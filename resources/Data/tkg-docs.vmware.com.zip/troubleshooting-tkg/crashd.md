# Troubleshooting Tanzu Kubernetes Clusters with Crash Diagnostics

[Crash Diagnostics (Crashd)](https://github.com/vmware-tanzu/crash-diagnostics) is an open source project that makes it easy to interact and automatically collect information, from Kubernetes infrastructures, for diagnosing problems with unstable state, or even unreponsive, clusters. 

Crashd uses a script file (written in Starlark, an Python-like language) that interacts with your TKG cluster to collect infrastructure and cluster information. The output of the script commands is then added to a `tar` file and saved locally for further analysis.

Tanzu Kubernetes Grid includes signed binaries for Crash Diagnostics and a diagnostics script file for Photon OS Tanzu Kubernetes clusters.

- [Install or Upgrade the Crashd Binary](#install)
- [Run Crashd on Photon OS Tanzu Kubernetes Grid Clusters](#tkg-photon)
- [Crash Recovery and Diagnostics Options](#options)

## <a id="install"></a> Install or Upgrade the Crashd Binary

This procedure assumes that you are installing Tanzu Kubernetes Grid v1.2.0. In v1.2.0, the version of Crash Diagnostics is `v0.3.1-vmware.4`. To upgrade `crashd` from `v0.2.2_vmware.3` to `v0.3.1-vmware.4`, follow the installation procedure to replace the existing binary with the new one.

1. Go to [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg) and log in with your My VMware credentials.
1. Download Crash Diagnostics for your platform.

   - Linux: **Crash Recovery and Diagnostics for Kubernetes 0.3.1 Linux**
   - Mac OS: **Crash Recovery and Diagnostics for Kubernetes 0.3.1 Mac**

1. Use the `gunzip` command to unpack the binary for your platform.

   - Linux:
        ```
        gunzip crashd-linux-v0.3.1-vmware.4.gz
        ```
   - Mac OS:
        ```
        gunzip crashd-darwin-v0.3.1-vmware.4.gz
        ```
1. Move the binary into the `/usr/local/bin` folder.

   - Linux:
        ```
        mv ./crashd-linux-v0.3.1-vmware.4 /usr/local/bin/crashd
        ```
   - Mac OS:
        ```
        mv ./crashd-darwin-v0.3.1-vmware.4 /usr/local/bin/crashd
        ```   
1. Make the file executable.

   ```
   chmod +x /usr/local/bin/crashd
   ```   


## <a id="tkg-photon"></a> Run Crash Diagnostics on Photon OS Tanzu Kubernetes Grid Clusters

The Crashd bundle that Tanzu Kubernetes Grid provides script file `diagnostics.crsh`, along with a script argument file `args`.  During execution, the argument values from the `args` file are passed to the script to extract information to help diagnose problems on Photon OS management clusters and Tanzu Kubernetes workload clusters that you deploy on vSphere from Tanzu Kubernetes Grid.

### Prerequisites

- Crashd requires an SSH private/public key pair.
- Ensure your Tanzu Kubernetes Grid VMs are configured to use your SSH public key.
- Extract the `kubeconfig` file for the management cluster using command `tkg get credentials <management-cluster-name>`.

### Procedure

1. Navigate to the location in which you downloaded and unpacked the Crashd bundle, and open argument file `args` in a text editor.

   For example, use `vi` to edit the file.

   ```
   vi args
   ```

   The file contains a series of named key/value pairs that are passed to the script:
   
   ```
   # Specifies cluster to target, (supported: bootstrap, mgmt, or workload)
   target=mgmt

   # Underlying infrastructure used by TKG (supported: vsphere, aws)
   infra=vsphere

   # working directory
   workdir=./workdir

   # User and private key for ssh connections to cluster nodes.
   ssh_user=capv
   ssh_pk_file=./capv.pem

   # namespace where mgmt cluster is deployed
   mgmt_cluster_ns=tkg-system

   # kubeconfig file path for management cluster
   mgmt_cluster_config=./tkg_cluster_config

   # Uncomment the following to specify a comma separated 
   # list of workload cluster names
   #workload_clusters=tkg-cluster-wc-498

   # Uncomment the following to specify the namespace
   # associated with the workload cluster names above
   #workload_cluster_ns=default
   ```   
1. Collecting diagnostics information from a bootstrap cluster:
   
   If you are troubleshooting the initial setup of your cluster during bootstrap, update the following arguments in the file:
   - `target`: Set this value to `bootstrap`.
   - `workdir`: The location in which to files as they are collected.

1. Collecting diagnostics from a management cluster:

   When diagnosing a management cluster failure, update the following arguments in the args file:
   - `target`: Set this value to `mgmt`.
   - `workdir`: The location in which to files as they are collected.
   - `ssh_user`: The SSH user used to access cluster machines. For clusters running on vSphere, the user name is `capv`.
    - `ssh_pk_file`: The path to your SSH private key file. For information about creating the SSH key pairs, see [Create an SSH Key Pair](../mgmt-clusters/vsphere.md#ssh-key) in *Deploy a Management Cluster to vSphere*.
    - `mgmt_cluster_ns`: The namespace where the management cluster is deployed.
   - `mgmt_cluster_config` The path of the kubeconfig file for the management cluster.
    
1. Collecting diagnostics from one or more workload clusters:

   When collecting diagnostics information from workload clusters, you will need to specify the following arguments:

   - `target`: Set this value to `workload`.
   - `workdir`: The location in which to files as they are collected.
   - `mgmt_cluster_ns`: The namespace where the management cluster is deployed.
   - `mgmt_cluster_config` The path of the kubeconfig file for the management cluster.

   In addition to the previous arguments, you will need to uncomment the following workload cluster values:

   - `workload_clusters`: a comma-separated list of workload cluster names from which to collect diagnostics information.
   - `workload_cluster_ns`: the namespace where the worload clusters are deployed. 

1. Run the Crashd command.

   Run the `crashd` command from the location in which script file `diagnostics.crsh` and argument file `args` are located.

   ```
   crashd run --args-file args diagnostics.crsh
   ```

   By default, the `crashd` command will run silently until completion.  However, you can use flag `--debug` to see log messages on the screen similar to the following: 

   ```
   crashd run --args-file args --debug diagnostics.crsh

   DEBU[0003] creating working directory ./workdir/tkg-kind-12345
   DEBU[0003] kube_capture(what=objects)
   DEBU[0003] Searching in 20 groups
   ...
   DEBU[0015] Archiving [./workdir/tkg-kind-12345] in bootstrap.tkg-kind-12345.diagnostics.tar.gz
   DEBU[0015] Archived workdir/tkg-kind-12345/kind-logs/docker-info.txt
   DEBU[0015] Archived workdir/tkg-kind-12345/kind-logs/tkg-kind-12345-control-plane/alternatives.log
   DEBU[0015] Archived workdir/tkg-kind-12345/kind-logs/tkg-kind-12345-control-plane/containerd.log
   ```