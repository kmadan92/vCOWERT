# Tanzu Kubernetes Grid CLI Reference

The table below lists all of the commands and options of the Tanzu Kubernetes Grid CLI, and provides links to the section in which they are documented.

<table class="table"> 
 <thead> 
  <tr> 
   <th>Command</th> 
   <th>Options</th> 
   <th>Documented In</th> 
  </tr> 
 </thead> 
 <tbody> 
  <tr> 
   <td colspan="3"><code>tkg *</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--config</code></td> 
   <td><a href="install-tkg.md#common-options">Common Tanzu Kubernetes Grid Options</a><br /><a href="mgmt-clusters/aws-cli.md">Deploy a Management Cluster to Amazon EC2 with the CLI</a><br /><a href="mgmt-clusters/aws-ui.md">Deploy a Management Cluster to Amazon EC2 with the Installer Interface</a><br /><a href="mgmt-clusters/azure-cli.md">Deploy a Management Cluster to Microsoft Azure with the CLI</a><br /><a href="mgmt-clusters/azure-ui.md">Deploy a Management Cluster to Microsoft Azure with the Installer Interface</a><br /><a href="mgmt-clusters/vsphere-cli.md">Deploy a Management Cluster to vSphere with the CLI</a><br /><a href="mgmt-clusters/vsphere-ui.md">Deploy a Management Cluster to vSphere with the Installer Interface</a></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--kubeconfig</code><br /><code>--log_file</code><br /><code>--quiet</code><br /><code>--v</code></td> 
   <td><a href="install-tkg.md#common-options">Common Tanzu Kubernetes Grid Options</a></td> 
  </tr> 
  <tr> 
   <td colspan="2"><code>tkg add management-cluster</code></td> 
   <td><a href="tanzu-k8s-clusters/connect-vsphere7.md">Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster</a><br /><a href="mgmt-clusters/multiple-management-clusters.md">Manage Your Management Clusters</a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg config cluster</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--controlplane-machine-count</code><br /><code>--controlplane-size</code><br /><code>--enable-cluster-options oidc</code><br /><code>--haproxy-size</code><br /><code>--kubernetes-version</code><br /><code>--namespace</code><br /><code>--plan</code><br /><code>--size</code><br /><code>--worker-machine-count</code><br /><code>--worker-size</code></td> 
   <td><a href="tanzu-k8s-clusters/config.md">Create Tanzu Kubernetes Cluster Configuration Files</a></td> 
  </tr>
  <tr> 
   <td colspan="3"><code>tkg config permissions aws</code></td>
  </tr>
  <tr>
   <td></td>
   <td><code>--config</code><br /><code>--kubeconfig</code><br /><code>--log_file</code><br /><code>--quiet</code><br /><code>--v</code></td>
   <td><a href="mgmt-clusters/aws-cli.md">Deploy Management Clusters to Amazon EC2 with the CLI</a></td>
  </tr>
  <tr>
   <td colspan="3"><code>tkg create cluster</code></td> 
  </tr>
  <tr> 
   <td></td> 
   <td><code>--cni</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#cni">Deploy a Cluster with a Non-Default CNI</a></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--controlplane-machine-count</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#ha-control-plane">Deploy a Cluster with a Highly Available Control Plane</a></td> 
  </tr> 
  <tr>
    <td></td>
    <td><code>--controlplane-size</code></td>
    <td><a href="tanzu-k8s-clusters/create.md#node-sizes">Deploy a Cluster with Nodes of Different Sizes</a></td>
  </tr>
  <tr> 
   <td></td> 
   <td><code>--dry-run</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#dry-run">Preview the YAML for a Tanzu Kubernetes Cluster</a></td> 
  </tr> 
  
  <tr>
    <td></td>
    <td><code>--enable-cluster-options oidc</code></td>
    <td><a href="extensions/deploy-auth-cluster.md">Deploy an Authentication-Enabled Tanzu Kubernetes Cluster</a><br /><a href="tanzu-k8s-clusters/create.md#auth">Create Tanzu Kubernetes Clusters</td>
  </tr>
  <tr> 
   <td></td> 
   <td><code>--kubernetes-version</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#k8s-version">Deploy a Cluster that Runs a Different Version of Kubernetes</a></td> 
  </tr> 
  <tr>
    <td></td>
    <td><code>--manifest</code></td>
    <td><a href="tanzu-k8s-clusters/config.md">Create Tanzu Kubernetes Cluster Configuration Files</a><br /><a href="tanzu-k8s-clusters/create.md#dry-run">Preview the YAML for a Tanzu Kubernetes Cluster</a></td>
  </tr>
  <tr> 
   <td></td> 
   <td><code>--namespace</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#namespace">Deploy a Cluster in a Specific Namespace</a></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--plan</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#plans">Tanzu Kubernetes Cluster Plans</a><br /><a href="tanzu-k8s-clusters/create.md#default">Deploy a Default Tanzu Kubernetes Cluster</a></td> 
  </tr> 
  <tr>
    <td></td>
    <td><code>--size</code></td>
    <td><a href="tanzu-k8s-clusters/create.md#node-sizes">Deploy a Cluster with Nodes of Different Sizes</a></td>
  </tr>
  <tr>
    <td></td>
    <td><code>--vsphere-controlplane-endpoint-ip</code></td>
    <td><a href="tanzu-k8s-clusters/create.md#deploy">Deploy Tanzu Kubernetes Clusters</a></td>
  </tr>
  <tr> 
   <td></td> 
   <td><code>--worker-machine-count</code></td> 
   <td><a href="tanzu-k8s-clusters/create.md#multi-worker-nodes">Deploy a Cluster with Multiple Worker Nodes</a></td> 
  </tr>
  <tr>
    <td></td>
    <td><code>--worker-size</code></td>
    <td><a href="tanzu-k8s-clusters/create.md#node-sizes">Deploy a Cluster with Nodes of Different Sizes</a></td>
  </tr> 
  <tr> 
   <td colspan="2"><code>tkg delete cluster</code></td> 
   <td><a href="tanzu-k8s-clusters/delete-cluster.md">Delete Tanzu Kubernetes Clusters</a></td> 
  </tr>
  <tr>
    <td colspan="2"><code>tkg delete machinehealthcheck</code></td>
    <td><a href="tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a></td>
  </tr>
  <tr> 
   <td colspan="2"><code>tkg delete management-cluster</code></td> 
   <td><a href="mgmt-clusters/multiple-management-clusters.md#delete">Delete Management Clusters</a></td> 
  </tr> 
    <tr>
    <td colspan="2"><code>tkg get ceip-participation</code></td>
    <td><a href="mgmt-clusters/multiple-management-clusters.md#ceip">Opt in or Out of the VMware CEIP</a></td>
  </tr>
  <tr> 
   <td colspan="3"><code>tkg get cluster</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--include-management-cluster</code></td> 
   <td><a href="tanzu-k8s-clusters/connect.md">Connect to and Examine Tanzu Kubernetes Clusters</a><br /><a href="upgrade-tkg/management-cluster.md">Upgrade Management Clusters</a><br /><a href="upgrade-tkg/workload-clusters.md">Upgrade Tanzu Kubernetes Clusters</a></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--namespace</code><br /><code>--output</code></td> 
   <td><a href="tanzu-k8s-clusters/connect.md">Connect to and Examine Tanzu Kubernetes Clusters</a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg get credentials</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--export-file</code><br /><code>--namespace</code></td> 
   <td><a href="tanzu-k8s-clusters/connect.md">Connect to and Examine Tanzu Kubernetes Clusters</a></td> 
  </tr> 
  <tr>
    <td colspan="2"><code>tkg get kubernetesversions </code></td>
    <td><a href="tanzu-k8s-clusters/create.md#k8s-version">Deploy a Cluster that Runs a Different Version of Kubernetes</a><br />
      <a href="upgrade-tkg/workload-clusters.md">Upgrade Tanzu Kubernetes Clusters</a><a href="upgrade-tkg/management-cluster.md"></a></td>
  </tr>
  <tr>
    <td colspan="2"><code>tkg get machinehealthcheck</code></td>
    <td><a href="tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a></td>
  </tr>
  <tr>
    <td colspan="2"><code>tkg get management-cluster</code></td>
    <td><a href="tanzu-k8s-clusters/connect.md">Connect to and Examine Tanzu Kubernetes Clusters</a><br />
      <a href="mgmt-clusters/verify-deployment.md">Examine the Management Cluster Deployment</a><br />
      <a href="mgmt-clusters/multiple-management-clusters.md">Manage Your Management Clusters</a><br />
      <a href="upgrade-tkg/management-cluster.md">Upgrade Management Clusters</a>
      </p></td>
  </tr>
  <tr> 
   <td>&nbsp;</td> 
   <td><code>--name</code><br />
     <code>--output</code></td>
   <td><a href="mgmt-clusters/multiple-management-clusters.md">Manage Your Management Clusters</a><a href="mgmt-clusters/verify-deployment.md"></a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg init</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--infrastructure aws</code></td> 
   <td><a href="mgmt-clusters/aws-cli.md">Deploy a Management Cluster to Amazon EC2 with the CLI</a></td> 
  </tr>
  <tr>
    <td></td>
    <td><code>--infrastructure azure</code></td>
    <td><a href="mgmt-clusters/azure-cli.md">Deploy a Management Cluster to Microsoft Azure with the CLI</a></td>
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--deploy-tkg-on-vSphere7</code><br />
     <code>--enable-tkgs-on-vSphere7</code><br />
   <code>--infrastructure vsphere</code><br />
   <code>--vsphere-controlplane-endpoint-ip</code></td> 
   <td><a href="mgmt-clusters/vsphere-cli.md">Deploy a Management Cluster to vSphere with the CLI </a></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--ceip-participation</code><br /><code>--controlplane-size</code><br /><code>--name</code><br /><code>--plan</code><br /><code>--size</code><br /><code>--worker-size</code></td> 
   <td><a href="mgmt-clusters/vsphere-cli.md">Deploy a Management Cluster to vSphere with the CLI </a><br /> <a href="mgmt-clusters/aws-cli.md">Deploy a Management Cluster to Amazon EC2 with the CLI</a><br /><a href="mgmt-clusters/azure-cli.md">Deploy a Management Cluster to Microsoft Azure with the CLI</a></td></td>
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--ui</code><br /><code>--ui --bind</code><br /><code>--ui --browser</code></td>
   <td><a href="mgmt-clusters/vsphere-ui.md">Deploy a Management Cluster to vSphere with the Installer Interface</a><br /> 
   <a href="mgmt-clusters/azure-ui.md">Deploy a Management Cluster to Microsoft Azure with the Installer Interface</a><br />
       <a href="mgmt-clusters/aws-ui.md">Deploy a Management Cluster to Amazon EC2 with the Installer Interface</a>     </td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--use-existing-bootstrap-cluster</code></td> 
   <td><a href="#use-existing">See below</a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg scale cluster</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--controlplane-machine-count</code><br /><code>--namespace</code><br /><code>--worker-machine-count</code></td> 
   <td><a href="mgmt-clusters/multiple-management-clusters.md">Manage Your Management Clusters</a><br /><a href="tanzu-k8s-clusters/scale-cluster.md">Scale Tanzu Kubernetes Clusters</a></td> 
  </tr> 
  <tr>
    <td colspan="2"><code>tkg set ceip-participation</code></td>
    <td><a href="mgmt-clusters/multiple-management-clusters.md#ceip">Opt in or Out of the VMware CEIP</a></td>
  </tr>
  <tr>
    <td colspan="2"><code>tkg set machinehealthcheck</code></td>
    <td><a href="tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a></td>
  </tr>
  <tr> 
   <td colspan="2"><code>tkg set management-cluster</code></td> 
   <td><a href="tanzu-k8s-clusters/connect.md">Connect to and Examine Tanzu Kubernetes Clusters</a><br /><a href="mgmt-clusters/multiple-management-clusters.md">Manage Your Management Clusters</a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg upgrade cluster</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--kubernetes-version</code><br /><code>--namespace</code><br /><code>--timeout</code><br /><code>--vpshere-vm-template-name</code><br /><code>--yes</code></td> 
   <td><a href="upgrade-tkg/workload-clusters.md">Upgrade Tanzu Kubernetes Clusters</a></td> 
  </tr> 
  <tr> 
   <td colspan="3"><code>tkg upgrade management-cluster</code></td> 
  </tr> 
  <tr> 
   <td></td> 
   <td><code>--timeout</code><br /><code>--vpshere-vm-template-name</code><br /><code>--yes</code></td> 
   <td><a href="upgrade-tkg/management-cluster.md">Upgrade Management Clusters</a></td> 
  </tr> 
  <tr> 
   <td colspan="2"><code>tkg version</code></td> 
   <td><a href="install-tkg.md">Install the Tanzu Kubernetes Grid CLI</a></td> 
  </tr> 
 </tbody> 
</table> 


## <a id="use-existing"></a> Use an Existing Bootstrap Cluster

By default, when you deploy a management cluster by running `tkg init`, Tanzu Kubernetes Grid creates a temporary `kind` cluster on the bootstrap machine, that it uses to provision the final management cluster. This temporary cluster is removed after the deployment of the final management cluster to vSphere, Amazon EC2, or Azure completes successfully. The same process of creating a temporary `kind` cluster also applies when you run `tkg delete management-cluster` to remove a management cluster.

In some circumstances, it might be desirable to keep the local bootstrap cluster after deploying or deleting a management cluster. For example, you might want to examine the objects in the cluster or review its logs. In this case, you can skip the creation of the `kind` cluster and use any Kubernetes cluster that already exists on your bootstrap machine as the local bootstrap cluster.

**IMPORTANT**:

- Using an existing bootstrap cluster is an advanced use case that is for experienced Kubernetes users. It is **strongly recommended** to use the default `kind` cluster that Tanzu Kubernetes Grid provides to bootstrap your management clusters.
- If you have used an existing cluster to bootstrap a management cluster, you cannot use that same cluster to bootstrap another management cluster. The same applies to deleting management clusters.

### Procedure

1. Set the context of `kubectl` to the local Kubernetes cluster that you want to use as a bootstrap cluster.

   ```
   kubectl config use-context my-bootstrap-cluster-admin@my-bootstrap-cluster
   ```   
1. To create a management cluster, run the `tkg init` command and specify the `--use-existing-bootstrap-cluster` option.
   
   ```
   tkg init --infrastructure=vsphere --use-existing-bootstrap-cluster my-bootstrap-cluster
   ```   
1. To delete a management cluster, run the `tkg delete management-cluster` command and specify the `--use-existing-bootstrap-cluster` option.

   If you are deleting a management cluster, first run `tkg get management-cluster` and `tkg set management-cluster` to make sure that the context of the Tanzu Kubernetes Grid CLI is set to the management cluster to delete.
   
   ```
   tkg delete management-cluster --use-existing-bootstrap-cluster my-bootstrap-cluster
   ```   