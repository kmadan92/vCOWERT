# Deploying Tanzu Kubernetes Grid Extensions and Shared Services

<!-- A README is required in each folder by Gitbook. This file is only for PDF generation and does not appear in the output -->

Deploying Tanzu Kubernetes Grid Extensions and Shared Services describes how to set up local shared services for your Tanzu Kubernetes clusters, such as authentication and authorization, logging, networking, and ingress control.
