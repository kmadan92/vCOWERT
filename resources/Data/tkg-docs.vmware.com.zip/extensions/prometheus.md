# Deploy Prometheus on Tanzu Kubernetes Clusters

Tanzu Kubernetes Grid includes signed binaries for Prometheus, so that you can enable monitoring services in your clusters. Prometheus provides an open-source system and service monitoring service.

- [Prerequisites](#prereqs)
- [Prepare the Tanzu Kubernetes Cluster for Prometheus Deployment](#prepare-tkc)
- [Prepare the Prometheus Configuration Files](#config)
- [Customize Your Prometheus Deployment](#customize)
- [Deploy Prometheus on the Tanzu Kubernetes Cluster](#deploy)
- [Update a Running Prometheus Deployment](#update)
- [Access the Prometheus Dashboard](#dashboard)
- [What to Do Next](#whatnext)

## <a id="prereqs"></a> Prerequisites

- You have downloaded and unpacked the bundle of Tanzu Kubernetes Grid extensions. For information about where to obtain the bundle, see [Download and Unpack the Tanzu Kubernetes Grid Extensions Bundle](index.md#unpack-bundle).  
- You have installed the Carvel tools. For information about installing the Carvel tools, see [Install the Carvel Tools on the Bootstrap Environment](index.md#install-carvel).
- You have deployed a management cluster on vSphere, Amazon EC2, or Azure.
- You have deployed a Tanzu Kubernetes cluster. The examples in this topic use a cluster named `monitoring-cluster`.

**IMPORTANT**: Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this section.

## <a id="prepare-tkc"></a> Prepare the Tanzu Kubernetes Cluster for Prometheus Deployment

Before you can deploy Prometheus on a Tanzu Kubernetes cluster, you must install the tools that the Prometheus extension requires. 

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. In a terminal, navigate to the folder that contains the unpacked Tanzu Kubernetes Grid extension manifest files, `tkg-extensions-v1.2.0+vmware.1/extensions`. 

   You should see folders for `authentication`, `ingress`, `logging`, `monitoring`, `registry`, and some YAML files. Run all of the commands in these procedures from this location.

1. Get the credentials of the cluster.

   ```sh
   tkg get credentials monitoring-cluster
   ```

1. Set the context of `kubectl` to the cluster.

   ```sh
   kubectl config use-context monitoring-cluster-admin@monitoring-cluster
   ```
1. Install the VMware Tanzu Mission Control extension manager on the Tanzu Kubernetes cluster.

    The Tanzu Kubernetes Grid extensions and Tanzu Mission Control both use the same extensions manager service. You must install the extensions manager even if you do not intend to use Tanzu Mission Control.
    ```sh
    kubectl apply -f tmc-extension-manager.yaml
    ```
    You should see confirmation that a namespace, resource definitions, a service account, an RBAC role, and a role binding for the `extension-manager` service are all created.
    
    ```
    namespace/vmware-system-tmc created
    customresourcedefinition.apiextensions.k8s.io/agents.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensions.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionresourceowners.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionintegrations.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionconfigs.intents.tmc.cloud.vmware.com created
    serviceaccount/extension-manager created
    clusterrole.rbac.authorization.k8s.io/extension-manager-role created
    clusterrolebinding.rbac.authorization.k8s.io/extension-manager-rolebinding created
    service/extension-manager-service created
    deployment.apps/extension-manager created
    ```

    Note that you can disregard any warning messages about deprecated APIs, if they appear.

1. Install the Kapp controller on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f kapp-controller.yaml
    ```
    You should see confirmation that a service account, resource definition, and RBAC role are created for the `kapp-controller` service.
    
    ```
    serviceaccount/kapp-controller-sa created
    customresourcedefinition.apiextensions.k8s.io/apps.kappctrl.k14s.io created
    deployment.apps/kapp-controller created
    clusterrole.rbac.authorization.k8s.io/kapp-controller-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/kapp-controller-cluster-role-binding created
    ```
    
1. Deploy `cert-manager`, which provides automated certificate management, on the Tanzu Kubernetes cluster.

   ```sh
   kubectl apply -f ../cert-manager/
   ```

1. Create a namespace for the Prometheus service on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f monitoring/prometheus/namespace-role.yaml
    ```
    You should see confirmation that a `tanzu-system-monitoring` namespace, service account, and RBAC role bindings are created.
    
    ```
    namespace/tanzu-system-monitoring created
    serviceaccount/prometheus-extension-sa created
    role.rbac.authorization.k8s.io/prometheus-extension-role created
    rolebinding.rbac.authorization.k8s.io/prometheus-extension-rolebinding created
    clusterrole.rbac.authorization.k8s.io/prometheus-extension-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/prometheus-extension-cluster-rolebinding created
    ```

1. Check that the Tanzu Mission Control extension manager, the Kapp controller, and cert-manager are running by listing all of the pods that are running in the Tanzu Kubernetes cluster. 

   ```sh
   kubectl get pods -A
   ```   

   In the `vmware-system-tmc` namespace, you should see running `extension-manager` and `kapp-controller` pods with names similar to `extension-manager-7cbdf7cbf9-xzrbn` and `kapp-controller-cd55bbd6b-vt2c4`.

   Similarly, in the `cert-manager` namespace, you should see running pods with names like `cert-manager-69877b5f94-8kwx9`, `cert-manager-cainjector-7594d76f5f-8tstw`, and `cert-manager-webhook-5fc8c6dc54-nlvzp`.

   The `Ready` status for all of these pods should show `1/1`; if that is not the case, stop and troubleshoot these pods before proceeding.

The Tanzu Kubernetes cluster is ready for you to deploy the Prometheus extension. For the next steps, see [Prepare the Prometheus Configuration Files](#config).

## <a id="config"></a> Prepare the Prometheus Configuration Files

This procedure describes how to prepare the configuration files to enable Prometheus on Tanzu Kubernetes clusters that you have deployed on vSphere, Amazon EC2, or Azure. 

1. Make a copy of the `prometheus-data-values.yaml.example` file for your platform, and name it `prometheus-data-values.yaml`.
   
   **vSphere:**
   ```
   cp monitoring/prometheus/vsphere/prometheus-data-values.yaml.example monitoring/prometheus/vsphere/prometheus-data-values.yaml
   ```
   **Amazon EC2:**
   ```sh
   cp monitoring/prometheus/aws/prometheus-data-values.yaml.example monitoring/prometheus/aws/prometheus-data-values.yaml
   ```
   **Azure:**
   ```sh
   cp monitoring/prometheus/azure/prometheus-data-values.yaml.example monitoring/prometheus/azure/prometheus-data-values.yaml
   ```

   After you have renamed the file, you do not need to modify it. The `prometheus-data-values.yaml` file only designates whether you are deploying to a cluster that is running on vSphere, Amazon EC2, or Azure. 
   
1. You can now either deploy Prometheus with all default values, or you can customize the deployment.   
 
   - To deploy Prometheus with all default values, proceed directly to [Deploy Prometheus on the Tanzu Kubernetes Cluster](#deploy). The default values allow you to get Prometheus running quickly.

   - To customize your Prometheus deployment, for example, to change how often it scrapes the cluster for information, or to configure notifications and alerts that are sent via Slack or email, see [Customize Your Prometheus Deployment](#customize).

## <a id="customize"></a> Customize Your Prometheus Deployment

In addition to the minimum configuration provided in the `prometheus-data-values.yaml` file, you can customize your configuration by adding values that you can copy from the file `tkg-extensions-v1.2.0+vmware.1/monitoring/prometheus/values.yaml` into `prometheus-data-values.yaml`. Note that this file is not located in the `tkg-extensions-v1.2.0+vmware.1/extensions/monitoring/prometheus` folder, but in the `monitoring` folder that is at the same level as the `extensions` folder. 

The table below contains information on the values you can copy from the `tkg-extensions-v1.2.0+vmware.1/monitoring/prometheus/values.yaml` file and how they can be used to modify the default behavior of Prometheus when deployed onto a Tanzu Kubernetes cluster.

| Parameter  | Description  | Type  | Default  |
|------------|--------------|-------|----------|
| `infrastructure_provider` | Infrastructure Provider. | string | `vsphere` / `aws` / `azure`  |
| `monitoring.namespace` | Namespace where Prometheus will be deployed | string  | `tanzu-system-monitoring` |
| `monitoring.create_namespace` | The flag indicates whether to create the namespace specified by `monitoring.namespace` | boolean | `false` |
| `onitoring.prometheus_server.config.alerting_rules_yaml` | Detailed alert rules defined in Prometheus | YAML file | `alerting_rules.yaml` |
| `monitoring.prometheus_server.config.recording_rules_yaml` | Detailed record rules defined in Prometheus | YAML file | `recording_rules.yaml` |
| `monitoring.prometheus_server.service.type` | Type of service to expose Prometheus. Supported value: `ClusterIP` | string | `ClusterIP`|
| `monitoring.prometheus_server.enable_alerts.kubernetes_api`| Enable SLO alerting for the Kubernetes API in Prometheus | boolean | `true` |
| `monitoring.prometheus_server.sc.sc_enabled` | Define if `StorageClass` is enabled in the deployment | boolean | `false` |
| `monitoring.prometheus_server.sc.is_default` | Define if current `StorageClass` is the default `StorageClass` | boolean | `false` |
| `monitoring.prometheus_server.sc.vsphereDatastoreurl` | Datastore URL for `StorageClass` used in vCenter | string | `"xxx-xxx-xxxx"` |
| `monitoring.prometheus_server.sc.aws_type`   | AWS type defined for `StorageClass` on AWS | string | `gp2` |
| `monitoring.prometheus_server.sc.aws_fsType` | AWS file system type defined for `StorageClass` on AWS | string | `ext4` |
| `monitoring.prometheus_server.sc.allowVolumeExpansion` | Define if volume expansion allowed for `StorageClass` on AWS| boolean | `true` |
| `monitoring.prometheus_server.pvc.annotations` | Storage class annotations | map | `{}` |
| `monitoring.prometheus_server.pvc.storage_class` | Storage class to use for Persistent Volume Claim. By default, this is null and the default provisioner is used | string | `null` |
| `monitoring.prometheus_server.pvc.accessMode`  | Define access mode for Persistent Volume Claim. Supported values: `ReadWriteOnce`, `ReadOnlyMany`, `ReadWriteMany` | string | `ReadWriteOnce` |
| `monitoring.prometheus_server.pvc.storage` | Define storage size for Persistent Volume Claim | string | `8Gi` |
| `monitoring.prometheus_server.deployment.replicas`| Number of Prometheus replicas | integer | `1` |
| `monitoring.prometheus_server.image.repository`| Repository containing the Prometheus image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.prometheus_server.image.name` | Name of the Prometheus image | string   | `prometheus` |
| `monitoring.prometheus_server.image.tag` | Image tag for the Prometheus image | string | `v2.17.1_vmware.1` |
| `monitoring.prometheus_server.image.pullPolicy` | The image pull policy for the Prometheus image | string | `IfNotPresent` |
| `monitoring.alertmanager.config.slack_demo` | Slack notification configuration for Alert Manager | string | See [Slack configuration example](#slack-config-example) below |
| `monitoring.alertmanager.config.email_receiver`  | Email notification configuration for Alert Manager | string | See [e-mail configuration example](#email-config-example) below |
| `monitoring.alertmanager.service.type` | Type of service to expose Alert Manager. Supported values: `ClusterIP` | string | `ClusterIP` |
| `monitoring.alertmanager.image.repository` | Repository containing the Alert Manager image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.alertmanager.image.name` | Name of the Alert Manager image | string  | `alertmanager` |
| `monitoring.alertmanager.image.tag` | Image tag for the Alert Manager image | string | `v0.20.0_vmware.1` |
| `monitoring.alertmanager.image.pullPolicy` | The image pull policy for the Alert Manager image | string | `IfNotPresent` |
| `monitoring.alertmanager.pvc.annotations` | `StorageClass` annotations | map | `{}` |
| `monitoring.alertmanager.pvc.storage_class` | `StorageClass` to use for Persistent Volume Claim. By default, this is null and the default provisioner is used | string | `null` |
| `monitoring.alertmanager.pvc.accessMode` | Define access mode for Persistent Volume Claim. Supported values: `ReadWriteOnce`, `ReadOnlyMany`, `ReadWriteMany` | string | `ReadWriteOnce` |
| `monitoring.alertmanager.pvc.storage` | Define storage size for Persistent Volume Claim | string | `2Gi` |
| `monitoring.alertmanager.deployment.replicas`   | Number of Alert Manager replicas | integer | `1` |
| `monitoring.kube_state_metrics.image.repository` | Repository containing `kube-state-metrics` image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.kube_state_metrics.image.name` | Name of the `kube-state-metrics` image | string | `kube-state-metrics`|
| `monitoring.kube_state_metrics.image.tag`  | Image tag for the `kube-state-metrics` image | string | `v1.9.5_vmware.1` |
| `monitoring.kube_state_metrics.image.pullPolicy` | The image pull policy for the `kube-state-metrics` image | string | `IfNotPresent` |
| `monitoring.kube_state_metrics.deployment.replicas` | Number of `kube-state-metrics` replicas | integer| `1` |
| `monitoring.node_exporter.image.repository`| Repository containing the `node-exporter` image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.node_exporter.image.name` | Name of the `node-exporter` image | string | `node-exporter` |
| `monitoring.node_exporter.image.tag` | Image tag for the `node-exporter` image | string | `v0.18.1_vmware.1` |
| `monitoring.node_exporter.image.pullPolicy` | The image pull policy for the `node-exporter` image | string | `IfNotPresent` |
| `monitoring.node_exporter.deployment.replicas` | Number of `node-exporter` replicas | integer| `1` |
| `monitoring.pushgateway.image.repository` | Repository containing the `pushgateway` image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.pushgateway.image.name` | Name of the `pushgateway` image | string | `pushgateway` |
| `monitoring.pushgateway.image.tag` | Image tag for the `pushgateway` image | string | `v1.2.0_vmware.1` |
| `monitoring.pushgateway.image.pullPolicy` | The image pull policy for the `pushgateway` image | string | `IfNotPresent` |
| `monitoring.pushgateway.deployment.replicas` | Number of `pushgateway` replicas   | integer | `1` |
| `monitoring.cadvisor.image.repository` | Repository containing cadvisor image | string | `registry.tkg.vmware.run/prometheus` |
| `monitoring.cadvisor.image.name` | Name of the `cadvisor` image| string | `cadvisor` |
| `monitoring.cadvisor.image.tag`| Image tag for the `cadvisor` image | string | `v0.36.0_vmware.1`  |
| `monitoring.cadvisor.image.pullPolicy` | The image pull policy for the `cadvisor` image | string | `IfNotPresent` |
| `monitoring.cadvisor.deployment.replicas` | Number of `cadvisor` replicas | integer | `1` |
| `monitoring.ingress.enabled` | Enable/disable ingress for Prometheus and Alert Manager | boolean | `false` |
| `monitoring.ingress.virtual_host_fqdn` | Hostname for accessing Promethues and Alert Manager| string | `prometheus.system.tanzu`    |
| `monitoring.ingress.prometheus_prefix` | Path prefix for Prometheus | string | `/` |
| `monitoring.ingress.alertmanager_prefix` | Path prefix for Alert Manager | string | `/alertmanager/` |
| `monitoring.ingress.tlsCertificate.tls.crt` | Optional certificate for ingress when using your own TLS certificate (a self-signed certificate is generated by default) | string | Generated certificate |
| `monitoring.ingress.tlsCertificate.tls.key`| Optional certificate private key for ingress when using your own TLS certificate (a private key from a self-signed certificate is generated by default) | string | Generated cert key |

<a id="slack-config-example"></a> **Slack Configuration Example**

To configure Alert Manager to send notifications to Slack, you can use the following YAML as an example configuration:

```yaml
slack_demo:
  name: slack_demo
  slack_configs:
  - api_url: https://hooks.slack.com
    channel: '#alertmanager-test'
```

<a id="email-config-example"></a> **E-Mail Configuration Example**

The YAML below provides an example of how to configure Alert Manager to send e-mail notifications.

```yaml
email_receiver:
  name: email-receiver
  email_configs:
  - to: demo@tanzu.com
    send_resolved: false
    from: from-email@tanzu.com
    smarthost: smtp.example.com:25
    require_tls: false
```

If you modify the `values.yaml` file _before_ deploying the Prometheus extension, then the settings will take effect when you deploy. See [Deploy Prometheus on the Tanzu Kubernetes Cluster](#deploy-prometheus) for instructions about initial deployment of Prometheus.

If you modify the `values.yaml` file _after_ deploying the Prometheus extension, you must update your running deployment. See the [Update a Running Prometheus Deployment](#update) section for steps on how to update a running Prometheus deployment on a Tanzu Kubernetes cluster.

## <a id="deploy"></a> Deploy Prometheus on the Tanzu Kubernetes Cluster

After you have prepared the Tanzu Kubernetes cluster, updated the appropriate configuration file for your platform, and optionally customized your deployment, you can deploy Prometheus on the cluster. 

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Create a Kubernetes secret named `prometheus-data-values` with the values that you set in `monitoring/prometheus/<platform>/prometheus-data-values.yaml`.
   
   **vSphere:**
   ```
   kubectl create secret generic prometheus-data-values --from-file=values.yaml=monitoring/prometheus/vsphere/prometheus-data-values.yaml -n tanzu-system-monitoring
   ```
   
   **Amazon EC2:**
   ```
    kubectl create secret generic prometheus-data-values --from-file=values.yaml=monitoring/prometheus/aws/prometheus-data-values.yaml -n tanzu-system-monitoring
    ``` 
   
   **Azure:**
   ```
    kubectl create secret generic prometheus-data-values --from-file=values.yaml=monitoring/prometheus/azure/prometheus-data-values.yaml -n tanzu-system-monitoring
    ```  

1. Deploy the Prometheus extension.

    ```sh
    kubectl apply -f monitoring/prometheus/prometheus-extension.yaml
    ```

    You should see a confirmation that `extensions.clusters.tmc.cloud.vmware.com/prometheus` was created.

2. The extension takes several minutes to deploy. You can check the status of the Prometheus extension with the `kubectl get extension` and the `kubectl get app` commands:

    ```sh
    kubectl get extension prometheus -n tanzu-system-monitoring
    kubectl get app prometheus -n tanzu-system-monitoring
    ```

    When the extension is still in the process of deploying, the "Description" field from the `kubectl get app` command will show `Reconciling`. Once Prometheus is deployed successfully, the Prometheus app status (as shown by the `kubectl get app` command above) should change to `Reconcile succeeded`. The output of the `kubectl get extension` command does not change.

    You can view detailed status information with this command:

    ```sh
    kubectl get app prometheus -n tanzu-system-monitoring -o yaml
    ```

## <a id="update"></a> Update a Running Prometheus Deployment

If you need to make changes to the configuration of the Prometheus extension, then follow these steps to update your deployed Prometheus extension.

1. Using the information in the [Customize Your Prometheus Deployment](#customize) as reference, make the necessary changes to the `tkg-extensions-v1.2.0+vmware.1/monitoring/prometheus/values.yaml` file. For example, if you need to change the number of Prometheus replicas (the default value is one), then you would add this to the `values.yaml` file:

    ```yaml
    monitoring:
      prometheus_server:
        deployment:
          replicas: 2
    ```

    Once you have made all applicable changes, save the file.

1. Update the Kubernetes secret.

    ```sh
    kubectl create secret generic prometheus-data-values --from-file=values.yaml=monitoring/prometheus/aws/prometheus-data-values.yaml -n tanzu-system-monitoring -o yaml --dry-run=client | kubectl replace -f -
    ```

    Note that the final `-` on the `kubectl replace` command above is necessary to instruct `kubectl` to accept the input being piped to it from the `kubectl create secret` command.

   The Prometheus extension will be reconciled using the new values you just added. The changes should show up in five minutes or less. This is handled by the Kapp controller, which synchronizes every five minutes.

1. To apply the changes immediately, delete the pods handled by the Prometheus extension, and the Kapp controller will recreate them with your updated configuration. 

   You can use the following commands to get the list of the pod names and to delete them.
   
   ```
   kubectl -n tanzu-system-monitoring get pods
   ```
   The pods are running in the `tanzu-system-monitoring` namespace, and have names like `prometheus-alertmanager-76c764dc9d-fqrct`, `prometheus-cadvisor-269bz`, `prometheus-kube-state-metrics-9456587f6-mwffw`, `prometheus-node-exporter-ffc7m`, `prometheus-pushgateway-7bc77847cd-cgsj8`, and `prometheus-server-55f9877f64-v4g52`.    
   ```   
   kubectl -n tanzu-system-monitoring delete pod <name>
   ```

## <a id="dashboard"></a> Access the Prometheus Dashboard

By default, ingress is not enabled on Prometheus. This is because access to the Prometheus dashboard is not authenticated. If you want to access the Prometheus dashboard, you must perform the following steps.

1. Deploy Contour on the cluster. 

   For information about deploying Contour, see [Implement Ingress control with Contour](ingress-contour.md). 
1. Copy the `monitoring.ingress.enabled` section from `tkg-extensions-v1.2.0+vmware.1/monitoring/prometheus/values.yaml` into `prometheus-data-values.yaml`. 

   Copy the section into the position shown in this example.

    ```
    #@data/values
    #@overlay/match-child-defaults missing_ok=True
    ---
    infrastructure_provider: "vsphere"
    monitoring:
      ingress:
        enabled: false
        virtual_host_fqdn: "prometheus.corp.tanzu"
        prometheus_prefix: "/"
        alertmanager_prefix: "/alertmanager/"
    ```
1. Update `monitoring.ingress.enabled` from `false` to `true`.
1. Create a DNS record to map `prometheus.corp.tanzu` to the address of the Envoy load balancer.

   How to obtain the address of the Envoy load balancer is described in [Implement Ingress control with Contour](ingress-contour.md).
1. Access the Prometheus dashboard by going to http://prometheus.corp.tanzu in a browser.

   ![Prometheus dashboard](../images/prometheus-dashboard.png)
   

## <a id="whatnext"></a> What to Do Next

The Prometheus extension is now running and scraping data from your cluster. To visualize the data in Grafana dashboards, see [Deploy Grafana on Tanzu Kubernetes Clusters](grafana.md).


