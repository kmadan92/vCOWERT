# Implementing Ingress Control with Contour

Ingress control is a core concept in Kubernetes, that is implemented by a third party proxy. [Contour](https://projectcontour.io/) is a Kubernetes ingress controller that uses the [Envoy](https://www.envoyproxy.io/) edge and service proxy. Tanzu Kubernetes Grid includes signed binaries for Contour and Envoy, that you can deploy on Tanzu Kubernetes clusters to provide ingress control services on those clusters.

For general information about ingress control, see [Ingress Controllers](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/) in the Kubernetes documentation.

You deploy Contour and Envoy directly on Tanzu Kubernetes clusters. You do not need to deploy Contour on management clusters. Deploying Contour is a prerequisite if you want to deploy the Prometheus, Grafana, and Harbor extensions. 

- [Prerequisites](#prereqs)
- [Prepare the Tanzu Kubernetes Cluster for Contour Deployment](#prepare-tkc)
- [Deploy Contour on the Tanzu Kubernetes Cluster](#deploy)
- [Access the Envoy Administration Interface Remotely](#envoy-interface)
- [Visualize the Internal Contour Directed Acyclic Graph (DAG)](#contour-dag)

## <a id="prereqs"></a> Prerequisites

- Deploy a management cluster on vSphere, Amazon EC2, or Azure.
- You have downloaded and unpacked the bundle of Tanzu Kubernetes Grid extensions. For information about where to obtain the bundle, see [Download and Unpack the Tanzu Kubernetes Grid Extensions Bundle](index.md#unpack-bundle).  
- You have installed the Carvel tools. For information about installing the Carvel tools, see [Install the Carvel Tools on the Bootstrap Environment](index.md#install-carvel).

**IMPORTANT**: 

- In this release of Tanzu Kubernetes Grid, the provided implementation of Contour and Envoy assumes that you use self-signed certificates. To configure Contour and Envoy with your own certificates, engage with VMware Tanzu support.
- Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this section.

## <a id="prepare-tkc"></a> Prepare the Tanzu Kubernetes Cluster for Contour Deployment

Before you can deploy Contour on a Tanzu Kubernetes cluster, you must install the tools that the Contour extension requires. 

This procedure applies to all clusters, running on vSphere, Amazon EC2, and Azure.

1. Deploy a Tanzu Kubernetes cluster. 

   For example, deploy a Tanzu Kubernetes cluster named `contour-test`.
   
   **vSphere:** 
   
   ```
   tkg create cluster contour-test --plan dev --vsphere-controlplane-endpoint-ip <WORKLOAD_CLUSTER_VIP>
   ```
   
   Replace `<WORKLOAD_CLUSTER_VIP>` with a static virtual IP address for the Tanzu Kubernetes cluster. Make sure that this IP address is not in the DHCP range, but is in the same subnet as the DHCP range.

   **Amazon EC2 and Azure**:

   ```
   tkg create cluster contour-test --plan dev
   ```
1. In a terminal, navigate to the folder that contains the unpacked Tanzu Kubernetes Grid extension manifest files, `tkg-extensions-v1.2.0+vmware.1/extensions`. 

   You should see folders for `authentication`, `ingress`, `logging`, `monitoring`, `registry`, and some YAML files. Run all of the commands in these procedures from this location.

1. Get the credentials of the Tanzu Kubernetes cluster on which to deploy Contour.

   ```
   tkg get credentials contour-test
   ```

1. Set the context of `kubectl` to the Tanzu Kubernetes cluster.

   ```
   kubectl config use-context contour-test-admin@contour-test
   ```
1. Install the VMware Tanzu Mission Control extension manager on the cluster.

    The Tanzu Kubernetes Grid extensions and Tanzu Mission Control both use the same extensions manager service. You must install the extensions manager even if you do not intend to use Tanzu Mission Control.
    ```
    kubectl apply -f tmc-extension-manager.yaml
    ```
    You should see confirmation that a namespace, resource definitions, a service account, an RBAC role, and a role binding for the `extension-manager` service are all created.
    
    ```
    namespace/vmware-system-tmc created
    customresourcedefinition.apiextensions.k8s.io/agents.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensions.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionresourceowners.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionintegrations.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionconfigs.intents.tmc.cloud.vmware.com created
    serviceaccount/extension-manager created
    clusterrole.rbac.authorization.k8s.io/extension-manager-role created
    clusterrolebinding.rbac.authorization.k8s.io/extension-manager-rolebinding created
    service/extension-manager-service created
    deployment.apps/extension-manager created
    ```

1. Install the Kapp controller on the management cluster.

    ```sh
    kubectl apply -f kapp-controller.yaml
    ```
    You should see confirmation that a service account, resource definition, and RBAC role are created for the `kapp-controller` service.
    
    ```
    serviceaccount/kapp-controller-sa created
    customresourcedefinition.apiextensions.k8s.io/apps.kappctrl.k14s.io created
    deployment.apps/kapp-controller created
    clusterrole.rbac.authorization.k8s.io/kapp-controller-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/kapp-controller-cluster-role-binding created
    ```
1. Deploy `cert-manager`, which provides automated certificate management, on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f ../cert-manager/
    ```  
1. Create a namespace for the Contour service on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f ingress/contour/namespace-role.yaml
    ```
    You should see confirmation that a `tanzu-system-ingress` namespace, service account, and RBAC role bindings are created.
    ```
    namespace/tanzu-system-ingress created
    serviceaccount/contour-extension-sa created
    role.rbac.authorization.k8s.io/contour-extension-role created
    rolebinding.rbac.authorization.k8s.io/contour-extension-rolebinding created
    clusterrole.rbac.authorization.k8s.io/contour-extension-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/contour-extension-cluster-rolebinding created
    ```
1. Check that the new services are running by listing all of the pods that are running in the cluster. 

   ```
   kubectl get pods -A
   ```   

   In the `tanzu-system-tmc` namespace, you should see the `extension-manager` and `kapp-controller` services running in a pod with names similar to `extension-manager-7cbdf7cbf9-xzrbn` and `kapp-controller-cd55bbd6b-vt2c4`.
   
   ```
    NAMESPACE              NAME                                  READY   STATUS    RESTARTS   AGE
    [...]
    vmware-system-tmc      extension-manager-7cbdf7cbf9-xzrbn    1/1     Running   0          52s
    vmware-system-tmc      kapp-controller-cd55bbd6b-vt2c4       1/1     Running   0          40s
    ```   

The cluster is ready for you to deploy the Contour service. For the next steps, see [Deploy Contour on the Tanzu Kubernetes Cluster](#deploy).

## <a id="deploy"></a> Deploy Contour on the Tanzu Kubernetes Cluster

After you have set up the cluster, you must create the configuration file that is used when you deploy Contour, create a Kubernetes secret, and then deploy Contour. 

This procedure applies to all clusters, running on vSphere, Amazon EC2, and Azure.

1. Make a copy of the `contour-data-values.yaml.example` file and name it `contour-data-values.yaml`.
   
   **vSphere:** 
   
   ```
   cp ingress/contour/vsphere/contour-data-values.yaml.example ingress/contour/vsphere/contour-data-values.yaml
   ```

   **Amazon EC2**:

   ```
   cp ingress/contour/aws/contour-data-values.yaml.example ingress/contour/aws/contour-data-values.yaml
   ```

   **Azure**:

   ```
   cp ingress/contour/azure/contour-data-values.yaml.example ingress/contour/azure/contour-data-values.yaml
   ```

1. (Optional) modify any values in `contour-data-values.yaml`. In most cases you do not need to modify `contour-data-values.yaml`, but the `ingress/contour/README.md` file in the extensions bundle directory lists non-default options that you may set.
   - For example, the Contour extension exposes Envoy as a `NodePort` type service by default, but also supports it as a `LoadBalancer` or `ClusterIP` service. You set this `envoy.service.type` value in `contour-data-values.yaml`.

1. Create a Kubernetes secret named `contour-data-values` with the values that you set in `contour-data-values.yaml`.

   **vSphere:** 
   
   ```
   kubectl create secret generic contour-data-values --from-file=values.yaml=ingress/contour/vsphere/contour-data-values.yaml -n tanzu-system-ingress
   ```

   **Amazon EC2**:

   ```
   kubectl create secret generic contour-data-values --from-file=values.yaml=ingress/contour/aws/contour-data-values.yaml -n tanzu-system-ingress
   ```

   **Azure**:

   ```
   kubectl create secret generic contour-data-values --from-file=values.yaml=ingress/contour/azure/contour-data-values.yaml -n tanzu-system-ingress
   ```

   You should see the confirmation `secret/contour-data-values created`.
   
1. Deploy the Contour extension

   ```
   kubectl apply -f ingress/contour/contour-extension.yaml
   ```

   You should see the confirmation `extension.clusters.tmc.cloud.vmware.com/contour created`.

1. View the status of the Contour extension.

    ```
    kubectl get extension contour -n tanzu-system-ingress
    ```
    You should see information about the Contour extension.
    ```
    NAME      STATE   HEALTH   VERSION
    contour   3
    ```
1. View the status of the Contour service itself.

    ```
    kubectl get app contour -n tanzu-system-ingress
    ```
    The status of the Contour app should show `Reconcile Succeeded` when Contour has deployed successfully. 
    ```
    NAME      DESCRIPTION           SINCE-DEPLOY   AGE
    contour   Reconcile succeeded   15s            72s
    ```
1. If the status is not `Reconcile Succeeded`, view the full status details of the Contour service.

   Viewing the full status can help you to troubleshoot the problem.

   ```
   kubectl get app contour -n tanzu-system-ingress -o yaml
   ```
   
1. Check that the new services are running by listing all of the pods that are running in the cluster. 

   ```
   kubectl get pods -A
   ```   

   In the `tanzu-system-ingress` namespace, you should see the `contour` and `envoy` services running in a pod with names similar to `contour-55c56bd7b7-85gc2` and `envoy-tmxww`.
   
   ```
    NAMESPACE              NAME                                  READY   STATUS    RESTARTS   AGE
    [...]
    tanzu-system-ingress   contour-55c56bd7b7-85gc2              1/1     Running   0          6m37s
    tanzu-system-ingress   contour-55c56bd7b7-x4kv7              1/1     Running   0          6m37s
    tanzu-system-ingress   envoy-tmxww                           2/2     Running   0          6m38s
    ``` 
1. If you deployed Contour to Amazon EC2 or Azure, check that a load balancer has been created for the Envoy service.
   
   ```
   $ kubectl get svc envoy -n tanzu-system-ingress -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
   ```

   On Amazon EC2, the loadbalancer has a name similar to `aabaaad4dfc8e4a808a70a7cbf7d9249-1201421080.us-west-2.elb.amazonaws.com`. On Azure, it will be an IP address similar to `20.54.226.44`.


## <a id="envoy-interface"></a> Access the Envoy Administration Interface Remotely

After you have deployed Contour on a cluster, you can use the embedded Envoy administration interface to view data about your deployments.

For information about the Envoy administration interface, see [Administration interface](https://www.envoyproxy.io/docs/envoy/latest/operations/admin) in the Envoy documentation.

1. Obtain the name of the Envoy pod.

    ```sh
    ENVOY_POD=$(kubectl -n tanzu-system-ingress get pod -l app=envoy -o name | head -1)
    ```

1. Forward the Envoy pod to port 9001 on your local machine.

    ```sh
    kubectl -n tanzu-system-ingress port-forward $ENVOY_POD 9001
    ```

1. In a browser, navigate to [http://127.0.0.1:9001/](http://127.0.0.1:9001/).

   You should see the Envoy administration interface.
   
   ![Envoy administration interface](../images/envoy-admin-interface.png)
1. Click the links in the Envoy administration interface to see information about the operations in your cluster.

## <a id="contour-dag"></a> Visualize the Internal Contour Directed Acyclic Graph (DAG)

When you have started running workloads in your Tanzu Kubernetes cluster, you can visualize the traffic information that Contour exposes in the form of a directed acyclic graph (DAG).

1. Obtain a Contour pod.

    ```sh
    CONTOUR_POD=$(kubectl -n tanzu-system-ingress get pod -l app=contour -o name | head -1) 
    ```

2. Forward port 6060 on the Contour pod.

    ```sh
    kubectl -n tanzu-system-ingress port-forward $CONTOUR_POD 6060
    ```

3. Open a new terminal window and download and store the DAG as a `*.png` file.

    This command requires you to install `dot` on your system, if it is not present already.
    
    ```sh
    curl localhost:6060/debug/dag | dot -T png > contour-dag.png
    ```

4. Open `contour-dag.png` to view the graph.

   ![Contour DAG file](../images/contour-dag.png)