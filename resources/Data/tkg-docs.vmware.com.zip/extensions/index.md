# Deploying Tanzu Kubernetes Grid Extensions and Shared Services

Tanzu Kubernetes Grid includes binaries for tools that provide in-cluster and shared services to the clusters running in your Tanzu Kubernetes Grid instance. All of the provided binaries and container images are built and signed by VMware. 

Tanzu Kubernetes Grid provides extensions that allow you to configure Tanzu Kubernetes clusters with the following services:

- [Ingress control with Contour](ingress-contour.md)
- [Log forwarding with Fluentbit](logging-fluentbit.md)
- [Monitoring with Prometheus and Grafana](monitoring.md)
- [User authentication with Dex and Gangway](authentication.md)

Tanzu Kubernetes Grid also provides a [Harbor registry](harbor-registry.md), that you deploy as a shared service for use by multiple Tanzu Kubernetes clusters.

Before you can deploy the Tanzu Kubernetes Grid extensions, you must prepare your bootstrap environment by performing the following tasks.

- [Download and Unpack the Tanzu Kubernetes Grid Extensions Bundle](#unpack-bundle)
- [Install the Carvel Tools on the Bootstrap Environment](#install-carvel)
- [Deploying the Tanzu Kubernetes Grid Extensions in an Internet Restricted Environment](#internet-restricted)

## <a id="unpack-bundle"></a> Download and Unpack the Tanzu Kubernetes Grid Extensions Bundle

The Tanzu Kubernetes Grid extension manifests are provided in a separate bundle to the Tanzu Kubernetes Grid CLI and other binaries.

1. On the system that you use as the bootstrap machine, go to [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg) and log in with your My VMware credentials.
1. Under **Product Downloads**, click **Go to Downloads**.
1. Scroll to **VMware Tanzu Kubernetes Grid Extensions Manifest 1.2.0** and click **Download Now**.
1. Use either the `tar` command or the extraction tool of your choice to unpack the bundle of YAML manifest files for the Tanzu Kubernetes Grid extensions. 

   <pre>tar -xzf tkg-extensions-manifests-v1.2.0-vmware.1.tar-2.gz</pre>

   For convenience, unpack the bundle in the same location as the one from which you run `tkg` and `kubectl` commands.
   
## <a id="install-carvel"></a> Install the Carvel Tools on the Bootstrap Environment

The Tanzu Kubernetes Grid uses the following tools from the [Carvel open-source project](https://carvel.dev/) to configure and deploy all of the extensions:

- [`ytt`](https://github.com/k14s/ytt): YAML templating tool
- [`kapp`](https://github.com/k14s/kapp): Kubernetes applications CLI
- [`kbld`](https://github.com/k14s/kbld): Kubernetes builder

Tanzu Kubernetes Grid provides signed binaries for `ytt`, `kapp`, and `kbld` that are bundled with the Tanzu Kubernetes Grid CLI. For information about where to download the CLI bundle, see [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md). 

To deploy the extensions, you update configuration files with information about your environment. You then use `kubectl` to apply preconfigured YAML files that pull data from the updated configuration files to create and update clusters that implement the extensions. The YAML files include calls to `ytt`, `kapp`, and `kbld` commands, so these tools must be present on your bootstrap environment when you deploy the extensions.

1. Navigate to the location on your bootstrap environment machine where you saved the Tanzu Kubernetes Grid CLI bundle.

   The bundles are `tkg-darwin-amd64-v1.2.0-vmware.1` for Mac OS, `tkg-linux-amd64-v1.2.0-vmware.1` for Linux, and `tkg-windows-amd64-v1.2.0-vmware.1` for Windows.
1. Rename the YTT binary for your platform to `ytt`, make sure that it is executable, and add it to your `PATH`.
   
   - Mac OS and Linux platforms: 

       1. Move the binary into the `/usr/local/bin` folder and rename it to `ytt`.<pre>mv ./ytt-linux-amd64-v0.30.0+vmware.1 /usr/local/bin/ytt</pre> <pre>mv ./ytt-darwin-amd64-v0.30.0+vmware.1 /usr/local/bin/ytt</pre> 
       1. Make the file executable.<pre>chmod +x /usr/local/bin/ytt</pre>
   
   - Windows platforms:
   
        1. Create a new `Program Files\ytt` folder and copy the `ytt-windows-amd64-v0.30.0+vmware.1` binary into it. 
        1. Rename `ytt-windows-amd64-v0.30.0+vmware.1` to `ytt.exe`.
        1. Right-click the `ytt` folder, select **Properties** > **Security**, and make sure that your user account has the **Full Control** permission.
        1. Use Windows Search to search for `env`.
        1. Select **Edit the system environment variables** and click the **Environment Variables** button.
        1. Select the `Path` row under **System variables**, and click **Edit**. 
        1. Click **New** to add a new row and enter the path to the `ytt` binary.
1. At the command line in a new terminal, run `ytt version` to check that the correct version of the binary is properly installed.

   You should see information about the installed `ytt` version.
   
    ```
    ytt version 0.30.0
    ```
1. Rename the Kapp binary for your platform to `kapp`, make sure that it is executable, and add it to your `PATH`.
   
   - Mac OS and Linux platforms: 

       1. Move the binary into the `/usr/local/bin` folder and rename it to `kapp`.<pre>mv ./kapp-linux-amd64-v0.33.0+vmware.1 /usr/local/bin/kapp</pre> <pre>mv ./kapp-darwin-amd64-v0.33.0+vmware.1 /usr/local/bin/kapp</pre> 
       1. Make the file executable.<pre>chmod +x /usr/local/bin/kapp</pre>
   
   - Windows platforms:
   
        1. Create a new `Program Files\kapp` folder and copy the `kapp-windows-amd64-v0.33.0+vmware.1` binary into it. 
        1. Rename `kapp-windows-amd64-v0.33.0+vmware.1` to `kapp.exe`.
        1. Right-click the `kapp` folder, select **Properties** > **Security**, and make sure that your user account has the **Full Control** permission.
        1. Use Windows Search to search for `env`.
        1. Select **Edit the system environment variables** and click the **Environment Variables** button.
        1. Select the `Path` row under **System variables**, and click **Edit**. 
        1. Click **New** to add a new row and enter the path to the `kapp` binary.
1. At the command line in a new terminal, run `kapp version` to check that the correct version of the binary is properly installed.

   You should see information about the installed `kapp` version.
   
    ```
    kapp version 0.33.0
    ```
1. Rename the Kbld binary for your platform to `kbld`, make sure that it is executable, and add it to your `PATH`.
   
   - Mac OS and Linux platforms: 

       1. Move the binary into the `/usr/local/bin` folder and rename it to `kbld`.<pre>mv ./kbld-linux-amd64-v0.24.0+vmware.1 /usr/local/bin/kbld</pre> <pre>mv ./kbld-darwin-amd64-v0.24.0+vmware.1 /usr/local/bin/kbld</pre> 
       1. Make the file executable.<pre>chmod +x /usr/local/bin/kbld</pre>
   
   - Windows platforms:
   
        1. Create a new `Program Files\kbld` folder and copy the `kbld-windows-amd64-v0.24.0+vmware.1` binary into it. 
        1. Rename `kbld-windows-amd64-v0.24.0+vmware.1` to `kbld.exe`.
        1. Right-click the `kbld` folder, select **Properties** > **Security**, and make sure that your user account has the **Full Control** permission.
        1. Use Windows Search to search for `env`.
        1. Select **Edit the system environment variables** and click the **Environment Variables** button.
        1. Select the `Path` row under **System variables**, and click **Edit**. 
        1. Click **New** to add a new row and enter the path to the `kbld` binary.
1. At the command line in a new terminal, run `kbld version` to check that the correct version of the binary is properly installed.

   You should see information about the installed `kbld` version.
   
    ```
    kbld version 0.24.0
    ```
          
## <a id="internet-restricted"></a> Deploying the Tanzu Kubernetes Grid Extensions in an Internet Restricted Environment

For information about how to initially configure your environment and deploy management clusters and Tanzu Kubernetes clusters in an internet-restricted environment, see [Deploy Tanzu Kubernetes Grid to an Offline Environment](../mgmt-clusters/airgapped-environments.html).

If you are using Tanzu Kubernetes Grid in an internet-restricted environment, after you download and unpack the Tanzu Kubernetes Grid extensions bundle, you must edit the extension files so that Tanzu Kubernetes Grid pulls images from your local private Docker registry rather than from the external Internet.

1. Copy the unpacked folder of extensions manifests to the machine within your firewall on which you run the `tkg` CLI.
1. Use the search and replace utility of your choice to search recursively through the `tkg-extensions-v1.2.0+vmware.1` folder and replace `registry.tkg.vmware.run` with the address of your private Docker registry, for example `custom-image-repository.io/yourproject`.

After making this change, when you implement the Tanzu Kubernetes Grid extensions, images will be pulled from your local private Docker registry rather than from `registry.tkg.vmware.run`.