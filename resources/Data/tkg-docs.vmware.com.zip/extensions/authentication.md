# Implementing User Authentication with Dex and Gangway

You can deploy Tanzu Kubernetes clusters that implement authentication and authorization, so that only users with the correct permissions can access those clusters. If you implement authentication on Tanzu Kubernetes clusters, users with the correct permissions can use their identity provider (IDP) credentials to log in to a Web interface where they can download the `kubeconfig` for a given cluster. Tanzu Kubernetes Grid provides user authentication of clusters by implementing the open source [Dex](https://github.com/dexidp/dex/blob/master/README.md) and [Gangway](https://github.com/heptiolabs/gangway/blob/master/README.md) projects. 

The process to set up authentication with Dex and Gangway involves several stages:

1. [Deploy Dex on Management Clusters](dex.md)

    The IDP that you can use depends on the infrastructure on which your management cluster runs.
    
    |Infrastructure|Supported IDP|
    |---|---|
    |vSphere|LDAP or OIDC|
    |Amazon EC2|OIDC|
    |Azure|Secure LDAP|
    
    The IDP that you configure Dex to use is used by all of the clusters in your Tanzu Kubernetes Grid instance.
1. [Deploy an Authentication-Enabled Tanzu Kubernetes Cluster](deploy-auth-cluster.md)

    To use the Dex service you must deploy Tanzu Kubernetes clusters with an embedded OIDC endpoint. The OIDC endpoint allows the cluster to connect to your LDAP or OIDC server.
1. [Deploy Gangway on Tanzu Kubernetes Clusters ](gangway.md)

    Gangway is a Kubernetes authentication client that you install on each Tanzu Kubernetes cluster for which you want to implement authentication. Gangway generates a `kubeconfig` that allows clusters to use Dex to connect to your identity provider. 
    
    **IMPORTANT**: Tanzu Kubernetes Grid provides Gangway exclusively for use in combination with Dex and in the manner that is documented here. Any other use of the provided Gangway implementation is not supported.
1. [Log In to the Authentication-Enabled Tanzu Kubernetes Cluster to Obtain Its `kubeconfig`](connect-auth-cluster.md)

   Gangway exposes a Web-based endpoint on Tanzu Kubernetes clusters, to which end users can connect with their IDP credentials, in order to access the `kubeconfig` for the cluster.