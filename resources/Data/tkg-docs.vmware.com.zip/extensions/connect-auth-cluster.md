# Log In to the Authentication-Enabled Tanzu Kubernetes Cluster to Obtain Its `kubeconfig`

After you have deployed Dex on a management cluster and deployed Gangway on an authentication-enabled Tanzu Kubernetes cluster, users can use their credentials from your external identity provider (IDP) to connect to the cluster and download its `kubeconfig` file. 

- [Prerequisites](#prereqs)
- [Log In to the Authentication-Enabled Tanzu Kubernetes Cluster with Your IDP Credentials](#login)
- [Configuring Role-Based Access Control (RBAC)](#rbac)

## <a id="prereqs"></a> Prerequisites

You have deployed Dex on your management cluster and and Gangway on a Tanzu Kubernetes cluster by completing the appropriate steps in each of the following procedures:

- [Deploy Dex on Management Clusters](dex.md)
- [Deploy an Authentication-Enabled Tanzu Kubernetes Cluster](deploy-auth-cluster.md)
- [Deploy Gangway on Tanzu Kubernetes Clusters ](gangway.md)

If you use OIDC as your IDP with either vSphere or Amazon EC2, you might need to add the login URL to your IDP provider's allow list. For example, if your IDP is Okta, you must log in to your Okta account, go to the General Settings for your application, and add the URL of the Tanzu Kubernetes cluster to the **Login redirect URIs**.

## <a id="login"></a> Log In to the Authentication-Enabled Tanzu Kubernetes Cluster with Your IDP Credentials

Users access the authentication-enabled Tanzu Kubernetes clusters by logging in to a Web portal that the clusters expose. You can distribute the URL for a cluster to any users who need to access that cluster. The users can log in to the cluster provided that their IDP account has the correct permissions. For information about how to set permissions, see [Configuring Role-Based Access Control (RBAC)](#rbac) below.

1. In a browser, go to the address of the Tanzu Kubernetes cluster on which   Gangway is enabled.

   You obtain this address from the administrator who deployed the cluster. The format of the URL depends on the platform on which the cluster is running.

   - **vSphere**: Go to `https://<WORKLOAD_CLUSTER_IP>:30166`, replacing `<WORKLOAD_CLUSTER_IP>` with the static virtual IP address that you set when you deployed the cluster.
   - **Amazon EC2**: Go to `https://<GANGWAY_SVC_LB_HOSTNAME>`, replacing `<GANGWAY_SVC_LB_HOSTNAME>` with the address of the Gangway service load balancer that you obtained in [Obtain the Gangway Load Balancer for Amazon EC2](gangway.md#lb-aws).
   - **Azure**: Go to `https://<GANGWAY_SVC_LB_IP>`, replacing `<GANGWAY_SVC_LB_IP>` with the IP address of the Gangway service load balancer that you obtained in [Obtain the Gangway Load Balancer for Azure](gangway.md#lb-azure).
   
   Because the Dex and Gangway extensions use self-signed certificates, follow the browser prompts to accept the certificates.
   
1. On the Tanzu Kubernetes Grid Authentication page, click **Sign In**.

    ![Authenticated cluster welcome page](../images/dex-gangway-welcome.png)
    
    **NOTE**: If you see the message `securecookie: the value is not valid`, clear your session cookies, or open the URL in an incognito browser.
1. At the **Log in to Your Account** page, enter your credentials from your IDP.

   - If Dex uses LDAP on either vSphere or Azure, enter your LDAP credentials.

      ![Log in with LDAP](../images/dex-gangway-ldap.png)
   
   - If Dex uses OIDC on either vSphere or Amazon EC2, enter the credentials from your OIDC provider.

      For example, if your IDP is Okta, you will see the Okta log in page.
      
      ![Log in with OIDC](../images/dex-gangway-oidc.png)
1. Download the `kubeconfig` file of the Tanzu Kubernetes cluster so that you can access it by using `kubectl`.

   You can obtain the `kubeconfig` file either by following the command line instructions or by clicking the **Download Kubeconfig** button.
      
   ![Download Kubeconfig file](../images/dex-gangway-kubeconfig.png)
    
## <a id="rbac"></a> Configuring Role-Based Access Control (RBAC)

The `kubeconfig` that Gangway provides enables user authentication to clusters. For a user to be able to perform any type of create, reconfigure, update, or delete (CRUD) actions against the cluster, the appropriate cluster 
roles and role bindings must be defined. For information about configuring RBAC on clusters, see [Using RBAC Authorization](https://kubernetes.io/docs/reference/access-authn-authz/rbac) in the Kubernetes documentation.

The following example shows a cluster role binding that gives any user in an example group `cluster-admin` access.

```yaml
kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: <name>
subjects:
  - kind: Group
    name: <group-name>
    apiGroup: ""
roleRef:
  kind: ClusterRole #this must be Role or ClusterRole
  name: cluster-admin # this must match the name of the Role or ClusterRole you wish to bind to
  apiGroup: rbac.authorization.k8s.io
```
