# Deploy Grafana on Tanzu Kubernetes Clusters
 
## <a id="prereqs"></a> Prerequisites

There are a few prerequisites you must satisfy before you can deploy the Grafana extension onto your Tanzu Kubernetes clusters:

- You have downloaded and unpacked the bundle of Tanzu Kubernetes Grid extensions. For information about where to obtain the bundle, see [Download and Unpack the Tanzu Kubernetes Grid Extensions Bundle](index.md#unpack-bundle).
- You have installed the Carvel tools. For information about installing the Carvel tools, see [Install the Carvel Tools on the Bootstrap Environment](index.md#install-carvel).
- You have deployed a management cluster on vSphere, Amazon EC2, or Azure.
- You have deployed a Tanzu Kubernetes cluster. The examples in this topic use a cluster named `monitoring-cluster`.
- You have installed Prometheus on the Tanzu Kubernetes cluster. For information on installing Prometheus, see [Deploy Prometheus on Tanzu Kubernetes Clusters](prometheus.md).
- You have installed Contour for ingress control on the Tanzu Kubernetes cluster. For information on installing Contour, see [Implementing Ingress Control with Contour](ingress-contour.md).

**IMPORTANT**: Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this section.

## <a id="prepare-tkc"></a> Prepare the Tanzu Kubernetes Cluster for the Grafana Extension

The first step in deploying the Grafana extension is preparing the specific Tanzu Kubernetes cluster where you will deploy the extension. There are a few supporting applications that must be installed on the Tanzu Kubernetes cluster first. If you have already installed another extension onto this Tanzu Kubernetes cluster&mdash;like the Prometheus extension, for example&mdash;you can skip this section and proceed directly to [Prepare the Configuration File for the Grafana Extension](#config).

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. In a terminal, navigate to the folder that contains the unpacked Tanzu Kubernetes Grid extension manifest files, `tkg-extensions-v1.2.0+vmware.1`.

    You should see folders including `authentication`, `bom`, `cert-manager`, `extensions`, `ingress`, `monitoring`, and so on, as well as some YAML files. Run all of the commands in these procedures from this location.

1. Get the credentials of the cluster.

    ```
    tkg get credentials monitoring-cluster
    ```

1. Set the context of kubectl to the cluster.

    ```
    kubectl config use-context monitoring-cluster-admin@monitoring-cluster
    ```

1. Install the VMware Tanzu Mission Control extension manager on the Tanzu Kubernetes cluster.

    The Tanzu Kubernetes Grid extensions and Tanzu Mission Control both use the same extensions manager service. You must install the extensions manager even if you do not intend to use Tanzu Mission Control.

    ```
    kubectl apply -f extensions/tmc-extension-manager.yaml
    ```

    You should see confirmation that a namespace, resource definitions, a service account, an RBAC role, and a role binding for the `extension-manager` service are all created.

    ```
    namespace/vmware-system-tmc created
    customresourcedefinition.apiextensions.k8s.io/agents.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensions.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionresourceowners.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionintegrations.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionconfigs.intents.tmc.cloud.vmware.com created
    serviceaccount/extension-manager created
    clusterrole.rbac.authorization.k8s.io/extension-manager-role created
    clusterrolebinding.rbac.authorization.k8s.io/extension-manager-rolebinding created
    service/extension-manager-service created
    deployment.apps/extension-manager created
    ```

    Note that you can disregard any warning messages about deprecated APIs, if they appear.

1. Install the Kapp controller on the Tanzu Kubernetes cluster.

    ```
    kubectl apply -f extensions/kapp-controller.yaml
    ```

    You should see confirmation that a service account, resource definition, and RBAC role are created for the `kapp-controller` service.

    ```
    serviceaccount/kapp-controller-sa created
    customresourcedefinition.apiextensions.k8s.io/apps.kappctrl.k14s.io created
    deployment.apps/kapp-controller created
    clusterrole.rbac.authorization.k8s.io/kapp-controller-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/kapp-controller-cluster-role-binding created
    ```

1. Deploy `cert-manager`, which provides automated certificate management, on the Tanzu Kubernetes cluster.

    ```
    kubectl apply -f cert-manager/
    ```

1. Check that the Tanzu Mission Control extension manager, the Kapp controller, and cert-manager are running by listing all of the pods that are running in the Tanzu Kubernetes cluster.

    ```
    kubectl get pods -A
    ```

    In the `vmware-system-tmc` namespace, you should see running `extension-manager` and `kapp-controller` pods with names similar to `extension-manager-7cbdf7cbf9-xzrbn` and `kapp-controller-cd55bbd6b-vt2c4`.

    Similarly, in the `cert-manager` namespace, you should see running pods with names like `cert-manager-69877b5f94-8kwx9`, `cert-manager-cainjector-7594d76f5f-8tstw`, and `cert-manager-webhook-5fc8c6dc54-nlvzp`.

    The `Ready` status for all of these pods should show 1/1; if that is not the case, stop and troubleshoot these pods before proceeding.

The Tanzu Kubernetes cluster is now ready for you to deploy the Grafana extension. For the next steps, see [Prepare the Configuration Files for the Grafana Extension](#config).

## <a id="config"></a> Prepare the Configuration File for the Grafana Extension

Before you can deploy the Grafana extension, you must first prepare the necessary configuration file.

This step applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Make a copy of the `grafana-data-values.yaml.example` file for your infrastructure platform, and name the file `grafana-data-values.yaml`.

    **vSphere:**
    ```sh
    cp extensions/monitoring/grafana/vsphere/grafana-data-values.yaml.example extensions/monitoring/grafana/vsphere/grafana-data-values.yaml
    ```

    **Amazon EC2:**
    ```sh
    cp extensions/monitoring/grafana/aws/grafana-data-values.yaml.example extensions/monitoring/grafana/aws/grafana-data-values.yaml
    ```

    **Azure:**
    ```sh
    cp extensions/monitoring/grafana/azure/grafana-data-values.yaml.example extensions/monitoring/grafana/azure/grafana-data-values.yaml
    ```

1. Edit the `grafana-data-values.yaml` file and replace `<ADMIN_PASSWORD>` with a Base64 encoded password. 

   To generate a Base64 encoded password, run the following command:
   
   ```
   echo -n 'mypassword' | base64
   ```
   
   You can also use the Base64 encoding tool at [https://www.base64encode.org/](https://www.base64encode.org/) to encode your password. For example, for either method, a password of `mypassword` results in the encoded password `bXlwYXNzd29yZA==`. Save `grafana-data-values.yaml` when you are finished.

1. If you wish to deploy the Grafana extension with default values, proceed directly to [Deploy the Grafana Extension to a Tanzu Kubernetes Cluster](#deploy). Otherwise, follow the remaining steps below.

1. Add configuration values to `grafana-data-values.yaml` to customize the configuration. Available configuration values are provided in [Customize the Configuration of the Grafana Extension](#customize). By default, `grafana-data-values.yaml` will contain _only_ information on the infrastructure provider and the default administrative password.

1. When you are finished, save your changes.

For the next steps, proceed to [Deploy the Grafana Extension to a Tanzu Kubernetes Cluster](#deploy).

## <a id="deploy"></a> Deploy the Grafana Extension to a Tanzu Kubernetes Cluster

After the Tanzu Kubernetes cluster has been prepared with the necessary supporting applications and you have updated the configuration file, you can deploy the Grafana extension.

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Create the namespace and RBAC roles for Grafana.

    ```sh
    kubectl apply -f extensions/monitoring/grafana/namespace-role.yaml
    ```

    You should see confirmation that a `tanzu-system-monitoring` namespace, service account, and RBAC role bindings are created for Grafana.

    ```
    namespace/tanzu-system-monitoring unchanged
    serviceaccount/grafana-extension-sa created
    role.rbac.authorization.k8s.io/grafana-extension-role created
    rolebinding.rbac.authorization.k8s.io/grafana-extension-rolebinding created
    clusterrole.rbac.authorization.k8s.io/grafana-extension-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/grafana-extension-cluster-rolebinding created
    ```

    In this case, you'll notice that the output states `namespace/tanzu-system-monitoring unchanged`. This is an example of output you would see if you have already deployed the Prometheus extension, which is likely going to be the case (Grafana uses Prometheus as its datasource). If you were installing Grafana first, then this output would show `namespace/tanzu-system-monitoring created` instead.

1. Create a Kubernetes secret that encodes the values stored in the `grafana-data-values.yaml` configuration file.

    **vSphere:**
    ```
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/vsphere/grafana-data-values.yaml
    ```

    **Amazon EC2:**
    ```
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/aws/grafana-data-values.yaml
    ```

    **Azure:**
    ```
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/azure/grafana-data-values.yaml
    ```

1. Deploy the Grafana extension.

    ```
    kubectl apply -f extensions/monitoring/grafana/grafana-extension.yaml
    ```

    You should see a confirmation that `extensions.clusters.tmc.cloud.vmware.com/grafana` was created.

1. The extension will take several minutes to complete the deployment. To check on the status of the deployment, use the `kubectl -n tanzu-system-monitoring get extension` and `kubectl -n tanzu-system-monitoring get app` commands:

    ```
    kubectl -n tanzu-system-monitoring get extension grafana
    kubectl -n tanzu-system-monitoring get app grafana
    ```

    When the extension is still in the process of deploying, the "Description" field from the `kubectl get app` command will show `Reconciling`. Once Grafana is deployed successfully, the app status (as shown by the `kubectl get app` command above) should change to `Reconcile succeeded`. The output of the `kubectl get extension` command does not change.

    You can view detailed status information with this command:

    ```
    kubectl get app prometheus -n tanzu-system-monitoring -o yaml
    ```

By default, the Grafana extension requires Contour to be present (this is noted in [Prerequisites](#prereqs) above), and creates a Contour HTTPProxy object with an FQDN of `grafana.system.tanzu`. To use this FQDN to access the Grafana dashboard, create an entry in your local `/etc/hosts` file (on macOS or Linux) that points this FQDN to the IP address of the LoadBalancer for the Envoy service in the `tanzu-system-ingress` namespace (on AWS or Azure) or the IP address of a worker node (on vSphere). You can then use a browser to navigate to `https://grafana.system.tanzu` (because the site uses self-signed certificates, you may need to navigate through a security warning before you are able to access the dashboard).

## <a id="update"></a> Update a Running Grafana Extension

If you need to make changes to the Grafana extension after it has been deployed, you will need to update the Kubernetes secret the extension uses for its configuration. The steps below describe how to update the Kubernetes secret and, accordingly, update the configuration of the Grafana extension.

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Locate the `grafana-data-values.yaml` file you created in the [Prepare the Configuration File for the Grafana Extension](#config). You will need to make your changes to this file. If you no longer have this file, you can recreate it with the following `kubectl` command:

    <pre>
    kubectl -n tanzu-system-monitoring get secret grafana-data-values -o 'go-template=&lbrace;&lbrace; index .data "values.yaml" &rbrace;&rbrace;' | base64 -d > grafana-data-values.yaml
    </pre>

    Note that macOS users will need to use the `-D` parameter to `base64`, instead of the lowercase `-d` shown above.

1. Using the information in [Customize the Configuration of the Grafana Extension](#customize) as reference, make the necessary changes to the `grafana-data-values.yaml` file.

    Once you have made all applicable changes, save the file.

1. Update the Kubernetes secret created in the [Deploy the Grafana Extension to a Tanzu Kubernetes Cluster](#deploy) using this command:

    **vSphere:**
    ```sh
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/vsphere/grafana-data-values.yaml -o yaml --dry-run=client | kubectl replace -f -
    ```

    **Amazon EC2:**
    ```sh
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/aws/grafana-data-values.yaml -o yaml --dry-run=client | kubectl replace -f -
    ```

    **Azure:**
    ```sh
    kubectl -n tanzu-system-monitoring create secret generic grafana-data-values --from-file=values.yaml=extensions/monitoring/grafana/azure/grafana-data-values.yaml -o yaml --dry-run=client | kubectl replace -f -
    ```

    Note that the final `-` on the `kubectl replace` command above is necessary to instruct `kubectl` to accept the input being piped to it from the `kubectl create secret` command.

1. The Grafana extension will be reconciled using the new values you just added. The changes should show up in five minutes or less (this is handled by the Kapp controller, which syncs every five minutes).

    If you need the changes to the configuration reflected more quickly, you can delete the Grafana pod using `kubectl delete pod`. The pod will be recreated via the Kapp controller with the new settings. You can also change `syncPeriod` in `grafana-extension.yaml` to a lesser value and re-apply the configuration with `kubectl apply -f grafana-extension.yaml`.

## <a id="customize"></a> Customize the Configuration of the Grafana Extension

If you need to change or alter the configuration of the Grafana extension, you'll need to edit the `extensions/monitoring/grafana/<platform>/grafana-data-values.yaml` file. If you modify this file _before_ you deploy the extension, the settings will take effect immediately upon deployment. If you modify this file _after_ you deploy the Grafana extension, you'll need to follow the steps in [Update a Running Grafana Extension](#update).

The supported configuration settings---and their default values---that can go into the `extensions/monitoring/grafana/<platform>/grafana-data-values.yaml` file are explained in the following table.

| Parameter | Description | Type | Default |
|-----------|-------------|------|---------|
| infrastructure_provider | Name of the infrastructure provider. Supported values: vsphere, aws, azure | string | vsphere, aws, azure |
| monitoring.namespace | Namespace where Grafana will be deployed | string | tanzu-system-monitoring |
| monitoring.create_namespace | The flag indicates whether to create the namespace specified by monitoring.namespace | boolean | false |
| monitoring.grafana.cluster_role.apiGroups | API group defined for Grafana ClusterRole | list | [""] |
| monitoring.grafana.cluster_role.resources | Resources defined for Grafana ClusterRole | list | ["configmaps", "secrets"] |
| monitoring.grafana.cluster_role.verbs | Access permission defined for ClusterRole | list | ["get", "watch", "list"] |
| monitoring.grafana.config.grafana_ini | Grafana configuration file details | config file | grafana.ini |
| monitoring.grafana.config.datasource.type | Grafana datasource type          | string | prometheus |
| monitoring.grafana.config.datasource.access | Access mode, proxy or direct (Server or Browser in the UI) | string | proxy |
| monitoring.grafana.config.datasource.isDefault | Flag to mark the default Grafana datasource | boolean | true |
| monitoring.grafana.config.provider_yaml | Config file to define Grafana dashboard provider | YAML file | provider.yaml |
| monitoring.grafana.service.type  | Type of Kubernetes Service to expose Grafana. Supported values: ClusterIP, NodePort, LoadBalancer | string | vSphere: NodePort, AWS/Azure: LoadBalancer |
| monitoring.grafana.pvc.storage_class | StorageClass to use for Persistent Volume Claim. By default this is null and default provisioner is used | string | null |
| monitoring.grafana.pvc.accessMode| Define access mode for Persistent Volume Claim. Supported values: ReadWriteOnce, ReadOnlyMany, ReadWriteMany | string | ReadWriteOnce |
| monitoring.grafana.pvc.storage | Define storage size for Persistent Volume Claim | string | 2Gi |
| monitoring.grafana.deployment.replicas | Number of Grafana replicas | integer | 1 |
| monitoring.grafana.image.repository| Repository containing the Grafana image | string | registry.tkg.vmware.run/grafana |
| monitoring.grafana.image.name | Name of the Grafana image | string | grafana |
| monitoring.grafana.image.tag | Image tag of the Grafana image | string | v7.0.3_vmware.1 |
| monitoring.grafana.image.pullPolicy | Image pull policy for the Grafana image | string | IfNotPresent |
| monitoring.grafana.secret.type | Secret type defined for Grafana dashboard | string | Opaque |
| monitoring.grafana.secret.admin_user | Username to access the Grafana dashboard | string | YWRtaW4= ('admin' in Base64 encoding) |
| monitoring.grafana.secret.admin_password | Password to access Grafana dashboard | string | null |
| monitoring.grafana.secret.ldap_toml | If using LDAP authentication, LDAP configuration file path | string | "" |
| monitoring.grafana_init_container.image.repository | Repository containing the Grafana init container image | string | registry.tkg.vmware.run/grafana |
| monitoring.grafana_init_container.image.name| Name of the Grafana init container image | string | k8s-sidecar |
| monitoring.grafana_init_container.image.tag | Image tag of the Grafana init container image | string | 0.1.99 |
| monitoring.grafana_init_container.image.pullPolicy | Image pull policy for the Grafana init container image | string | IfNotPresent |
| monitoring.grafana_sc_dashboard.image.repository | Repository containing the Grafana dashboard image | string | registry.tkg.vmware.run/grafana |
| monitoring.grafana_sc_dashboard.image.name | Name of the Grafana dashboard image | string | k8s-sidecar |
| monitoring.grafana_sc_dashboard.image.tag | Image tag of the Grafana dashboard image | string | 0.1.99 |
| monitoring.grafana_sc_dashboard.image.pullPolicy | Image pull policy for the Grafana dashboard image | string | IfNotPresent |
| monitoring.grafana.ingress.enabled | Enable/disable ingress for Grafana | boolean | true |
| monitoring.grafana.ingress.virtual_host_fqdn | Hostname for accessing Grafana | string | grafana.system.tanzu |
| monitoring.grafana.ingress.prefix| Path prefix for grafana | string | / |
| monitoring.grafana.ingress.tlsCertificate.tls.crt  | Optional certificate for ingress if you want to use your own TLS certificate; a self-signed certificate is generated by default | string  | Generated certificate |
| monitoring.grafana.ingress.tlsCertificate.tls.key  | Optional certificate private key for ingress if you want to use your own TLS certificate | string | Generated certificate private key |

By default, the `grafana-data-values.yaml` file contains _only_ information on the selected infrastructure provider and the default administrative password. All other values will use the default settings from the table above.

## <a id="remove"></a> Remove the Grafana Extension

For information on how to remove the Grafana extension from a Tanzu Kubernetes cluster, see the [Delete Tanzu Kubernetes Grid Extensions](delete-extensions#observability) section.
