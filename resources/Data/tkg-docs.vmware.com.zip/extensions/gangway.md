# Deploy Gangway on Tanzu Kubernetes Clusters  

Tanzu Kubernetes Grid includes signed binaries for Gangway. Gangway is the Kubernetes authentication helper that you install on each Tanzu Kubernetes cluster for which you want to implement authentication. It allows users to use their IDP credentials to access Tanzu Kubernetes clusters that have been configured to use Dex as their OIDC server.

**IMPORTANT**: Tanzu Kubernetes Grid provides Gangway exclusively for use in combination with Dex and in the manner that is documented here. Any other use of the provided Gangway implementation is not supported.

- [Prerequisites](#prereqs)
- [Prepare the Tanzu Kubernetes Cluster for Gangway Deployment](#prepare-tkc)
- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on vSphere](#vsphere)
- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Amazon EC2](#aws)
- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Azure](#azure)
- [Deploy Gangway on the Tanzu Kubernetes Cluster](#deploy-gangway)
- [Obtain the Gangway Load Balancer for Amazon EC2](#lb-aws)
- [Obtain the Gangway Load Balancer for Azure](#lb-azure)
- [Register Gangway with the Dex Service](#register-gangway)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

- You have completed the appropriate procedures in [Deploy Dex on Management Clusters](dex.md) to deploy Dex on a management cluster that is running on  vSphere, Amazon EC2, or Azure. The examples in this topic use a management cluster named `auth-mgmt-cluster`.
- You have deployed a Tanzu Kubernetes cluster with an OIDC endpoint, as described in [Deploy an Authentication-Enabled Tanzu Kubernetes Cluster](deploy-auth-cluster.md). The examples in this topic use a Tanzu Kubernetes cluster named `auth-cluster`.
- Run all of the commands in this procedure from the folder that contains the unpacked Tanzu Kubernetes Grid extension manifest files, `tkg-extensions-v1.2.0+vmware.1/extensions`.

## <a id="prepare-tkc"></a> Prepare the Tanzu Kubernetes Cluster for Gangway Deployment

Before you can deploy Gangway on an authentication-enabled Tanzu Kubernetes cluster, you must install the tools that the Gangway extension requires. 

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. While the context of `kubectl` is still set to the management cluster, obtain the CA certificate of the Dex service.

   <pre>
   kubectl get secret dex-cert-tls -n tanzu-system-auth -o 'go-template=&lbrace;&lbrace; index .data "ca.crt" &rbrace;&rbrace;' | base64 -d
   </pre>
   Record the output. You will need it later.
   
1. Get the credentials of the authentication-enabled cluster.

   ```
   tkg get credentials auth-cluster
   ```

1. Set the context of `kubectl` to the authentication-enabled cluster.

   ```
   kubectl config use-context auth-cluster-admin@auth-cluster
   ```
1. Install the VMware Tanzu Mission Control extension manager on the Tanzu Kubernetes cluster.

    The Tanzu Kubernetes Grid extensions and Tanzu Mission Control both use the same extensions manager service. You must install the extensions manager even if you do not intend to use Tanzu Mission Control.
    ```sh
    kubectl apply -f tmc-extension-manager.yaml
    ```
    You should see confirmation that a namespace, resource definitions, a service account, an RBAC role, and a role binding for the `extension-manager` service are all created.
    
    ```
    namespace/vmware-system-tmc created
    customresourcedefinition.apiextensions.k8s.io/agents.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensions.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionresourceowners.clusters.tmc.cloud.vmware.com created
    customresourcedefinition.apiextensions.k8s.io/extensionconfigs.intents.tmc.cloud.vmware.com created
    serviceaccount/extension-manager created
    clusterrole.rbac.authorization.k8s.io/extension-manager-role created
    clusterrolebinding.rbac.authorization.k8s.io/extension-manager-rolebinding created
    service/extension-manager-service created
    deployment.apps/extension-manager created
    ```

1. Install the Kapp controller on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f kapp-controller.yaml
    ```
    You should see confirmation that a service account, resource definition, and RBAC role are created for the `kapp-controller` service.
    
    ```
    serviceaccount/kapp-controller-sa created
    customresourcedefinition.apiextensions.k8s.io/apps.kappctrl.k14s.io created
    deployment.apps/kapp-controller created
    clusterrole.rbac.authorization.k8s.io/kapp-controller-cluster-role created
    clusterrolebinding.rbac.authorization.k8s.io/kapp-controller-cluster-role-binding created
    ```
    
1. Deploy `cert-manager`, which provides automated certificate management, on the Tanzu Kubernetes cluster.

   ```sh
   kubectl apply -f cert-manager/
   ```
1. Create a namespace for the Gangway service on the Tanzu Kubernetes cluster.

    ```sh
    kubectl apply -f authentication/gangway/namespace-role.yaml
    ```
    You should see confirmation that a `tanzu-system-auth` namespace, service account, and RBAC role bindings are created.
    ```
    namespace/tanzu-system-auth created
    serviceaccount/gangway-extension-sa created
    role.rbac.authorization.k8s.io/gangway-extension-role created
    rolebinding.rbac.authorization.k8s.io/gangway-extension-rolebinding created
    ```
1. Check that the new services are running by listing all of the pods that are running in the Tanzu Kubernetes cluster. 

   ```
   kubectl get pods -A
   ```   

   In the `tanzu-system-tmc` namespace, you should see the `extension-manager` and `kapp-controller` services running in a pod with  names similar to `extension-manager-7cbdf7cbf9-xzrbn` and `kapp-controller-cd55bbd6b-vt2c4`.
   
   ```
    NAMESPACE              NAME                                  READY   STATUS    RESTARTS   AGE
    [...]
    vmware-system-tmc      extension-manager-7cbdf7cbf9-xzrbn    1/1     Running   0          52s
    vmware-system-tmc      kapp-controller-cd55bbd6b-vt2c4       1/1     Running   0          40s
    ```   
1. Use `openssl` to create a client secret and session key for the Gangway service.

   Run both of the following commands:

   ```
   CLIENT_SECRET=$(openssl rand -hex 16)
   ```
   
   ```   
   SESSION_KEY=$(openssl rand -hex 16)
   ```
1. Display the values of the client secret and session key variables.   

   Run both of the following commands and record the output. You will need it later.

   ```
   echo $CLIENT_SECRET
   ```
   
   ```   
   echo $SESSION_KEY
   ``` 
   
The Tanzu Kubernetes cluster is ready for you to deploy the Gangway service. For the next steps, see the procedure that corresponds to the infrastructure in which your Tanzu Kubernetes cluster is running:

- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on vSphere](#vsphere)
- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Amazon EC2](#aws)
- [Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Azure](#azure)

## <a id="vsphere"></a> Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on vSphere

This procedure describes how to update the configuration file to enable Gangway on authentication-enabled clusters that you have deployed to vSphere.

1. Make a copy of the `gangway-data-values.yaml.example` file and name it `gangway-data-values.yaml`.

   You use the same `gangway-data-values.yaml` file for connections to both LDAP servers and to OIDC providers.
   
    ```
    cp authentication/gangway/vsphere/gangway-data-values.yaml.example authentication/gangway/vsphere/gangway-data-values.yaml
    ```
1. Update the configuration file with information about your management cluster and the authentication-enabled Tanzu Kubernetes cluster.

    - `gangway.config.clusterName`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled Tanzu Kubernetes cluster.
    - `gangway.config.MGMT_CLUSTER_IP`: Replace `<MGMT_CLUSTER_VIP>` with the static virtual IP address of the management cluster.
    - `gangway.config.clientID`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled Tanzu Kubernetes cluster.
    - `gangway.config.APISERVER_URL`: Replace `<WORKLOAD_CLUSTER_VIP>` with the static virtual IP address of the authentication-enabled Tanzu Kubernetes cluster.
    - `gangway.secret.sessionKey`: Replace `<SESSION_KEY>` with the session key for the Gangway service that you obtained in the preceding procedure.
    - `gangway.secret.clientSecret`: Replace `<CLIENT_SECRET>` with the client secret for the Gangway service that you obtained in the preceding procedure.
    - `dns.vsphere.ipAddresses`: Replace `<WORKLOAD_CLUSTER_VIP>` with the static virtual IP address of the authentication-enabled Tanzu Kubernetes cluster.
    - `dex.ca`: Replace `<INSERT_DEX_CA_CERT>` with the contents of the CA file for the Dex service that you obtained in [Prepare the Tanzu Kubernetes Cluster for Gangway Deployment](#prepare-tkc) above.
   
      **IMPORTANT**: Make sure that the CA file contents are indented by exactly 4 spaces. If the indentation is incorrect, the Kapp controller will not deploy the extension.
   
   For example:
    
    ```
    #@data/values
    #@overlay/match-child-defaults missing_ok=True
    ---
    infrastructure_provider: "vsphere"
    gangway:
      config:
        clusterName: auth-cluster
        MGMT_CLUSTER_IP: 192.168.100.55
        clientID: auth-cluster
        APISERVER_URL: 192.168.100.11
      secret:
        sessionKey: 02ab7df041fdfeace3952d7d832db6f9
        clientSecret: 7b0fb0244d7eb28da0db39a3588b23eb
    dns:
      vsphere:
        #@overlay/replace
        ipAddresses: [192.168.100.11]
    dex:
      ca: | 
        -----BEGIN CERTIFICATE-----
        MIIDJjCCAg6gAwIBAgIRAJ7NE8QscfIGDyiSOeqwGPYwDQYJKoZIhvcNAQELBQAw
        IzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQDEwd0a2ctZGV4MB4XDTIwMDkzMDA4
        NDcxMFoXDTIwMTIyOTA4NDcxMFowIzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQD
        Ewd0a2ctZGV4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxxc+i/Cq
        qw2pr4puhy7rllNIUWsRGnxXPiqWdCMpIo1W0HQNtf65SMxU/7NwyHOSdRzz6XGL
        0BEdLv9IrO/BkDazg1WsTr2S6jTpH2CbJ2S5vmIW/3IIhr5rcQXVM5cWnKSpitRc
        8Q7kHHg53kCpRFyGFpGQvWPlHxxsJAqp6axV7konSpWqsyQmMVuEuD1VnJUeHLpa
        Za6ySdp4AwNzgIkwAKrza8TXkQZ3uL8uxH7JWgIrzXEqIfyRDxRiYYBqMOOorC0Z
        Ef46GgS0z8RGcFmwHJwVjwN0vs2EUbNiqsvgBUTZWrqpKaDQd2q9ciTYXR57YC+5
        Qxd5JmMpT4ssHwIDAQABo1UwUzAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUH
        AwIwDAYDVR0TAQH/BAIwADAkBgNVHREEHTAbggt0a2ctZGV4LmNvbYIMMjAuNTQu
        MjI2LjQyMA0GCSqGSIb3DQEBCwUAA4IBAQAp2eKubjZzYo4OAvBgqXje8PJOurmG
        B9vU5HpmqSO1GqAt6SJuiWgXbFeJmiZ4aDlAucVtwINPLnPYXunE9BZ0QQvUyozD
        pAbHdoLjvhf8srZV58cXr41OVs2lodFFymIt4PHvlZ3UuCXqMC2Nn9bowCTjmgMx
        u+iHem5/vWGASd37z0WmiwiwKzPbJNfGDhQY9I7WKOaL+azQBAiwjMWxUf+OLau7
        VFVtYD65uztsqU4wWoA3UswAP0dcJlRN0P5XQlxW/+ecVj8Kn0vFqGkMGCZTJCsW
        suqxb/OkRO5+EkOhwK8kpx+kHKce5/Olvp4Kcog62XMrfqLhn1Kg4eXR
        -----END CERTIFICATE-----
    ```
1. Save the updated `gangway-data-values.yaml` file.
1. Create a Kubernetes secret named `gangway-data-values` with the values that you set in `gangway-data-values.yaml`.

   ```
   kubectl create secret generic gangway-data-values --from-file=values.yaml=authentication/gangway/vsphere/gangway-data-values.yaml -n tanzu-system-auth
   ```   

For the next steps, see [Deploy Gangway on the Tanzu Kubernetes Cluster](#deploy-gangway).

## <a id="aws"></a> Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Amazon EC2

This procedure describes how to update the configuration file to enable Gangway on authentication-enabled clusters that you have deployed to Amazon EC2.

1. Make a copy of the `gangway-data-values.yaml.example` file and name it `gangway-data-values.yaml`.
   
    ```
    cp authentication/gangway/aws/gangway-data-values.yaml.example authentication/gangway/aws/gangway-data-values.yaml
    ```
1. Update the configuration file with information about your management cluster and the authentication-enabled Tanzu Kubernetes cluster.

   - `gangway.config.clusterName`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled cluster.
   - `gangway.config.DEX_SVC_LB_HOSTNAME`: Replace `<DEX_SVC_LB_HOSTNAME>` with the host name of the Dex service load balancer that is running in the management cluster, that you identified in [Obtain the Dex Load Balancer for Amazon EC2](dex.md#lb-aws).
   - `gangway.config.clientID`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled Tanzu Kubernetes cluster.
   - `gangway.config.APISERVER_URL`: Replace `<API_SERVER_LB_HOSTNAME>` with the host name of the Kubernetes API Server endpoint for the Tanzu Kubernetes cluster. This is the DNS name of the AWS load balancer, that has a name like `auth-cluster-apiserver-1506126946.us-west-2.elb.amazonaws.com`. You can find this DNS name in the **Load Balancers** view of your EC2 Dashboard.
    - `gangway.secret.sessionKey`: Replace `<SESSION_KEY>` with the session key for the Gangway service that you obtained in the preceding procedure.
    - `gangway.secret.clientSecret`: Replace `<CLIENT_SECRET>` with the client secret for the Gangway service that you obtained in the preceding procedure.
   - `dns.aws.GANGWAY_SVC_LB_HOSTNAME`: Do not update `<GANGWAY_SVC_LB_HOSTNAME>` yet. The Gangway service load balancer is created when you deploy the Gangway service, so you must update this value after you have deployed Gangway.
   - `dex.ca`: Replace `<INSERT_DEX_CA_CERT>` with the contents of the CA file for the Dex service that you obtained in [Prepare the Tanzu Kubernetes Cluster for Gangway Deployment](#prepare-tkc) above. 
   
      **IMPORTANT**: Make sure that the CA file contents are indented by exactly 4 spaces. If the indentation is incorrect, the Kapp controller will not deploy the extension.
   
   For example:
   
    ```
    #@data/values
    #@overlay/match-child-defaults missing_ok=True
    ---
    infrastructure_provider: "aws"
    gangway:
      config:
        clusterName: auth-cluster
        DEX_SVC_LB_HOSTNAME: aff037c12897xxxxxxxxxxxxxxf7668d-1246768892.us-west-2.elb.amazonaws.com
        clientID: auth-cluster
        APISERVER_URL: auth-cluster-apiserver-xxxxxxxxxx.us-west-2.elb.amazonaws.com
      secret:
        sessionKey: 02ab7df041fdfeace3952d7d832db6f9
        clientSecret: 7b0fb0244d7eb28da0db39a3588b23eb
    dns:
      aws:
        GANGWAY_SVC_LB_HOSTNAME: <GANGWAY_SVC_LB_HOSTNAME>
    
    dex:
      ca: | 
        -----BEGIN CERTIFICATE-----
        MIIDJjCCAg6gAwIBAgIRAJ7NE8QscfIGDyiSOeqwGPYwDQYJKoZIhvcNAQELBQAw
        IzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQDEwd0a2ctZGV4MB4XDTIwMDkzMDA4
        NDcxMFoXDTIwMTIyOTA4NDcxMFowIzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQD
        Ewd0a2ctZGV4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxxc+i/Cq
        qw2pr4puhy7rllNIUWsRGnxXPiqWdCMpIo1W0HQNtf65SMxU/7NwyHOSdRzz6XGL
        0BEdLv9IrO/BkDazg1WsTr2S6jTpH2CbJ2S5vmIW/3IIhr5rcQXVM5cWnKSpitRc
        8Q7kHHg53kCpRFyGFpGQvWPlHxxsJAqp6axV7konSpWqsyQmMVuEuD1VnJUeHLpa
        Za6ySdp4AwNzgIkwAKrza8TXkQZ3uL8uxH7JWgIrzXEqIfyRDxRiYYBqMOOorC0Z
        Ef46GgS0z8RGcFmwHJwVjwN0vs2EUbNiqsvgBUTZWrqpKaDQd2q9ciTYXR57YC+5
        Qxd5JmMpT4ssHwIDAQABo1UwUzAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUH
        AwIwDAYDVR0TAQH/BAIwADAkBgNVHREEHTAbggt0a2ctZGV4LmNvbYIMMjAuNTQu
        MjI2LjQyMA0GCSqGSIb3DQEBCwUAA4IBAQAp2eKubjZzYo4OAvBgqXje8PJOurmG
        B9vU5HpmqSO1GqAt6SJuiWgXbFeJmiZ4aDlAucVtwINPLnPYXunE9BZ0QQvUyozD
        pAbHdoLjvhf8srZV58cXr41OVs2lodFFymIt4PHvlZ3UuCXqMC2Nn9bowCTjmgMx
        u+iHem5/vWGASd37z0WmiwiwKzPbJNfGDhQY9I7WKOaL+azQBAiwjMWxUf+OLau7
        VFVtYD65uztsqU4wWoA3UswAP0dcJlRN0P5XQlxW/+ecVj8Kn0vFqGkMGCZTJCsW
        suqxb/OkRO5+EkOhwK8kpx+kHKce5/Olvp4Kcog62XMrfqLhn1Kg4eXR
        -----END CERTIFICATE-----
    ```
1. Save the updated `gangway-data-values.yaml` file.
1. Create a Kubernetes secret named `gangway-data-values` with the values that you set in `gangway-data-values.yaml`.

   ```
   kubectl create secret generic gangway-data-values --from-file=values.yaml=authentication/gangway/aws/gangway-data-values.yaml -n tanzu-system-auth
   ```
   
For the next steps, see [Deploy Gangway on the Tanzu Kubernetes Cluster](#deploy-gangway).

## <a id="azure"></a> Update the Gangway Configuration File for a Tanzu Kubernetes Cluster Running on Azure

This procedure describes how to update the configuration file to enable Gangway on authentication-enabled clusters that you have deployed to Azure.

1. Make a copy of the `gangway-data-values.yaml.example` file and name it `gangway-data-values.yaml`.
   
    ```
    cp authentication/gangway/azure/gangway-data-values.yaml.example authentication/gangway/azure/gangway-data-values.yaml
    ```
1. Update the configuration file with information about your management cluster and the authentication-enabled Tanzu Kubernetes cluster.

   - `gangway.config.clusterName`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled cluster.
   - `gangway.config.DEX_SVC_LB_HOSTNAME`: Replace `<DEX_SVC_LB_HOSTNAME>` with the host name of the Dex service load balancer that is running in the management cluster, that you identified in [Obtain the Dex Load Balancer for Azure](dex.md#lb-azure).
   - `gangway.config.clientID`: Replace `<WORKLOAD_CLUSTER_NAME>` with the name of the authentication-enabled Tanzu Kubernetes cluster.
   - `gangway.config.APISERVER_URL`: Replace `<API_SERVER_LB_HOSTNAME>` with the host name of the Kubernetes API Server endpoint for the Tanzu Kubernetes cluster. This is the DNS name of the Azure load balancer, that has a name like `auth-cluster-apiserver-1506126946.us-west-2.elb.amazonaws.com`. You can find this DNS name by consulting the Resource group in your Azure account.
    - `gangway.secret.sessionKey`: Replace `<SESSION_KEY>` with the session key for the Gangway service that you obtained in the preceding procedure.
    - `gangway.secret.clientSecret`: Replace `<CLIENT_SECRET>` with the client secret for the Gangway service that you obtained in the preceding procedure.
   - `dns.aws.GANGWAY_SVC_LB_HOSTNAME`: Do not update `<GANGWAY_SVC_LB_HOSTNAME>` yet. The Gangway service load balancer is created when you deploy the Gangway service, so you must update this value after you have deployed Gangway.
   - `dex.ca`: Replace `<INSERT_DEX_CA_CERT>` with the contents of the CA file for the Dex service that you obtained in [Prepare the Tanzu Kubernetes Cluster for Gangway Deployment](#prepare-tkc) above. 
   
      **IMPORTANT**: Make sure that the CA file contents are indented by exactly 4 spaces. If the indentation is incorrect, the Kapp controller will not deploy the extension.
   
   For example:
   
    ```
    #@data/values
    #@overlay/match-child-defaults missing_ok=True
    ---
    infrastructure_provider: "azure"
    gangway:
      config:
        clusterName: auth-cluster
        DEX_SVC_LB_HOSTNAME: 20.54.226.42
        clientID: auth-cluster
        APISERVER_URL: 20.54.226.42
      secret:
        sessionKey: 02ab7df041fdfeace3952d7d832db6f9
        clientSecret: 7b0fb0244d7eb28da0db39a3588b23eb
    dns:
      azure:
        GANGWAY_SVC_LB_HOSTNAME: <GANGWAY_SVC_LB_HOSTNAME>
    dex:
      ca: | 
        -----BEGIN CERTIFICATE-----
        MIIDJjCCAg6gAwIBAgIRAJ7NE8QscfIGDyiSOeqwGPYwDQYJKoZIhvcNAQELBQAw
        IzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQDEwd0a2ctZGV4MB4XDTIwMDkzMDA4
        NDcxMFoXDTIwMTIyOTA4NDcxMFowIzEPMA0GA1UEChMGdm13YXJlMRAwDgYDVQQD
        Ewd0a2ctZGV4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxxc+i/Cq
        qw2pr4puhy7rllNIUWsRGnxXPiqWdCMpIo1W0HQNtf65SMxU/7NwyHOSdRzz6XGL
        0BEdLv9IrO/BkDazg1WsTr2S6jTpH2CbJ2S5vmIW/3IIhr5rcQXVM5cWnKSpitRc
        8Q7kHHg53kCpRFyGFpGQvWPlHxxsJAqp6axV7konSpWqsyQmMVuEuD1VnJUeHLpa
        Za6ySdp4AwNzgIkwAKrza8TXkQZ3uL8uxH7JWgIrzXEqIfyRDxRiYYBqMOOorC0Z
        Ef46GgS0z8RGcFmwHJwVjwN0vs2EUbNiqsvgBUTZWrqpKaDQd2q9ciTYXR57YC+5
        Qxd5JmMpT4ssHwIDAQABo1UwUzAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUH
        AwIwDAYDVR0TAQH/BAIwADAkBgNVHREEHTAbggt0a2ctZGV4LmNvbYIMMjAuNTQu
        MjI2LjQyMA0GCSqGSIb3DQEBCwUAA4IBAQAp2eKubjZzYo4OAvBgqXje8PJOurmG
        B9vU5HpmqSO1GqAt6SJuiWgXbFeJmiZ4aDlAucVtwINPLnPYXunE9BZ0QQvUyozD
        pAbHdoLjvhf8srZV58cXr41OVs2lodFFymIt4PHvlZ3UuCXqMC2Nn9bowCTjmgMx
        u+iHem5/vWGASd37z0WmiwiwKzPbJNfGDhQY9I7WKOaL+azQBAiwjMWxUf+OLau7
        VFVtYD65uztsqU4wWoA3UswAP0dcJlRN0P5XQlxW/+ecVj8Kn0vFqGkMGCZTJCsW
        suqxb/OkRO5+EkOhwK8kpx+kHKce5/Olvp4Kcog62XMrfqLhn1Kg4eXR
        -----END CERTIFICATE-----
    ```
1. Save the updated `gangway-data-values.yaml` file.
1. Create a Kubernetes secret named `gangway-data-values` with the values that you set in `gangway-data-values.yaml`.

   ```
   kubectl create secret generic gangway-data-values --from-file=values.yaml=authentication/gangway/azure/gangway-data-values.yaml -n tanzu-system-auth
   ```

For the next steps, see [Deploy Gangway on the Tanzu Kubernetes Cluster](#deploy-gangway).   

## <a id="deploy-gangway"></a> Deploy Gangway on the Tanzu Kubernetes Cluster

After you have prepared the authentication-enabled Tanzu Kubernetes cluster and updated the appropriate configuration file for your platform, you can deploy Gangway on the cluster. 

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Deploy the Gangway extension.

   ```
   kubectl apply -f authentication/gangway/gangway-extension.yaml
   ```

   You should see the confirmation `extension.clusters.tmc.cloud.vmware.com/gangway created`.

1. View the status of the Gangway extension.

    ```
    kubectl get extension gangway -n tanzu-system-auth
    ```
    You should see information about the Gangway extension.
    ```
    NAME      STATE   HEALTH   VERSION
    gangway   3
    ```
1. View the status of the Gangway service itself.

    ```
    kubectl get app gangway -n tanzu-system-auth
    ```
    The status of the Dex app should show `Reconcile Succeeded` when Gangway has deployed successfully. 
    ```
    NAME      DESCRIPTION           SINCE-DEPLOY   AGE
    gangway   Reconcile succeeded   9s             43s
    ```
    If the status is not `Reconcile Succeeded`, view the full status details of the Gangway service.

   Viewing the full status can help you to troubleshoot the problem.

   ```
   kubectl get app gangway -n tanzu-system-auth -o yaml
   ```   
1. Check that the Gangway service is running by listing all of the pods that are running in the Tanzu Kubernetes cluster. 

   ```
   kubectl get pods -A
   ```   

   In the `tanzu-system-auth` namespace, you should see the `gangway` service running in a pod with  names similar to `gangway-69657b8585-qdqg9`.
   
   ```
    NAMESPACE              NAME                                  READY   STATUS    RESTARTS   AGE
    [...]
    tanzu-system-auth   gangway-69657b8585-qdqg9                                   1/1     Running   0          10m
    vmware-system-tmc   extension-manager-d7cc7fcbb-g6z9s                          1/1     Running   0          15m
    vmware-system-tmc   kapp-controller-7c98dff676-7hg8b                           1/1     Running   0          15m
    ```      
If your Tanzu Kubernetes cluster is running on vSphere, for the next steps, see [Register Gangway with the Dex Service](#register-gangway).

If your Tanzu Kubernetes cluster is running on Amazon EC2 or Azure, for the next steps see [Obtain the Gangway Load Balancer for Amazon EC2](#lb-aws) or [Obtain the Gangway Load Balancer for Azure](#lb-azure).

## <a id="lb-aws"></a> Obtain the Gangway Load Balancer for Amazon EC2

If you deployed Gangway on a cluster that is running on Amazon EC2, you must perform additional steps to obtain the address of the Gangway service load balancer that is running in that cluster. You then need to update the Gangway configuration to use it.

1. Obtain the hostname of the Gangway service load balancer.

   ```
   kubectl get svc gangwaysvc -n tanzu-system-auth -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
   ```
1. Open `authentication/gangway/aws/gangway-data-values.yaml` in a text editor and update the `GANGWAY_SVC_LB_HOSTNAME` parameter with the address that you obtained in the preceding step.

   ```
    dns:
      aws:
        GANGWAY_SVC_LB_HOSTNAME: a708e794809d54af699834323c33a0a-463181988.us-west-2.elb.amazonaws.com
    ```

1. Update the `gangway-data-values` secret to include the load balancer address.

   ```
   kubectl create secret generic gangway-data-values --from-file=values.yaml=authentication/gangway/aws/gangway-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ``` 

   You should see the confirmation `secret/dex-data-values replaced`.  
1. Restart the Gangway extension by deleting the pod in which the Gangway service is running.

   When you delete the pod, Kubernetes recreates it with the new configuration. You obtained the pod ID by running `kubectl get pods -A` in the previous procedure. 

   ```
   kubectl delete pod --namespace tanzu-system-auth gangway-69657b8585-qdqg9
   ```   
   
For the next steps, see [Register Gangway with the Dex Service](#register-gangway).

## <a id="lb-azure"></a> Obtain the Gangway Load Balancer for Azure

If you deployed Gangway on a cluster that is running on Azure, you must perform additional steps to obtain the address of the Gangway service load balancer that is running in that cluster. You then need to update the Gangway configuration to use it.

1. Obtain the IP address of the Gangway service load balancer.

   ```
   kubectl get svc gangwaysvc -n tanzu-system-auth -o jsonpath='{.status.loadBalancer.ingress[0].ip}'
   ```
1. Open `authentication/gangway/azure/gangway-data-values.yaml` in a text editor and update the `GANGWAY_SVC_LB_HOSTNAME` parameter with the address that you obtained in the preceding step.

   ```
    dns:
      azure:
        GANGWAY_SVC_LB_HOSTNAME: 20.54.226.44
    ```

1. Update the `gangway-data-values` secret to include the load balancer address.

   ```
   kubectl create secret generic gangway-data-values --from-file=values.yaml=authentication/gangway/azure/gangway-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ``` 

   You should see the confirmation `secret/dex-data-values replaced`.  
1. Restart the Gangway extension by deleting the pod in which the Gangway service is running.

   When you delete the pod, Kubernetes recreates it with the new configuration. You obtained the pod ID by running `kubectl get pods -A` in the previous procedure. 

   ```
   kubectl delete pod --namespace tanzu-system-auth gangway-69657b8585-qdqg9
   ```   
   
For the next steps, see [Register Gangway with the Dex Service](#register-gangway).

## <a id="register-gangway"></a> Register Gangway with the Dex Service

After you have deployed Gangway on a Tanzu Kubernetes cluster, you must register the Gangway service with the Dex service that is running in the management cluster.

This procedure applies to Tanzu Kubernetes clusters running on vSphere, Amazon EC2, and Azure.

1. Set the context of `kubectl` back to the management cluster.

   ```
   kubectl config use-context auth-mgmt-cluster-admin@auth-mgmt-cluster 
   ```
1. Open the appropriate `dex-data-values.yaml` file in a text editor.

   - **vSphere (LDAP):** `authentication/dex/vsphere/ldap/dex-data-values.yaml`
   - **vSphere (OIDC):** `authentication/dex/vsphere/oidc/dex-data-values.yaml`
   - **Amazon EC2:** `authentication/dex/aws/oidc/dex-data-values.yaml`
   - **Azure:**  `authentication/dex/azure/ldap/dex-data-values.yaml`
1. Edit the `dex.config.staticClients` entry in the `dex-data-values.yaml` file with information about the Gangway service that is running in the Tanzu Kubernetes cluster.
   
   - `dex.config.staticClients.id`: Replace `WORKLOAD_CLUSTER_NAME` with the name of the Tanzu Kubernetes cluster on which you deployed Gangway. For example, `auth-cluster`.
   - `dex.config.staticClients.redirectURIs`: 
   
      - **vSphere**: Replace `WORKLOAD_CLUSTER_IP` with the static virtual IP address that you set for the Tanzu Kubernetes cluster on which you deployed Gangway.
      - **Amazon EC2**: Replace `GANGWAY_SVC_LB_HOSTNAME` with the name of the Gangway service load balancer that you obtained in [Obtain the Gangway Load Balancer for Amazon EC2](#lb-aws).
      - **Azure**: Replace `WORKLOAD_CLUSTER_IP` with the IP of the Gangway service load balancer that you obtained in [Obtain the Gangway Load Balancer for Azure](#lb-azure).
   - `dex.config.staticClients.name`: Replace `WORKLOAD_CLUSTER_NAME` with the name of the Tanzu Kubernetes cluster on which you deployed Gangway. For example, `auth-cluster`.
   - `dex.config.staticClients.secret`: Replace `<CLIENT_SECRET>` with the client secret for the Gangway service that you obtained in [Prepare the Tanzu Kubernetes Cluster for Gangway Deployment](#prepare-tkc) above.
   
   **vSphere:**
   
    ```
        staticClients:
        - id: auth-cluster
          redirectURIs:
          - 'https://192.168.100.11:30166/callback'
          name: auth-cluster
          secret: 7b0fb0244d7eb28da0db39a3588b23eb
    ```     
   
   **Amazon EC2:**
   
    ```
        staticClients:
        - id: auth-cluster
          redirectURIs:
          - 'https://a708e794809d54af699834323c33a0a-463181988.us-west-2.elb.amazonaws.com:30166/callback'
          name: auth-cluster
          secret: 7b0fb0244d7eb28da0db39a3588b23eb
    ```
   
   **Azure:**
   
    ```
        staticClients:
        - id: auth-cluster
          redirectURIs:
          - 'https://20.54.226.44:30166/callback'
          name: auth-cluster
          secret: 7b0fb0244d7eb28da0db39a3588b23eb
    ```   
1. Recreate the `dex-data-values` Kubernetes secret with the new values that you set in `dex-data-values.yaml`

   **vSphere (LDAP):**
   
   ```
   kubectl create secret generic dex-data-values --from-file=authentication/dex/vsphere/ldap/dex-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ```

   **vSphere (OIDC):**
   
   ```
   kubectl create secret generic dex-data-values --from-file=authentication/dex/vsphere/oidc/dex-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ```

   **Amazon EC2:**
   
   ```
   kubectl create secret generic dex-data-values --from-file=authentication/dex/aws/oidc/dex-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ```   

   **Azure:**
   
   ```
   kubectl create secret generic dex-data-values --from-file=authentication/dex/azure/ldap/dex-data-values.yaml -n tanzu-system-auth -o yaml --dry-run | kubectl replace -f-
   ```   
1. Restart the Dex extension by deleting the pod in which the Dex service is running.

   When you delete the pod, Kubernetes recreates it with the new configuration. You obtain the pod ID by running `kubectl get pods -A`. 

   ```
   kubectl delete pod --namespace tanzu-system-auth dex-56687dcdbc-qjkrm
   ```   
1. Check that the update succeeded and that the Dex service has restarted.

   ```
   kubectl get app dex -n tanzu-system-auth
   ```

   You should see `Reconcile succeeded` and that the `SINCE-DEPLOY` value is recent.
   
   ```
   NAME   DESCRIPTION           SINCE-DEPLOY   AGE
   dex    Reconcile succeeded   61s            69m
   ```   

## <a id="what-next"></a> What to Do Next

Dex and Gangway are now running on your management cluster and Tanzu Kubernetes cluster respectively. You can now use your the credentials from your external identity provider (IDP) to connect to the cluster, as described in [Log In to the Authentication-Enabled Tanzu Kubernetes Cluster to Obtain Its `kubeconfig`](connect-auth-cluster.md).

