# Upgrade Tanzu Kubernetes Clusters

After you have upgraded a management cluster, you can [upgrade the Tanzu Kubernetes clusters](workload-clusters.md) that the management cluster manages.

**IMPORTANT**: Due to changes in implementation betweeen Tanzu Kubernetes Grid v1.1.x and v1.2, you must upgrade all management clusters that you connect to with the upgraded instance of the Tanzu Kubernetes Grid CLI. You cannot use v1.2 of the CLI to deploy Tanzu Kubernetes clusters from management clusters that are still at v1.1.x.   

- [Prerequisites](#prereqs)
- [Procedure](#procedure)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

- You performed the steps in [Upgrading Tanzu Kubernetes Grid](index.md) to upgrade the Tanzu Kubernetes Grid CLI.
- You performed the steps in [Upgrade Management Clusters](management-cluster.md) to upgrade the management cluster that manages the Tanzu Kubernetes clusters that you want to upgrade.
- If you are upgrading clusters that run on vSphere, before you can upgrade clusters to a non-default version of Kubernetes for your version of Tanzu Kubernetes Grid, the appropriate base OS template OVAs must be available in vSphere as VM templates. For information about importing base OVA files into vSphere, see [Prepare to Upgrade Clusters on vSphere](index.md#vsphere). 
- If you are upgrading clusters that run in Amazon EC2, the Amazon Linux 2 Amazon Machine Images (AMI) that include the supported Kubernetes versions are publicly available to all Amazon EC2 users, in all supported AWS regions. Tanzu Kubernetes Grid automatically uses the appropriate AMI for the Kubernetes version that you specify during upgrade.

## <a id="procedure"></a> Procedure

The upgrade process upgrades the version of Kubernetes in all of the control plane and worker nodes of your Tanzu Kubernetes clusters.

1. Run the `tkg get management-cluster` command to see the list of management clusters that you have deployed from your bootstrap machine.

   ```
   tkg get management-cluster
   ``` 
1. Run the `tkg set management-cluster` command to set the context of the Tanzu Kubernetes Grid CLI to the management cluster that manages the clusters that you want to upgrade.

   <pre>
   tkg set management-cluster <em>management_cluster_name</em>
   </pre>  
1. Run the `tkg get cluster` command with the `--include-management-cluster` option. 

   ```
   tkg get cluster --include-management-cluster
   ```
   
   The `tkg get cluster` command shows the version of Kubernetes that is running in the management cluster and all of the clusters that it manages. In this example, you can see that the management cluster has already been upgraded to v1.19.1, but the Tanzu Kubernetes clusters are running older versions of Kubernetes.
   
   ```
   NAME                NAMESPACE   STATUS    CONTROLPLANE  WORKERS  KUBERNETES          ROLES
   k8s-1-17-9-cluster  default     running   1/1           1/1      v1.17.9+vmware.1    <none>   
   k8s-1-18-3-cluster  default     running   1/1           1/1      v1.18.3+vmware.1    <none>   
   k8s-1-18-6-cluster  default     running   1/1           1/1      v1.18.6+vmware.1    <none>  
   mgmt-cluster        tkg-system  running   1/1           1/1      v1.19.1+vmware.2    management 
   ```

1. To discover which versions of Kubernetes are made available by a management cluster, run the `tkg get kubernetesversions` command.

   ```
   tkg get kubernetesversions
   ```
   The output lists all of the versions of Kubernetes that you can use to deploy clusters.
   ```   
    VERSIONS
    v1.17.11+vmware.1
    v1.17.9+vmware.1
    v1.18.3+vmware.1
    v1.18.6+vmware.1
    v1.18.8+vmware.1
    v1.19.1+vmware.2
   ```
1. Run the `tkg upgrade cluster` command and enter `y` to confirm.

   To upgrade the cluster to the default version of Kubernetes for this release of Tanzu Kubernetes Grid, run the `tkg upgrade cluster` command without any options. For example, the following command upgrades the cluster `k8s-1-18-6-cluster` from v1.18.6 to v1.19.1.
   
   ```
   tkg upgrade cluster k8s-1-18-6-cluster
   ```
   
   If the cluster is not running in the `default` namespace, specify the `--namespace` option.
   
   <pre>
   tkg upgrade cluster <em>cluster_name</em> --namespace <em>namespace_name</em>
   </pre>
   
   If you are upgrading a cluster that is running on vSphere, and if your vSphere inventory includes more than one base OS template that is running the same version of Kubernetes, specify the `--vpshere-vm-template-name` option with the name of the template to use to create the cluster.
   
   **NOTE**: This is an advanced option that you should not normally need to use. Use this option only when instructed to do so by VMware Tanzu Support.
   
   <pre>
   tkg upgrade cluster <em>cluster_name</em> --vpshere-vm-template-name <em>baseos_template_name</em>
   </pre>
   
   To skip the confirmation step when you upgrade a cluster, specify the `--yes` option.
   
   <pre>
   tkg upgrade cluster <em>cluster_name</em> --yes
   </pre>
   
   To upgrade a cluster to a version of Kubernetes that is not the default version for this release of Tanzu Kubernetes Grid, specify the `--kubernetes-version` option. For example, the following command upgrades the cluster `k8s-1-17-9-cluster` from v1.17.9 to v1.17.11.
   
   ```
   tkg upgrade cluster k8s-1-17-9-cluster --kubernetes-version v1.17.11 --yes
   ```
   
   If an upgrade times out before it completes, run `tkg upgrade cluster` again and specify the `--timeout` option with a value greater than the default of 30 minutes.
   
   <pre>
   tkg upgrade cluster <em>cluster_name</em> --timeout 45m0s
   </pre>
   
1. When the upgrade finishes, run the `tkg get cluster` command with the `--include-management-cluster` option again, to check that the Tanzu Kubernetes cluster has been upgraded.

   ```
   tkg get cluster --include-management-cluster
   ```

   You see that the `k8s-1-17-9-cluster` and `k8s-1-18-6-cluster` Tanzu Kubernetes clusters are now running Kubernetes v1.17.11 and v1.19.1 respectively.
   
   ```
   NAME                NAMESPACE   STATUS    CONTROLPLANE  WORKERS  KUBERNETES         ROLES
   k8s-1-17-9-cluster  default     running   1/1           1/1      v1.17.11+vmware.1   <none>  
   k8s-1-18-3-cluster  default     running   1/1           1/1      v1.18.3+vmware.1   <none>  
   k8s-1-18-6-cluster  default     running   1/1           1/1      v1.19.1+vmware.2   <none> 
   mgmt-cluster        tkg-system  running   1/1           1/1      v1.19.1+vmware.2   management
   ```   

## <a id="what-next"></a> What to Do Next

If your deployment runs on vSphere, you must also perform manual steps to [Migrate Clusters from an HA Proxy Load Balancer to Kube-VIP](migrate-haproxy.md).

Otherwise, you can now continue to use Tanzu Kubernetes Grid CLI to manage your clusters, and run your applications with the new version of Kubernetes.
