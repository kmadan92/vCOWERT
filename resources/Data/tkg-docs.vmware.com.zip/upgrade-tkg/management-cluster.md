# Upgrade Management Clusters

To upgrade your Tanzu Kubernetes Grid instance, you must first upgrade the management cluster. You cannot upgrade Tanzu Kubernetes clusters until you have upgraded the management cluster that manages them. 

**IMPORTANT**: Due to changes in implementation betweeen Tanzu Kubernetes Grid 1.1.x and 1.2, you must upgrade all management clusters that you connect to with the upgraded instance of the Tanzu Kubernetes Grid CLI. You cannot use version 1.2 of the CLI to deploy Tanzu Kubernetes clusters from management clusters that are still at version 1.1.x.   

- [Prerequisites](#prereqs)
- [Procedure](#procedure)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

- You performed the steps in [Upgrading Tanzu Kubernetes Grid](index.md) to upgrade the Tanzu Kubernetes Grid CLI and to prepare your vSphere and Amazon EC2 environments so that you can upgrade the management cluster.
- If you deployed the previous version of Tanzu Kubernetes Grid in an Internet-restricted environment, you have performed the steps in [Deploy Tanzu Kubernetes Grid to an Offline Environment](../mgmt-clusters/airgapped-environments.md#procedure) to recreate and run the `gen-publish-images.sh` and `publish-images.sh` scripts with the new component image versions.

## <a id="procedure"></a> Procedure

1. Run the `tkg get management-cluster` command to see the list of management clusters that you have deployed from your bootstrap machine.

   ```
   tkg get management-cluster
   ```   
1. Run the `tkg set management-cluster` command to set the context of the Tanzu Kubernetes Grid CLI to the management cluster that you want to upgrade.

   <pre>
   tkg set management-cluster <em>management_cluster_name</em>
   </pre>  
1. Run the `tkg get cluster` command with the `--include-management-cluster` option. 

   ```
   tkg get cluster --include-management-cluster
   ```
   
   The `tkg get cluster` command shows the version of Kubernetes that is running in the management cluster and all of the clusters that it manages. For example:
   
   ```
   NAME                NAMESPACE   STATUS    CONTROLPLANE  WORKERS  KUBERNETES          ROLES
   k8s-1-17-9-cluster  default     running   1/1           1/1      v1.17.9+vmware.1    <none>
   k8s-1-18-3-cluster  default     running   1/1           1/1      v1.18.3+vmware.1    <none>
   k8s-1-18-6-cluster  default     running   1/1           1/1      v1.18.6+vmware.1    <none> 
   mgmt-cluster        tkg-system  running   1/1           1/1      v1.18.6+vmware.1    <none> 
   ``` 
1. Set the context of `kubectl` to the management cluster:

   <pre>
   kubectl config use-context <em>management_cluster_context_name</em>
   </pre>

1. Add the `cluster-role` label to all management clusters.

   In previous releases, management clusters were not labeled with a role. In Tanzu Kubernetes Grid 1.2, the labels `management` and `tanzu-services` are applied to clusters when you create them, so that you can easily distinguish between management clusters and the clusters that are created when you deploy the Tanzu Kubernetes Grid extensions. When you are upgrading management clusters from a previous version, you must apply the new role labels to existing clusters manually.
   
   To apply the `management` label to the management cluster `mgmt-cluster`, run the following command:
   
   ```
   kubectl label -n tkg-system cluster.cluster.x-k8s.io/mgmt-cluster cluster-role.tkg.tanzu.vmware.com/management="" --overwrite=true
   ```   
   Repeat the commands for all other management clusters.   
1. Run the `tkg upgrade management-cluster` command and enter `y` to confirm.
   
   The following command upgrades the management cluster named `mgmt-cluster`.

   <pre>
   tkg upgrade management-cluster mgmt-cluster
   </pre>
   
   If you are upgrading a management cluster that is running on vSphere, and if your vSphere inventory includes more than one base OS template that is running the same version of Kubernetes, specify the `--vsphere-vm-template-name` option with the name of the template to use to create the cluster.
   
   **NOTE**: This is an advanced option that you should not normally need to use. Use this option only when instructed to do so by VMware Tanzu Support.
   
   <pre>
   tkg upgrade management-cluster mgmt-cluster --vsphere-vm-template-name <em>baseos_template_name</em>
   </pre>
   
   To skip the confirmation step when you upgrade a cluster, specify the `--yes` option.
   
   <pre>
   tkg upgrade management-cluster mgmt-cluster --yes
   </pre>
   
   The upgrade process first upgrades the Cluster API providers for vSphere or Amazon EC2 that are running in the management cluster. Then, it upgrades the version of Kubernetes in all of the control plane and worker nodes of the management cluster.
   
   If the upgrade times out before it completes, run `tkg upgrade management-cluster` again and specify the `--timeout` option with a value greater than the default of 30 minutes.
   
   <pre>
   tkg upgrade management-cluster mgmt-cluster --timeout 45m0s
   </pre>
1. When the upgrade finishes, run the `tkg get cluster` command with the `--include-management-cluster` option again to check that the management cluster has been upgraded.

   ```
   tkg get cluster --include-management-cluster
   ```

   You see that the management cluster is now running the new version of Kubernetes, but that the Tanzu Kubernetes clusters are still running previous versions of Kubernetes.
   
   ```
   NAME                NAMESPACE   STATUS    CONTROLPLANE  WORKERS  KUBERNETES          ROLES
   k8s-1-17-9-cluster  default     running   1/1           1/1      v1.17.9+vmware.1    <none> 
   k8s-1-18-3-cluster  default     running   1/1           1/1      v1.18.3+vmware.1    <none> 
   k8s-1-18-6-cluster  default     running   1/1           1/1      v1.18.6+vmware.1    <none> 
   mgmt-cluster        tkg-system  running   1/1           1/1      v1.19.1+vmware.2    management
   ```    

## <a id="what-next"></a> What to Do Next

If your deployment runs on vSphere, you must also perform manual steps to [Migrate Clusters from an HA Proxy Load Balancer to Kube-VIP](migrate-haproxy.md).

You can now [upgrade the Tanzu Kubernetes clusters](workload-clusters.md) that this management cluster manages. By default, any new clusters that you deploy with this management cluster will run the new default version of Kubernetes. In Tanzu Kubernetes Grid 1.2.0, the default version of Kubernetes is 1.19.1. However, if required, you can use the `tkg create cluster` command with the `--kubernetes-version` option to deploy new clusters that run different versions of Kubernetes. For more information, see [Deploy a Cluster that Runs a Different Version of Kubernetes](../tanzu-k8s-clusters/create.md#k8s-version).