# Create Tanzu Kubernetes Cluster Configuration Files

You can use the Tanzu Kubernetes Grid CLI to create YAML files for Tanzu Kubernetes clusters without actually creating the clusters. To generate a YAML file for a cluster configuration, run the `tkg config cluster` command with the same options as you would specify when running `tkg create cluster`. For more information about the `tkg create cluster` options, see [Create Tanzu Kubernetes Clusters](create.md). 

For example, the following command uses many of the possible `tkg config cluster` options, including to identify the namespace in which to run the cluster, and setting the sizes of the nodes.

```
tkg config cluster my-cluster --plan dev --controlplane-machine-count 3 --worker-machine-count 10 --namespace my_namespace --controlplane-size large --worker-size extra-large
```

If you are creating YAML files for deployment to vSphere, you must also specify the `--vsphere-controlplane-endpoint-ip` option. The `--vsphere-controlplane-endpoint-ip` option sets a static virtual IP address for API requests to the cluster. Make sure that this IP address is not in the DHCP range, but is in the same subnet as the DHCP range. For more information, see [Load Balancers for vSphere](../mgmt-clusters/vsphere.md#load-balancer).

```
tkg config cluster my-cluster --plan dev --vsphere-controlplane-endpoint-ip <ip_address> --controlplane-machine-count 3 --worker-machine-count 10 --namespace my_namespace --controlplane-size large --worker-size extra-large
```

If you are satisfied with the displayed configuration file, run the `tkg create cluster` command with the same options, to create the cluster.

```
tkg create cluster my-cluster --plan dev --controlplane-machine-count 3 --worker-machine-count 10 --namespace my_namespace --controlplane-size large --worker-size extra-large
```

```
tkg create cluster my-cluster --plan dev --vsphere-controlplane-endpoint-ip <ip_address> --controlplane-machine-count 3 --worker-machine-count 10 --namespace my_namespace --controlplane-size large --worker-size extra-large
```

**NOTES**: 

- Running the `tkg config cluster` command works in the same way as specifying `--dry-run` option with `tkg create cluster`. For more information about the `--dry-run` option, see [Preview the YAML for a Tanzu Kubernetes Cluster](create.md#dry-run).
- The `tkg config cluster` command includes the `--enable-cluster-options oidc` option, that allows you to create configuration files to deploy Tanzu Kubernetes clusters that implement authentication. If you enable authentication, only users with the correct permissions can access those clusters. To use the `--enable-cluster-options oidc` option, you must implement the Dex and Gangway extensions. For information about how to implement authentication with Dex and Gangway, see [Implementing User Authentication with Dex and Gangway](../extensions/authentication.md).

### Deploy a Cluster from a Saved YAML File

When you run `tkg config cluster` or `tkg create cluster` with the  `--dry-run` option, Tanzu Kubernetes Grid sends the YAML file for the cluster to `stdout`, so that you can save it for repeated future use. You can use the `tkg create cluster` command with the `--manifest` option to deploy a cluster from the saved YAML file.

1. Run either `tkg config cluster` or `tkg create cluster` with the  `--dry-run` option to create a cluster configuration and save it to a YAML file.

    - vSphere:
    
       ```
       tkg config cluster manifest-test --plan dev --vsphere-controlplane-endpoint-ip <ip_address> --controlplane-machine-count 3 --worker-machine-count 10 > manifest-test.yaml
       ```
    
       ```
       tkg create cluster manifest-test --plan dev --vsphere-controlplane-endpoint-ip <ip_address> --controlplane-machine-count 3 --worker-machine-count 10 --dry-run > manifest-test.yaml
       ```  
    
    - Amazon EC2 or Azure:
    
       ```
       tkg config cluster manifest-test --plan dev --controlplane-machine-count 3 --worker-machine-count 10 > manifest-test.yaml
       ```
    
       ```
       tkg create cluster manifest-test --plan dev --controlplane-machine-count 3 --worker-machine-count 10 --dry-run > manifest-test.yaml
       ``` 
1. To deploy a cluster from the saved YAML file, run `tkg create cluster` with the `--manifest` option. 

   If you specify the `--manifest` option, no other options are required, as the configuration is taken from the YAML file.
   
   ```
   tkg create cluster manifest-test --manifest manifest-test.yaml
   ```