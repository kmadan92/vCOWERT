# Deploying Tanzu Kubernetes Clusters and Managing their Lifecycle

This section describes how you use Tanzu Kubernetes Grid to deploy and manage Tanzu Kubernetes clusters.

Before you can create Tanzu Kubernetes clusters, you must install the Tanzu Kubernetes Grid CLI and deploy a management cluster. For information, see [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) and [Deploying and Managing Management Clusters](../mgmt-clusters/deploy-management-clusters.md).

You can use the Tanzu Kubernetes Grid CLI to deploy Tanzu Kubernetes clusters to the following platforms:

- vSphere 6.7u3
- vSphere 7
- Amazon EC2
- Microsoft Azure

If you have vSphere 7 and you have enabled the vSphere with Tanzu feature, you can use the Tanzu Kubernetes Grid CLI to interact with the vSphere with Tanzu Supervisor Cluster, and to deploy Tanzu Kubernetes clusters from the Supervisor Cluster.

**NOTE**: You cannot provision Tanzu Kubernetes clusters across providers. A management cluster that is running on vSphere cannot create a Tanzu Kubernetes cluster in Amazon EC2, and vice-versa. It is not possible to use shared services between the different providers because, for example, vSphere clusters are reliant on sharing vSphere networks and storage, while Amazon EC2 uses its own systems. 

The Tanzu Kubernetes Grid provides commands and options to perform the following common cluster creation and lifecycle management operations:

- [Create Tanzu Kubernetes Clusters](create.md)
- [Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster](connect-vsphere7.md)
- [Create Tanzu Kubernetes Cluster Configuration Files](config.md)
- [Create Persistent Volumes with Storage Classes](storage.md)
- [Connect to and Examine Tanzu Kubernetes Clusters](connect.md)
- [Scale Tanzu Kubernetes Clusters](scale-cluster.md)
- [Delete Tanzu Kubernetes Clusters](delete-cluster.md)