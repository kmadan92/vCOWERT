# Deploying Tanzu Kubernetes Clusters and Managing their Lifecycle

<!-- A README is required in each folder by Gitbook. This file is only for PDF generation and does not appear in the output -->

Deploying Tanzu Kubernetes Clusters and Managing their Lifecycle describes how to use the Tanzu Kubernetes Grid CLI to deploy Tanzu Kubernetes clusters from your management cluster, and how to manage the lifecycle of those clusters.
