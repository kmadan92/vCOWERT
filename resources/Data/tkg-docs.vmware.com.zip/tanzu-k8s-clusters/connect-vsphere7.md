# Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster 

You can connect the Tanzu Kubernetes Grid CLI to a vSphere with Tanzu Supervisor Cluster that is running in a vSphere 7 instance. In this way, you can deploy Tanzu Kubernetes clusters to vSphere with Tanzu and manage their lifecycle directly from the Tanzu Kubernetes Grid CLI. 

vSphere with Tanzu provides a vSphere Plugin for `kubectl`. The vSphere Plugin for `kubectl` extends the standard `kubectl` commands so that you can connect to the Supervisor Cluster from `kubectl` by using vCenter Single Sign-On credentials. Once you have installed the vSphere Plugin for `kubectl`, you can connect the Tanzu Kubernetes Grid CLI to the Supervisor Cluster. Then, you can use the Tanzu Kubernetes Grid CLI to deploy and manage Tanzu Kubernetes clusters running in vSphere.

## <a id="prereqs"></a> Prerequisites

- Perform the steps described in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.html).
- Make sure that you have a vSphere account that has the correct permissions for deployment of clusters to vSphere 7. For information about how to create a user account, see [Required Permissions for the vSphere Account](../mgmt-clusters/vsphere.html#vsphere-permissions).
- You have access to a vSphere 7 instance on which the vSphere with Tanzu feature is enabled.
- Download and install the `kubectl vsphere` CLI utility on the bootstrap machine on which you run Tanzu Kubernetes Grid CLI commands. 

   For information about how to obtain and install the vSphere Plugin for `kubectl`, see <a href="https://docs.vmware.com/en/VMware-vSphere/7.0/vmware-vsphere-with-kubernetes/GUID-0F6E45C4-3CB1-4562-9370-686668519FCA.html" target="_blank">Download and Install the Kubernetes CLI Tools for vSphere</a> in the vSphere with Tanzu documentation.

## <a id="procedure"></a> Procedure


### <a id="add"></a> Step 1: Add the Supervisor Cluster

Connect to the Supervisor Cluster and add it as a management cluster to the `tkg` CLI:

1. From vCenter **Hosts and Clusters** view, in the left column, expand the nested Datacenter, the vCenter cluster that hosts the Supervisor Cluster, and its **Namespaces** object.

1. Under **Namespaces**, select the cluster containing the three **SupervisorControlPlaneVM** instances.  In the main pane, select the **Summary** tab.

1. Under **Summary** > **Status** > **Link to CLI Tools** click **Copy link** and record the URL, for example `https://192.168.123.3`. This is the Supervisor Cluster API endpoint, `SUPERVISOR_IP` below, which serves the download page for the Kubernetes CLI tools.

1. On the bootstrap machine, run the `kubectl vsphere login` command to log in to vSphere 7 with your vCenter administrator account.

   Specify a vCenter Single Sign-On user account with the required privileges for Tanzu Kubernetes Grid operation, and the virtual IP (VIP) address for the control plane of the Supervisor Cluster. For example:
   
   ```
   kubectl vsphere login --vsphere-username administrator@vsphere.local --server=SUPERVISOR_IP --insecure-skip-tls-verify=true
   ```

1. Enter the password you use to log in to your vCenter administrator account.

   When you have successfully logged in, `kubectl vsphere` displays all of the contexts to which you have access. The list of contexts should include the IP address of the Supervisor Cluster.

1. Set the context of `kubectl` to the Supervisor Cluster.

   ```
   kubectl config use-context SUPERVISOR_IP
   ```   

1. Add the Supervisor Cluster to your Tanzu Kubernetes Grid instance.

    ```
    tkg add management-cluster 
    ```

1. Run `tkg get management-cluster` to see the list of management clusters that your `tkg` CLI can access.

    ```
    tkg get management-cluster
    ```
    The output should list the Supervisor Cluster by its IP address, as both the management cluster name and context.
    
    ```
    MANAGEMENT-CLUSTER-NAME       CONTEXT-NAME                             STATUS
    vsphere-mc                    vsphere-mc-admin@vsphere-mc              Success
    aws-mc *                      aws-mc-admin@aws-mc                      Success  
    SUPERVISOR_IP                 SUPERVISOR_IP                            Success   
    ```    

1. Set the context of the Tanzu Kubernetes Grid CLI to the Supervisor Cluster.

    ```
    tkg set management-cluster SUPERVISOR_IP
    ```

### <a id="config"></a> Step 2: Configure Cluster Parameters

Configure the Tanzu Kubernetes clusters that the `tkg` CLI calls the Supervisor Cluster to create:

1. Obtain information about the storage classes that are defined in the Supervisor Cluster.

   ```
   kubectl get storageclasses
   ```
   
1. Set variables to define the storage classes, VM classes, and service domain with which to create your cluster. For information about all of the configuration parameters that you can set when deploying Tanzu Kubernetes clusters to vSphere with Tanzu, see <a href="https://docs.vmware.com/en/VMware-vSphere/7.0/vmware-vsphere-with-kubernetes/GUID-4E68C7F2-C948-489A-A909-C7A1F3DC545F.html" target="_blank">Configuration Parameters for Provisioning Tanzu Kubernetes Clusters</a> in the vSphere with Tanzu documentation.

  The following table lists the required variables:

  <table width="100%" border="0">
    <tr>
      <th width="25%" scope="col">Option</th>
      <th width="25%" scope="col">Value</th>
      <th width="50%" scope="col">Description</th>
    </tr>
    <tr>
      <td><code>CONTROL_PLANE_STORAGE_CLASS</code></td>
      <td rowspan=2>Value returned from CLI: <code>kubectl get storageclasses</code></td>
      <td>Default storage class for control plane nodes</td>
    </tr>
    <tr>
      <td><code>WORKER_STORAGE_CLASS</code></td>
      <td>Default storage class for worker nodes</td>
    </tr>
    <tr>
      <td><code>DEFAULT_STORAGE_CLASS</code></td>
      <td>Empty string <code>""</code> for no default, or value from CLI, as above.</td>
      <td>Default storage class for control plane or workers</td>
    </tr>
    <tr>
      <td><code>STORAGE_CLASSES</code></td>
      <td>Empty string <code>""</code> lets clusters use any storage classes in the namespace, or comma-separated list string of values from CLI, <code>"SC-1,SC-2,SC-3"</code></td>
      <td>Storage classes available for node customization</td>
    </tr>
    <tr>
      <td><code>CONTROL_PLANE_VM_CLASS</code></td>
      <td rowspan=2>A standard VM class for vSphere with Tanzu, for example <code>guaranteed-large</code>.<br />
      See <a href="https://docs.vmware.com/en/VMware-vSphere/7.0/vmware-vsphere-with-kubernetes/GUID-7351EEFF-4EF0-468F-A19B-6CEA40983D3D.html">Virtual Machine Class Types for Tanzu Kubernetes Clusters</a> in the vSphere with Tanzu documentation.</td>
      <td>VM class for control plane nodes</td>
    </tr>
    <tr>
      <td><code>WORKER_VM_CLASS</code></td>
      <td>VM class for worker nodes</td>
    </tr>
    <tr>
      <td><code>SERVICE_CIDR</code></td>
      <td>CIDR range</td>
      <td>The CIDR range to use for the Kubernetes services. The recommended range is <code>100.64.0.0/13</code>. Change this value only if the recommended range is unavailable.</td>
    </tr>
    <tr>
      <td><code>CLUSTER_CIDR</code></td>
      <td>CIDR range</td>
      <td>The CIDR range to use for pods. The recommended range is <code>100.96.0.0/11</code>. Change this value only if the recommended range is unavailable.</td>
    </tr>
    <tr>
      <td><code>SERVICE_DOMAIN</code></td>
      <td>Domain</td>
      <td>e.g. <code>my.example.com</code>, or <code>cluster.local</code> if no DNS.  If you are going to assign FQDNs with the nodes, DNS lookup is required.</td>
    </tr>
  </table>
  
  You can set the variables above by doing either of the following:

    - Include them in `~/.tkg/config.yaml`, or other file passed to `tkg` CLI `--config` option.  For example:

      ```
      CONTROL_PLANE_VM_CLASS: guaranteed-large
      ```

    - From command line, set them as local environment variables by running `export` (on Linux and Mac OS) or `SET` (on Windows) on the command line.  For example: 

      ```
      CONTROL_PLANE_VM_CLASS=guaranteed-large
      ```

### <a id="create"></a> Step 3: Create a Cluster

Run `tkg create cluster` to create a Tanzu Kubernetes cluster.

1. Determine the versioned Tanzu Kubernetes release (`tkr`) for the cluster:

  1. Obtain the list of Tanzu Kubernetes releases that are available in the Supervisor Cluster.

      ```
      kubectl get tkr
      ```
      - Use the `-l` flag to narrow down the `tkr` list by Kubernetes version, for example:
          - `kubectl get tkr -l v1.17` returns all 1.17 versions
          - `kubectl get tkr -l v1.17.7=latest` returns the latest 1.17.7 version
      - This list differs from the output of `tkg get kubernetesversions`, which lists Kubernetes versions that ship with `tkg` for management clusters that are not vSphere 7 Supervisor Clusters.

  1. From the command output, record the desired value listed under `VERSION`, for example `1.18.9+vmware.1-tkg.1.a87f261`.

1. Determine the namespace for the cluster.

  1. Obtain the list of namespaces.
      ```
      kubectl get namespaces
      ```
  1. From the command output, record the namespace that includes the Supervisor cluster, for example `test-gc-e2e-demo-ns`.

1. Decide on the cluster plan: `dev`, `prod`, or a custom plan.

1. Run `tkg create cluster` with the namespace and `tkr` values above to create a Tanzu Kubernetes cluster:

   ```
   tkg create cluster my-vsphere7-cluster --plan=dev --namespace=NAMESPACE --kubernetes-version=TANZU-KUBERNETES-RELEASE
   ```

## <a id="what-next"></a> What to Do Next

You can now use the Tanzu Kubernetes Grid CLI to deploy more Tanzu Kubernetes clusters to the vSphere with Tanzu Supervisor Cluster. You can also use the Tanzu Kubernetes Grid CLI to manage the lifecycles of clusters that are already running there. For information about how to manage the lifecycle of clusters, see the other topics in [Deploying Tanzu Kubernetes Clusters and Managing their Lifecycle](index.md).