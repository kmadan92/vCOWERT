# Scale Tanzu Kubernetes Clusters

After you create a Tanzu Kubernetes cluster, you can scale it up or down by increasing or reducing the number of node VMs that it contains. To scale a cluster, use the `tkg scale cluster` command. You change the number of control plane nodes by specifying the `--controlplane-machine-count` option. You change the number of worker nodes by specifying the `--worker-machine-count` option.

**NOTE**: If you deployed Tanzu Kubernetes clusters to vSphere with Tanzu, you can only scale the number of worker nodes upwards. You cannot scale down the number of worker nodes on vSphere with Tanzu. You cannot scale the number of control plane nodes either up or down on clusters that run in vSphere with Tanzu.

- To scale a cluster that you originally deployed with 3 control plane nodes and 5 worker nodes to 5 and 10 nodes respectively, run the following command:

    <pre>tkg scale cluster <em>cluster_name</em> --controlplane-machine-count 5 --worker-machine-count 10</pre>

   If you initially deployed a cluster with `--controlplane-machine-count 1` and then you scale it up to 3 control plane nodes, Tanzu Kubernetes Grid automatically enables stacked HA on the control plane.

- If the cluster in running in a namespace other than the `default` namespace, you must specify the `--namespace` option to scale that cluster.

    <pre>tkg scale cluster <em>cluster_name</em> --controlplane-machine-count 5 --worker-machine-count 10 --namespace=my-namespace</pre>   

**IMPORTANT**: Do not change context or edit the `.kube-tkg/config` file while Tanzu Kubernetes Grid operations are running.
