# Build and Use Custom AMI Images on Amazon EC2

## <a id="prerequisites"></a> Prerequisites

* Before beginning you should be familiar with
[Cluster API](https://github.com/kubernetes-sigs/cluster-api)
and read more [about building images](index.md)
using this guide
* An AWS account
* A [github](https://github.com) account
* A macOS or Linux workstation with the following installed:
  * [Python 3](https://www.python.org/downloads/) with the [distutils](https://docs.python.org/3/library/distutils.html) library
  * [make](https://www.gnu.org/software/make/)

## <a id="build"></a> Build an Image with Kubernetes Image Builder

To build a Tanzu Kubernetes Grid image for AWS on your local workstation:

1. Clone the Kubernetes [Image Builder](https://github.com/kubernetes-sigs/image-builder.git) tool.

  ```bash
  git clone https://github.com/kubernetes-sigs/image-builder.git
  ```

1. Change directory to the cloned image-builder repository:

  ```bash
  cd image-builder/images/capi
  ```

1. Install required dependencies for AWS:

  ```bash
  make deps-ami
  ```

1. If the `make deps-ami` output states that it installed binaries to the `.local/bin` directory, move these files into your `$PATH`.  For example:

   ```bash
   mv .local/bin/packer /usr/local/bin
   ```

1. Determine the Image Builder configuration version that you want to build from.

   - Search the VMware {code} [Sample Exchange](https://code.vmware.com/samples) for `TKG Image Builder` to see the available versions.
   - Each version corresponds to the Kubernetes versions that it uses.
   For example, `image-builder-1.19.1-cfg.zip` builds a Kubernetes v1.19.1 image.
   - To create a management cluster, such as when you are first installing Tanzu Kubernetes Grid, choose the default Kubernetes version for your version of Tanzu Kubernetes Grid.
   For Tanzu Kubernetes Grid v1.2.0, the default Kubernetes version is v1.19.1.

1. Download the configuration code zipfile and unpack its contents.  You can unpack it within the `image-builder` directory structure or elsewhere.

1. Within this extracted Image Builder configuration directory, in the subdirectory that contains `build-image.sh`, `kubernetes.json` and other files, create a file called `aws.json` with contents:

  ```json
  {
    "ami_regions": "ap-south-1,eu-west-3,eu-west-2,eu-west-1,ap-northeast-2,ap-northeast-1,sa-east-1,ca-central-1,ap-southeast-1,ap-southeast-2,eu-central-1,us-east-1,us-east-2,us-west-1,us-west-2",
    "aws_region": "us-east-1",
    "aws_access_key": "",
    "aws_secret_key": ""
  }
  ```
1. Edit the `ami_regions` to only include regions where you would like the built image to be copied.
1. Edit the `aws_region` to the region where you would like the image build to occur in.
1. Fill in your `aws_access_key` and `aws_secret_key` and save the `aws.json` file.
1. Edit the `osstp.json` file replacing the `.` in the `custom_role_names` value with the full path to the `ansible_customize` directory (i.e. `pwd`).
1. Set the `PACKER_VAR_FILES` as such:
```bash
export PACKER_VAR_FILES="`pwd`/kubernetes.json `pwd`/osstp.json `pwd`/aws.json"
```
1. From the `image-builder/images/capi` directory, run the following command to start the build process:

  **For Amazon Linux 2:**
  ```bash
  make build-ami-amazon-2
  ```

  **For Ubuntu 18.04**
  ```bash
  make build-ami-ubuntu-1804
  ```

1. Parse and record the ami-id values listed in the output, to insert later in the BoM file.  The output will have a differing ami-id for each of the `ami_regions` you set previously

**References**

- [Building Images for AWS](https://image-builder.sigs.k8s.io/capi/providers/aws.html) in the Kubernetes Image Builder documentation.

- [Customizing images](https://image-builder.sigs.k8s.io/capi/capi.html#customization)

## <a id="bom"></a> Edit the Tanzu Kubernetes Grid Bill of Materials

Once your custom image is available in AWS, update the Tanzu Kubernetes Grid
management cluster Bill of Materials (BoM) YAML file to point to it:

1. In `~/.tkg/bom`, find the BoM file that matches your Image Builder configuration version, based on its Kubernetes version:
   - If a Kubernetes version is not the default for a Tanzu Kubernetes Grid version, its BoM file is named for the Kubernetes version.
   For example, `bom-1.18.8+vmware.1.yaml` could use an image created with `image-builder-1.18.8-cfg`.
   - If a Kubernetes version is the default for a Tanzu Kubernetes Grid version, its BoM file is named for the Tanzu Kubernetes Grid version.
   For example, `bom-1.2.0+vmware.1.yaml` could use an image created with `image-builder-1.19.1-cfg` because v1.19.1 is the default Kubernetes version in Tanzu Kubernetes Grid v1.2.0.
   - In all cases, a BoM file's `components.kubernetes.version` field indicates its Kubernetes version.

1. In the BoM file, look for the entire `ami: ` key.
2. Using ami-id values recorded from the image-builder output, replace the existing ami-id with the new values corresponding to each region you had image-builder copy to.

  ```yaml
    ami:
      ap-northeast-1:
        id: <new ami id here>
      ap-northeast-2:
        id: <new ami id here>
      ...
  ```

## <a id="what-next"></a> What to Do Next

With the BoM file pointing to your custom AMIs, you can now deploy your management cluster or a workload cluster to AWS:

- [Deploy Management Clusters to AWS with the Installer Interface](../mgmt-clusters/aws-ui.md).
- [Deploy Management Clusters to AWS with the CLI](../mgmt-clusters/aws-cli.md).
- [Create Tanzu Kubernetes Clusters](../tanzu-k8s-clusters/create.md)
