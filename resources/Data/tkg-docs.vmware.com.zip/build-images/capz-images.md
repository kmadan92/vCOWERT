# Build and Use Custom VM Images on Azure

## <a id="prerequisites"></a> Prerequisites

* Before beginning you should be familiar with
[Cluster API](https://github.com/kubernetes-sigs/cluster-api)
and read more [about building images](index.md)
using this guide
* An Azure account
* A [github](https://github.com) account
* A macOS or Linux workstation with the following installed:
  * [Docker Desktop](https://www.docker.com/products/docker-desktop)
  * [Ansible](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html)
  * [Packer](https://www.packer.io/downloads)
  * [`yq`](https://github.com/mikefarah/yq/releases/tag/3.4.0)
  * [GNU `sed`](https://www.gnu.org/software/sed/)
* The Azure CLI installed and configured. See [Install the Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) in the Microsoft Azure documentation.


## <a id="build"></a> Build an Image with Kubernetes Image Builder

To build a Tanzu Kubernetes Grid image for Azure on your local workstation:

1. Clone the Kubernetes [Image Builder](https://github.com/kubernetes-sigs/image-builder.git) tool.

   ```bash
   git clone https://github.com/kubernetes-sigs/image-builder.git
   ```

1. Set local environment variables to access and target your Azure account:

   ```
   export AZURE_SUBSCRIPTION_ID=<your-subscription-id>
   export AZURE_TENANT_ID=<your-tenant-id>
   export AZURE_CLIENT_ID=<your-client-id>
   export AZURE_CLIENT_SECRET=<your-client-secret>
   export AZURE_LOCATION="westus2"
   export AZURE_ENVIRONMENT="AzurePublicCloud"
   ```

1. Log into Azure and set your subscription:
   ```
   az cloud set --name AzureCloud

   az login --service-principal --username $AZURE_CLIENT_ID --password $AZURE_CLIENT_SECRET --tenant $AZURE_TENANT_ID

   az account set --subscription $AZURE_SUBSCRIPTION_ID
   ```

1. Determine the Image Builder configuration version that you want to build from.

   - Search the VMware {code} [Sample Exchange](https://code.vmware.com/samples) for `TKG Image Builder` to see the available versions.
   - Each version corresponds to the Kubernetes versions that it uses.
   For example, `image-builder-1.19.1-cfg.zip` builds a Kubernetes v1.19.1 image.
   - To create a management cluster, such as when you are first installing Tanzu Kubernetes Grid, choose the default Kubernetes version for your version of Tanzu Kubernetes Grid.
   For Tanzu Kubernetes Grid v1.2.0, the default Kubernetes version is v1.19.1.

1. Download the configuration code zipfile and unpack its contents into your `image-builder/images/capi` directory.
After extracting the contents, you may need to move them up one level, so that `build_image.sh`, `apply_goss.sh` etc. are directly under `/images/capi`.

1. From the `image-builder/images/capi` directory, run `build-image.sh` to create your image:

   ```
   ./build-image.sh
   ```

1. Parse and record the values listed in the output as follows, to reference later in the BoM file as **name**, **resourceGroup**, **subscriptionID**, **gallery**, and **version**:

   - `ManagedImageName`: **name**
   - `ManagedImageSharedImageGalleryId`: `/subscriptions/`**subscriptionID**`/resourceGroups/`**cluster-api-images**`/providers/Microsoft.Compute/galleries/`**gallery**`/images/capi-ubuntu-1804/versions/`**version**

   For example, this output from `build-image.sh`:
   ```
   ManagedImageName: capi-1602021415
   ManagedImageSharedImageGalleryId: /subscriptions/881e14ab-d120-412d-b8ad-8f555fd86943/resourceGroups/cluster-api-images/providers/Microsoft.Compute/galleries/ClusterAPI/images/capi-ubuntu-1804/versions/0.3.1602021415
   ```
   ...yields:

   - name: `capi-1602021415`
   - resourceGroup: `cluster-api-images`
   - subscriptionID: `881e14ab-d120-412d-b8ad-8f555fd86943`
   - gallery: `ClusterAPI`
   - version: `0.3.1602021415`

**Troubleshooting**

In some cases of component versioning, [Goss](https://github.com/aelsabbahy/goss) tests fail.
We are working on this.

If Goss tests fail:

1. Edit the `images/capi/packer/config/goss-args.json` file in Image Builder directory to set `"goss_inspect_mode": "true"`.
1. Run `build-image` again.
1. After the image is deployed, SSH into the VM manually and run tests there.

**References**

- [Building Images for Azure](https://image-builder.sigs.k8s.io/capi/providers/azure.html) in the Kubernetes Image Builder documentation.

- [Custom images](https://capz.sigs.k8s.io/topics/custom-images.html) in the Cluster API Azure documentation.

## <a id="bom"></a> Edit the Tanzu Kubernetes Grid Bill of Materials

Once your custom image is available in Azure Shared Image Gallery, update the Tanzu Kubernetes Grid
management cluster Bill of Materials (BoM) YAML file to point to it:

1. In `~/.tkg/bom`, find the BoM file that matches your Image Builder configuration version, based on its Kubernetes version:
   - If a Kubernetes version is not the default for a Tanzu Kubernetes Grid version, its BoM file is named for the Kubernetes version.
   For example, `bom-1.18.8+vmware.1.yaml` could use an image created with `image-builder-1.18.8-cfg`.
   - If a Kubernetes version is the default for a Tanzu Kubernetes Grid version, its BoM file is named for the Tanzu Kubernetes Grid version.
   For example, `bom-1.2.0+vmware.1.yaml` could use an image created with `image-builder-1.19.1-cfg` because v1.19.1 is the default Kubernetes version in Tanzu Kubernetes Grid v1.2.0.
   - In all cases, a BoM file's `components.kubernetes.version` field indicates its Kubernetes version.

1. In the BoM file, replace the entire `azure: ` block with the following, using values recorded from the `build-image.sh` output.
   - This replaces the `publisher` and `sku` values for a Marketplace image with `gallery` and `name` values for a Shared Image Gallery image.

    ```
    azure:
      resourceGroup: <resourceGroup>
      name: <name>
      subscriptionID: <subscriptionID>
      gallery: <gallery>
      version: <version>
    ```

## <a id="what-next"></a> What to Do Next

With the BoM file pointing to your custom VM image, you can now deploy your management cluster or a workload cluster to Azure:

- [Deploy Management Clusters to Microsoft Azure with the Installer Interface](../mgmt-clusters/azure-ui.md).
- [Deploy Management Clusters to Microsoft Azure with the CLI](../mgmt-clusters/azure-cli.md).
- [Create Tanzu Kubernetes Clusters](../tanzu-k8s-clusters/create.md)
