# Building Cluster API Machine Images

[Cluster API (CAPI)](https://github.com/kubernetes-sigs/cluster-api) is built on the principles of immutable infrastructure. All nodes
that make up a cluster are derived from a common template, or machine image.

When CAPI begins creating a cluster from the machine image, it expects several
things to be pre-configured and installed, including:

* Correct versions of `kubeadm`, `kubelet` and `kubectl` as specified in the
workload cluster manifest.
* Container runtime (most often `containerd`) installed and running
* Access to all required images for `kubeadm init` (and `kubeadm join`). If the
images are not published and must be pulled locally (as is the case for VMware
signed images) these images must be baked into the machine image.
* `cloud-init` installed and configured to accept bootstrap instructions on first boot.

To further complicate things, each CAPI provider requires it's own machine
image format. The linked guides covers building the following machine image formats:

 * Cluster API Provider AWS (CAPA)
    * AMI - Amazon Machine Image
    * Image builds are derived from published AMIs in AWS (such as official
      Ubuntu AMIs). Builds occur inside AWS and are stored in the builder's
      AWS account in one or many regions.

 * Cluster API Provider vSphere (CAPV)
    * OVA - Open Virtualization Archive
    * Image builds are derived from the Linux distributions's  original installation `ISO`.
    * The resulting OVA is then imported into a vSphere cluster, a snapshot is
    taken for fast cloning, and is then marked as a `vm template`.

Machine images can also include additional software and configuration during the
build process based on your own custom specifications. Before making any
modifications, please consult with VMware CRE for best practices and recommendations.

While the above may seem complicated and complex, you can leverage existing
projects and tooling to streamline the process.

### Extending the Kubernetes `image-builder` project

[`image-builder`](https://github.com/kubernetes-sigs/image-builder) is an
official upstream Kubernetes project dedicated to building
machine images. The process it uses to build images is as follows:

* `packer` is used as a project base to begin building a machine image. This
allows you to create machine images for virtually any current (and future) CAPI
provider in an uniform, automated manner.
* `ansible` is used to configure machines during the provisioning stage. This
allows you to use a common playbook targeting multiple distribution families such
as Ubuntu and CentOS.
* Finally, packer will "stamp" the machine and publish it for use according to
the provider you are using. At this point you can launch workload clusters using the
freshly minted machine image via the workload cluster manifests.

## Build Images for vSphere, Amazon EC2, and Azure

* [Build and Use Custom OVA Images on vSphere](capv-images.md)
* [Build and Use Custom AMI Images on Amazon EC2](capa-images.md)
* [Build and Use Custom VM Images on Azure](capz-images.md)

