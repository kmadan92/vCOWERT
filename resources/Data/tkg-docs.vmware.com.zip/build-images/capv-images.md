# Build and Use Custom OVA Images on vSphere

## <a id="prerequisites"></a> Prerequisites

* Before beginning you should be familiar with
[Cluster API](https://github.com/kubernetes-sigs/cluster-api)
and read more [about building images](index.md)
using this guide
* A vSphere administrator account
* A [github](https://github.com) account
* A macOS or Linux workstation with the following installed:
  * [Python 3](https://www.python.org/downloads/) with the [distutils](https://docs.python.org/3/library/distutils.html) library
  * [make](https://www.gnu.org/software/make/)

## <a id="build"></a> Build an Image with Kubernetes Image Builder

To build a custom OVA image on vSphere on your local workstation:

1. Clone the Kubernetes [Image Builder](https://github.com/kubernetes-sigs/image-builder.git) tool.

  ```bash
  git clone https://github.com/kubernetes-sigs/image-builder.git
  ```

1. Change directory to the cloned image-builder repository:

  ```bash
  cd image-builder/images/capi
  ```

1. Install required dependencies for vSphere:

  ```bash
  make deps-ova
  ```

1. If the `make deps-ova` output states that it installed binaries to the `.local/bin` directory, move these files into your `$PATH`.  For example:

   ```bash
   mv .local/bin/packer /usr/local/bin
   ```

1. Determine the Image Builder configuration version that you want to build from.

   - Search the VMware {code} [Sample Exchange](https://code.vmware.com/samples) for `TKG Image Builder` to see the available versions.
   - Each version corresponds to the Kubernetes versions that it uses.
   For example, `image-builder-1.19.1-cfg.zip` builds a Kubernetes v1.19.1 image.
   - To create a management cluster, such as when you are first installing Tanzu Kubernetes Grid, choose the default Kubernetes version for your version of Tanzu Kubernetes Grid.
   For Tanzu Kubernetes Grid v1.2.0, the default Kubernetes version is v1.19.1.

1. Download the configuration code zipfile and unpack its contents.  You can unpack it within the `image-builder` directory structure or elsewhere.

1. Within this extracted Image Builder configuration directory, in the subdirectory that contains `build-image.sh`, `kubernetes.json` and other files, create a file called `vsphere.json` with contents:

    ```
    {
        "vcenter_server": "",
        "datacenter": "",
        "username": "administrator@vsphere.local",
        "password": "",
        "datastore": "",
        "folder": "",
        "cluster": "",
        "network": "VM Network",
        "insecure_connection": "false",
        "create_snapshot": "true",
        "convert_to_template": "true"
    }
    ```
  
      * Edit the `vcenter_server` field to include the IP address or FQDN of your vCenter.
      * Edit the `datacenter` field to an appropriate vSphere datacenter.
      * Edit the `username` and `password` fields with a vSphere account that has access to create VMs and Templates.
      * Edit the `datastore` to a vSphere datastore to use for VM creation and installation media.
      * Edit the `cluster` field to include an appropriate compute resource.
      * Edit the `network` field with an appropriate VM network, that has access to internet resources.
      * Set the `insecure_connection` field to `true` if your vCenter uses a self-signed certificate.
      * Set the `create_snapshot` field to `true` if you plan on using the built template to generate other templates later.
      * Set the `convert_to_template` field to `true` if you plan on using the built template to generate other templates later.

1. In the `kubernetes.json` file, confirm or edit the Kubernetes version setting `kubernetes_semver`, and source setting `kubernetes_http_source`.

   - For open source, upstream `kubernetes_semver` values such as `v1.19.1`, `kubernetes_http_source` must refer to an open source bucket.
   - Downstream, VMware Kubernetes versions such as `v1.19.1+vmware.2` have a `+vmware` suffix and require `kubernetes_http_source` to point to VMware's build artifactory.

1. Edit the `osstp.json` file in the same directory replacing the `.` in the `custom_role_names` value with the full path to the `ansible_customize` directory (i.e. `pwd`).

1. Set an environment variable `PACKER_VAR_FILES` to point to the `.json` files in your configuration directory:

    ```bash
    export PACKER_VAR_FILES="`pwd`/kubernetes.json `pwd`/osstp.json `pwd`/vsphere.json"
    ```
1. From the `image-builder/images/capi` directory, run the following command to start the build process:

  **For Photon3:**
  ```bash
  make build-node-ova-vsphere-photon-3
  ```

  **For Ubuntu 18.04**
  ```bash
  make build-node-ova-vsphere-ubuntu-1804
  ```

  **For Red Hat Enterprise Linux 7**

    1. Download the Red Hat Enterprise Linux 7.7 ISO from [Red Hat Customer Portal](https://access.redhat.com) with SHA256 checksum of `88b42e934c24af65e78e09f0993e4dded128d74ec0af30b89b3cdc02ec48f028` and store it in your root like `/rhel-server-7.7-x86_64-dvd.iso`.  The filename must be exactly as shown and the checksum must match.
    1. Export a username and password with access to register a RHEL7 system with Red Hat Subscription Manager:

      ```bash
      export RHSM_USER='your username here'
      export RHSM_PASS='your password here'
      ```
    1. Build the image:

      ```bash
      make build-node-ova-vsphere-rhel-7
      ```

**References**

- [Building Images for vSphere](https://image-builder.sigs.k8s.io/capi/providers/vsphere.html) in the Kubernetes Image Builder documentation.

- [Customizing images](https://image-builder.sigs.k8s.io/capi/capi.html#customization)



## <a id="ova-import"></a> Import the OVA to vSphere

1. Prior to deploying a cluster with the built custom image, you must first import the OVA that was built.  This OVA can be found in the `./output` directory.  It is important to import this OVA, because the file has been tagged with the necessary parameters for TKGm to recognize the image as valid.  You *may* have to delete the template left behind on the vSphere prior to importing the OVA file.

1. Once the OVA has been imported to vSphere, you will need to convert it to a template prior to deploying a cluster.

1. If you have more than one template that was built for a particular version of Kubernetes on your vSphere (e.g. `photon3-1.19.1+vmware.2`, `ubuntu1804-1.19.1+vmware.2`, and `rhel7-1.19.1+vmware.2`) then you can export the template name to use when deploying a TKGm cluster to vSphere:

    ```bash
    export VSPHERE_TEMPLATE='name of the template in vSphere'
    ```

## <a id="what-next"></a> What to Do Next

- [Deploy Management Clusters to vSphere with the Installer Interface](../mgmt-clusters/vsphere-ui.md)
- [Deploy Management Clusters to vSphere with the CLI](../mgmt-clusters/vsphere-cli.md)
- [Create Tanzu Kubernetes Clusters](../tanzu-k8s-clusters/create.md)
