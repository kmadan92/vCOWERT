#  Install the Tanzu Kubernetes Grid CLI

To install Tanzu Kubernetes Grid, you download the Tanzu Kubernetes Grid command line interface (CLI) on a local system, known as the bootstrap machine. The bootstrap machine is the laptop, host, or server on which the initial bootstrapping of a management cluster is performed. This is where you run Tanzu Kubernetes Grid CLI commands. Tanzu Kubernetes Grid creates a temporary management cluster using a [Kubernetes in Docker](https://kind.sigs.k8s.io/) (`kind`) cluster on the bootstrap machine. After creating the temporary management cluster locally, Tanzu Kubernetes Grid uses it to provision the final management cluster in the platform of your choice. 

- [Prerequisites](#prereqs)
- [Download and Unpack the Tanzu Kubernetes Grid CLI and kubectl](#download)
- [Install the Tanzu Kubernetes Grid CLI](#install-cli)
- [Install kubectl](#install-kubectl)
- [Initialize the Tanzu Kubernetes Grid CLI](#initialize)
- [CLI Short Names and Aliases](#short-names)
- [Common Tanzu Kubernetes Grid CLI Options](#common-options)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites 

Tanzu Kubernetes Grid provides CLI binaries for Linux, Mac OS, and Windows systems. 

The bootstrap machine on which you run the Tanzu Kubernetes Grid CLI must meet the following requirements:

- If you intend to use the Tanzu Kubernetes Grid installer interface, a browser is available. You can use the Tanzu Kubernetes Grid CLI without a browser, but for first deployments it is **strongly recommended** to use the installer interface.
- [Docker](https://docs.docker.com/install/) is installed and running, if you are installing Tanzu Kubernetes Grid on Linux.
- [Docker Desktop](https://www.docker.com/products/docker-desktop) is installed and running, if you are installing Tanzu Kubernetes Grid on Mac OS or Windows.
- System time is synchronized with a Network Time Protocol (NTP) server.

If you are running Docker Desktop on Mac OS, the `kind` container requires at least 6GB of RAM. For information about how to configure Docker Desktop so that it can run `kind`, see [Settings for Docker Desktop](https://kind.sigs.k8s.io/docs/user/quick-start/#settings-for-docker-desktop) in the `kind` documentation.

**NOTE**: Tanzu Kubernetes Grid uses [Cluster API](https://cluster-api.sigs.k8s.io/). If you have previously used Cluster API on the machine that you are using as your bootstrap machine, you must delete the `~/.cluster-api` folder from that machine. This folder contains Cluster API configuration files that might interfere with the correct operation of Tanzu Kubernetes Grid.

## <a id="download"></a> Download and Unpack the Tanzu Kubernetes Grid CLI and `kubectl`

The `tkg` CLI ships with a compatible version of the `kubectl` CLI. To download and unpack both:

1. Go to [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg) and log in with your My VMware credentials.
1. Under **Product Downloads**, click **Go to Downloads**.
1. Scroll down to the **VMware Tanzu Kubernetes Grid 1.2.0 CLI** and **kubectl** entries and click the **Download Now** button:

   - For Linux, download **VMware Tanzu Kubernetes Grid CLI for Linux** and **kubectl cluster cli v1.19.1 for Linux**.
   - For Mac OS, download **VMware Tanzu Kubernetes Grid CLI for Mac** and **kubectl cluster cli v1.19.1 for Mac**.
   - For Windows, download **VMware Tanzu Kubernetes Grid CLI for Windows** and **kubectl cluster cli v1.19.1 for Windows**.

1. Use either the `tar -xzvf` command or the extraction tool of your choice to unpack the Tanzu Kubernetes Grid CLI binaries for your operating system:
   
   - For Linux, unpack `tkg-linux-amd64-v1.2.0-vmware.1.tar.gz`.
   - For Mac OS, unpack `tkg-darwin-amd64-v1.2.0-vmware.1.tar.gz`.
   - For Windows, unpack `tkg-windows-amd64-v1.2.0-vmware.1.tar.gz`.
   
   In the `tkg` folder, the unpacked CLI binary files are `tkg-linux-amd64-v1.2.0+vmware.1`, `tkg-darwin-amd64-v1.2.0+vmware.1`, or `tkg-windows-amd64-v1.2.0+vmware.1`. The other files in the `tkg` folder, such as `ytt`, `kapp`, and `kbld`, are required by the Tanzu Kubernetes Grid extensions. You will need them later when you install the extensions.

1. Unpack the `kubectl` binary the same way you unpacked the CLI.
The unpacked kubectl binary files are `kubectl-linux-v1.19.1-vmware.2`,`kubectl-mac-v1.19.1-vmware.2`, or `kubectl-windows-v1.19.1-vmware.2.exe`.

## <a id="install-cli"></a> Install the Tanzu Kubernetes Grid CLI

After you have downloaded and unpacked the Tanzu Kubernetes Grid CLI binary on your bootstrap machine, you must make it available to the system.

1. Navigate to the executable for the Tanzu Kubernetes Grid CLI that you downloaded and unpacked in the previous section.   
1. Rename the CLI binary for your platform to `tkg`, make sure that it is executable, and add it to your `PATH`.
   
   - Mac OS and Linux platforms: 

       1. Move the binary into the `/usr/local/bin` folder and rename it to `tkg`.<pre>mv ./tkg-linux-amd64-v1.2.0+vmware.1 /usr/local/bin/tkg</pre> <pre>mv ./tkg-darwin-amd64-v1.2.0+vmware.1 /usr/local/bin/tkg</pre>
       1. Make the file executable.<pre>chmod +x /usr/local/bin/tkg</pre>
   
   - Windows platforms:
   
        1. Create a new `Program Files\tkg` folder and copy the `tkg-windows-amd64-v1.2.0+vmware.1` binary into it. 
        1. Rename `tkg-windows-amd64-v1.2.0+vmware.1` to `tkg.exe`.
        1. Right-click the `tkg` folder, select **Properties** > **Security**, and make sure that your user account has the **Full Control** permission.
        1. Use Windows Search to search for `env`.
        1. Select **Edit the system environment variables** and click the **Environment Variables** button.
        1. Select the `Path` row under **System variables**, and click **Edit**. 
        1. Click **New** to add a new row and enter the path to the `tkg` binary.
   
1. At the command line in a new terminal, run `tkg version` to check that the correct version of the binary is properly installed.

   You should see information about the installed Tanzu Kubernetes Grid CLI version.
   
    ```
    Client:
	  Version: v1.2.0
	  Git commit: 05b233e75d6e40659247a67750b3e998c2d990a5
    ```
    
    If you are running on Mac OS, you might encounter the following error:
   
   ```
   "tkg" cannot be opened because the developer cannot be verified.
   ```
   If this happens, you need to create a security exception for the `tkg` executable. Locate the `tkg` app in Finder, control-click the app, and select **Open**.  

## <a id="install-kubectl"></a> Install `kubectl`

To install the version of `kubectl` compatible with the Tanzu Kubernetes Grid CLI, use the same process as in [Install the Tanzu Kubernetes Grid CLI](#install-cli) above, but with the following substitutions:

- Navigate to the executable you downloaded for `kubectl`.
- Rename the `kubectl-PLATFORM-v1.19.1-vmware` executable to `kubectl` (Linux, Mac) or `kubectl.exe` (Windows).
- Run `kubectl version` to check the correct version, and create a security exception if needed.


## <a id="initialize"></a> Initialize the Tanzu Kubernetes Grid CLI

1. Run `tkg --help` to see the list of commands that the Tanzu Kubernetes Grid CLI provides.

   You can run any command with the `--help` option to see information about that specific command or sub-command. For example, `tkg init --help` or `tkg create cluster --help`. 
1. Run the `tkg get management-cluster` command.

   ```
   tkg get management-cluster
   ```  

   Running a `tkg` command for the first time creates the `~/.tkg` folder in your home directory, that contains the Tanzu Kubernetes Grid configuration files.
   
   - The cluster configuration file `~/.tkg/config.yaml`, from which management clusters and Tanzu Kubernetes clusters are created. 
   - The `~/.tkg/bom` folder, containing `bom-*.yaml` files that provide references to the correct versions of all of the packages that Tanzu Kubernetes Grid requires when creating clusters for all of the versions of Kubernetes that it supports.
   
## <a id="short-names"></a> CLI Short Names and Aliases

Most of the Tanzu Kubernetes Grid CLI commands and options have short names or aliases, so that you do not have to type the full command and option names each time you run `tkg`. For example, `-h` for `--help`, and `mc` for `management-cluster`. For increased clarity, this documentation always uses the full command and option names. To see the shortnames and aliases for commands and options, run CLI commands with the `--help` option.

## <a id="common-options"></a> Common Tanzu Kubernetes Grid CLI Options

The Tanzu Kubernetes Grid CLI provides common options that can be used with all of the CLI commands.

<table width="100%" border="0">
  <tr>
    <th width="20%" scope="col">Option</th>
    <th width="80%" scope="col">Description</th>
  </tr>
  <tr>
    <td><code>--config</code></td>
    <td>The path to the cluster configuration file, if it is not stored in the default location with the default name, <code>~/.tkg/config.yaml</code>. For example, <code>tkg init --ui --config /path/my-cluster-config.yaml</code>.</td>
  </tr>
  <tr>
    <td><code>--help</code></td>
    <td>Show help for the current command. For example, <code>tkg create cluster --help</code>.</td>
  </tr>
  <tr>
    <td><code>--kubeconfig</code></td>
    <td>The path to the shared <code>kubeconfig</code> file for management clusters and Tanzu Kubernetes clusters, if it is not stored in the default location, <code>~/.kube-tkg/config</code>. For example, <code>tkg init --ui --kubeconfig /path/my-cluster-kubeconfig</code>.</td>
  </tr>
  <tr>
    <td><code>--log_file</code></td>
    <td>Specify a file in which to save the logs for the current command. For example, <code>tkg scale cluster my-cluster --worker-machine-count=9 --log_file=my-cluster-scale-logs</code>.</td>
  </tr>
  <tr>
    <td><code>--quiet</code></td>
    <td>Mute all output for the current command.</td>
  </tr>
  <tr>
    <td><code>--v</code></td>
    <td>Set the logging verbosity level for the command.</td>
  </tr>
</table>

## <a id="what-next"></a> What to Do Next

The Tanzu Kubernetes Grid CLI is ready. You can set up your bootstrap machine to deploy management clusters to vSphere, Amazon EC2, and Microsoft Azure. 

- For information about how to deploy management clusters to your chosen platform, see [Deploying and Managing Management Clusters](mgmt-clusters/deploy-management-clusters.md).
- If you have vSphere 7 and the vSphere with Tanzu feature is enabled, you can directly use the Tanzu Kubernetes Grid CLI to deploy Tanzu Kubernetes clusters to vSphere with Tanzu, without deploying a management cluster. For information about how to connect the Tanzu Kubernetes Grid CLI to a vSphere with Tanzu Supervisor Cluster, see [Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster](tanzu-k8s-clusters/connect-vsphere7.md).