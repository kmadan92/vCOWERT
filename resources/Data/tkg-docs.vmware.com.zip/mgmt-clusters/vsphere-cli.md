# Deploy Management Clusters to vSphere with the CLI

This topic describes how to use the Tanzu Kubernetes Grid CLI to deploy a management cluster to vSphere from a YAML configuration file.

- [Prerequisites](#prereqs)
- [Configure the `config.yaml` File](#config)
    - [Configuration Parameter Reference](#params-ref)
- [Run the `tkg init` Command](#tkg-init) 
    - [CLI Options Reference](#cli-ref)
    - [Tanzu Kubernetes Grid Service on vSphere 7](#vsphere-7)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

- Ensure that you have met the all of the requirements listed in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) and [Deploy Management Clusters to vSphere](vsphere.md). If you are deploying clusters in an internet-restricted environment, you must also perform the steps in see [Deploy Tanzu Kubernetes Grid to an Offline Environment](airgapped-environments.md).
- It is **strongly recommended** to use the Tanzu Kubernetes Grid installer interface rather than the CLI to deploy your first management cluster to vSphere. When you deploy a management cluster by using the installer interface, it populates the `config.yaml` file for the management cluster with the required parameters. You can use the created `config.yaml` as a model for future deployments from the CLI.

## <a id="config"></a> Configure the `config.yaml` File

The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. When you deploy a management cluster from the CLI, the `tkg init` command uses this configuration.

To configure the `config.yaml` file, follow the steps below:

1. If this is the first time that you are running Tanzu Kubernetes Grid commands on this machine, and you have not already deployed a management cluster to vSphere by using the Tanzu Kubernetes Grid installer interface, open a terminal and run the `tkg get management-cluster` command:

   ```
   tkg get management-cluster
   ```  

   Running a `tkg` command for the first time creates the `$HOME/.tkg` folder, that contains the management cluster configuration file `config.yaml` and other configuration files.

2. Open the `.tkg/config.yaml` file in a text editor.

    - If you have already deployed a management cluster to vSphere from the installer interface, you will see variables that describe your previous deployment. 
       
    - If you have not already deployed a management cluster to vSphere from the installer interface, copy and paste the following rows at the end of  configuration file.
    
      ```
      VSPHERE_SERVER:
      VSPHERE_USERNAME:
      VSPHERE_PASSWORD:
      VSPHERE_DATACENTER:
      VSPHERE_DATASTORE:
      VSPHERE_NETWORK:
      VSPHERE_RESOURCE_POOL:
      VSPHERE_FOLDER:
      VSPHERE_SSH_AUTHORIZED_KEY:
      SERVICE_CIDR:
      CLUSTER_CIDR:
      VSPHERE_WORKER_DISK_GIB:
      VSPHERE_WORKER_NUM_CPUS:
      VSPHERE_WORKER_MEM_MIB:
      VSPHERE_CONTROL_PLANE_DISK_GIB:
      VSPHERE_CONTROL_PLANE_NUM_CPUS:
      VSPHERE_CONTROL_PLANE_MEM_MIB:
      ```

1. Edit the configuration file to update the information about the target vSphere environment and the configuration of the management cluster to deploy.
   
    The table in [Configuration Parameter Reference](#params-ref) describes all of the configuration options that you can provide for deployment of a management cluster to vSphere. Line order in the configuration file does not matter.
    
    The following example shows the configuration for a management cluster that corresponds to one that you would deploy from the installer interface by selecting the options for `small` control plane and worker nodes.
    
    ```
    VSPHERE_SERVER: <vcenter_server_address>
    VSPHERE_USERNAME: tkg-user@vsphere.local
    VSPHERE_PASSWORD: <vcenter_sso_password>
    VSPHERE_DATACENTER: /MY-DATACENTER
    VSPHERE_DATASTORE: /MY-DATACENTER/datastore/MyDatastore
    VSPHERE_NETWORK: VM Network
    VSPHERE_RESOURCE_POOL: /MY-DATACENTER/host/MY-CLUSTER/Resources
    VSPHERE_FOLDER: /MY-DATACENTER/vm/TKG-FOLDER
    VSPHERE_SSH_AUTHORIZED_KEY: ssh-rsa 
    NzaC1yc2EA [...] hnng2OYYSl+8ZyNz3fmRGX8uPYqw==
        email@example.com
    SERVICE_CIDR: 100.64.0.0/13
    CLUSTER_CIDR: 100.96.0.0/11
    VSPHERE_WORKER_DISK_GIB: "20"
    VSPHERE_WORKER_NUM_CPUS: "2"
    VSPHERE_WORKER_MEM_MIB: "2048" 
    VSPHERE_CONTROL_PLANE_DISK_GIB: "20"
    VSPHERE_CONTROL_PLANE_NUM_CPUS: "2"
    VSPHERE_CONTROL_PLANE_MEM_MIB: "2048"
    ```

### <a id="params-ref"></a> Configuration Parameter Reference    

The table below describes all of the variables that you must set for deployment to vSphere, along with some vSphere-specific optional variables. To set them in a configuration file, leave a space between the colon (`:`) and the variable value. For example:
    
```
VSPHERE_USERNAME: tkg-user@vsphere.local
```
   
**IMPORTANT**:

- As described in [Configuring the Management Cluster](deploy-management-clusters.md#configuring), environment variables override values from a configuration file. To use all settings from a `config.yaml`, unset any conflicting environment variables before you deploy the management cluster from the CLI.
- Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this topic.

<table width="100%" border="0">
  <tr>
    <th width="25%" scope="col">Option</th>
    <th width="25%" scope="col">Value</th>
    <th width="50%" scope="col">Description</th>
  </tr>
  <tr>
    <td><code>VSPHERE_SERVER:</code></td>
    <td><code>vCenter_Server_address</code></td>
    <td>The IP address or FQDN of the vCenter Server instance on which to deploy the management cluster.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_USERNAME:</code></td>
    <td><code>tkg-user@vsphere.local</code></td>
    <td>A vSphere user account with the required privileges for Tanzu Kubernetes Grid operation.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_PASSWORD:</code></td>
    <td><code>My_P@ssword!</code></td>
    <td>The password for the vSphere user account. This value is base64-encoded when you run <code>tkg init</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_DATACENTER:</code></td>
    <td><code>datacenter_name</code></td>
    <td>The name of the datacenter in which to deploy the management cluster, as it appears in the vSphere inventory. For example, <code>/MY-DATACENTER</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_DATASTORE:</code></td>
    <td><code>datastore_name</code></td>
    <td>The name of the vSphere datastore for the management cluster to use, as it appears in the vSphere inventory. For example, <code>/MY-DATACENTER/datastore/MyDatastore</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_NETWORK:</code></td>
    <td><code>VM Network</code></td>
    <td>The name of an existing vSphere network to use as the Kubernetes service network, as it appears in the vSphere inventory. For example, <code>VM Network</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_RESOURCE_POOL:</code></td>
    <td><code>resource_pool_name</code></td>
    <td>The name of an existing resource pool in which to place this Tanzu Kubernetes Grid instance, as it appears in the vSphere inventory. To use the root resource pool for a cluster, enter the full path, for example for a cluster named <code>cluster0</code> in datacenter <code>MY-DATACENTER</code>, the full path is <code>/MY-DATACENTER/host/cluster0/Resources</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_FOLDER:</code></td>
    <td><code>VM_folder_name</code></td>
    <td>The name of an existing VM folder in which to place Tanzu Kubernetes Grid VMs, as it appears in the vSphere inventory. For example, if you created a folder named <code>TKG</code>, the path is <code>/MY-DATACENTER/vm/TKG</code>.</td>
  </tr>
  <tr>
    <td><code>VSPHERE_WORKER_DISK_GIB:</code></td>
    <td><code>&quot;50&quot;</code></td>
    <td>The size in gigabytes of the disk for the worker node VMs. Include the quotes (<code>""</code>). You can also specify or override this value by using the <code>tkg init --size</code> or <code>--worker-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_WORKER_NUM_CPUS:</code></td>
    <td><code>&quot;2&quot;</code></td>
    <td>The number of CPUs for the worker node VMs. Include the quotes (<code>""</code>). Must be at least 2. You can also specify or override this value by using the <code>tkg init --size</code> or <code>--worker-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_WORKER_MEM_MIB:</code></td>
    <td><code>&quot;4096&quot;</code></td>
    <td>The amount of memory in megabytes for the worker node VMs. Include the quotes (<code>""</code>). You can also specify or override this value by using the <code>tkg init --size</code> or <code>--worker-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_CONTROL_PLANE_DISK_GIB:</code></td>
    <td><code>&quot;30&quot;</code></td>
    <td>The size in gigabytes of the disk for the control plane node VMs. Include the quotes (<code>""</code>). You can also specify or override this value by using the <code>tkg init --size</code> or <code>--controlplane-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_CONTROL_PLANE_NUM_CPUS:</code></td>
    <td><code>&quot;2&quot;</code></td>
    <td>The number of CPUs for the control plane node VMs. Include the quotes (<code>""</code>). Must be at least 2. You can also specify or override this value by using the <code>tkg init --size</code> or <code>--controlplane-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_CONTROL_PLANE_MEM_MIB:</code></td>
    <td><code>&quot;2048&quot;</code></td>
    <td>The amount of memory in megabytes for the control plane node VMs. Include the quotes (<code>""</code>). You can also specify or override this value by using the <code>tkg init --size</code> or <code>--controlplane-size</code> options. </td>
  </tr>
  <tr>
    <td><code>VSPHERE_SSH_AUTHORIZED_KEY:</code></td>
    <td><code>&quot;ssh-rsa 
  NzaC1yc2EA [...] hnng2OYYSl+8ZyNz3fmRGX8uPYqw==
    email@example.com&quot;</code></td>
    <td>Paste in the contents of the SSH public key that you created in <a href="vsphere.html">Deploy a Management Cluster to vSphere</a>.</td>
  </tr>
  <tr>
    <td><code>SERVICE_CIDR:</code></td>
    <td><code>100.64.0.0/13</code></td>
    <td>The CIDR range to use for the Kubernetes services. The recommended range is 100.64.0.0/13. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>CLUSTER_CIDR:</code></td>
    <td><code>100.96.0.0/11</code></td>
    <td>The CIDR range to use for pods. The recommended range is 100.96.0.0/11. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>ENABLE_MHC:</code></td>
    <td><code>"true"</code> or <code>"false"</code></td>
    <td>Enables or disables the <a href="https://cluster-api.sigs.k8s.io/developer/architecture/controllers/machine-health-check.html#machinehealthcheck"><code>MachineHealthCheck</code></a> controller, which provides node health monitoring and node auto-repair for Tanzu Kubernetes clusters. This option is enabled in the global Tanzu Kubernetes Grid configuration by default, for all Tanzu Kubernetes clusters. To disable <code>MachineHealthCheck</code> on the clusters that you deploy with this management cluster, set <code>ENABLE_MHC</code> to <code>false</code>. Set this variable only if you want to override your global configuration. You can enable or disable <code>MachineHealthCheck</code> on individual clusters after deployment by using the CLI. For instructions, see <a href="../tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a>.</td>
  </tr>
  <tr>
    <td><code>MHC_UNKNOWN_STATUS_TIMEOUT:</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>Unknown</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
  <tr>
    <td><code>MHC_FALSE_STATUS_TIMEOUT:</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>False</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
</table>

## <a id="tkg-init"></a> Run the `tkg init` Command

After you have updated `.tkg/config.yaml` you deploy a management cluster by running the `tkg init` command. The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. You provide more precise configuration information for individual clusters by running the `tkg init` command with different options.

**IMPORTANT**: Do not run multiple management cluster deployments on the same bootstrap machine at the same time. Do not change context or edit the `.kube-tkg/config` file while Tanzu Kubernetes Grid operations are running.

To control how `tkg init` connects to Tanzu Kubernetes Grid Service configuration on vSphere 7, see the [Tanzu Kubernetes Grid Service on vSphere 7](#vsphere-7) section below.

To deploy a management cluster to vSphere, you must at least specify the `--infrastructure vsphere` and `--vsphere-controlplane-endpoint-ip` options to `tkgi init`:

   ```
   tkg init --infrastructure vsphere --vsphere-controlplane-endpoint-ip <ip_address>
   ```
   
The table in [CLI Options Reference](#cli-ref) describes the required and additional command-line options for deploying a management cluster to vSphere.

**Monitoring Progress**

When you run `tkg init`, you can follow the progress of the deployment of the management cluster in the terminal.  For more detail, open the log file listed in the terminal output **Logs of the command execution can also be found at...**.

Deployment of the management cluster can take several minutes. The first run of `tkg init` takes longer than subsequent runs because it has to pull the required Docker images into the image store on your bootstrap machine. Subsequent runs do not require this step, so are faster.

The first run of `tkg init` also adds settings to your configuration file.

If `tkg init` fails before the management cluster deploys to vSphere, you should clean up artifacts on your bootstrap machine before you re-run `tkg init`. See the [Troubleshooting Tips](../troubleshooting-tkg/tips.html) topic for details.

### <a id="cli-ref"></a> CLI Options Reference

The table below describes command-line options that you can set for deployment to vSphere.

For example, to create a highly available vSphere management cluster `vsphere-management-cluster` in which all of the control plane and worker node VMs are `large` size:

   ```
   tkg init --infrastructure vsphere --vsphere-controlplane-endpoint-ip <ip_address> --name vsphere-management-cluster --plan prod --size large
   ```

<table width="100%" border="0">
<tr>
  <th width="25%" scope="col">Option</th>
  <th width="25%" scope="col">Value</th>
  <th width="50%" scope="col">Description</th>
</tr>
<tr>
  <td><code>--infrastructure</code></td>
  <td><code>vsphere</code></td>
  <td><strong>Required</strong></td>
</tr>
<tr>
  <td><code>--vsphere-controlplane-endpoint-ip</code></td>
  <td><code>&lt;ip_address&gt;</code></td>
  <td><strong>Required</strong>. Static virtual IP address for API requests to the management cluster.  For more information, see <a href="vsphere.md#load-balancer">Load Balancers for vSphere</a>.</td>
</tr>
<tr>
  <td><code>--deploy-tkg-on-vSphere7</code></td>
  <td rowspan=2 colspan=2>See <a href="#vsphere-7">Tanzu Kubernetes Grid Service on vSphere 7</a> below.</td>
</tr>
<tr>
  <td><code>--enable-tkgs-on-vSphere7</code></td>
</tr>
<tr>
  <td><code>--name</code></td>
  <td>Name for the management cluster</td>
  <td>Name must comply with DNS hostname requirements as outlined in <a href="https://tools.ietf.org/html/rfc952">RFC 952</a> and amended in <a href="https://tools.ietf.org/html/rfc1123">RFC 1123</a><br />
  If you do not specify a name, a unique name is generated.</td>
</tr>
<tr>
  <th colspan=3>Scaling and Availability
  </th>
</tr>
<tr>
  <td><code>--plan</code></td>
  <td><code>dev</code> or <code>prod</code></td>
  <td><code>dev</code> ("development"), the default, deploys a management cluster with a single control plane node.<br />
  <code>prod</code> ("production") deploys a highly available management cluster with three control plane nodes.</td>
</tr>
<tr>
  <th colspan=3>Configuration Files
  </th>
</tr>
<tr>
  <td><code>--config</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-config.yaml</code></td>
  <td>Configuration file to use or create, other than the default <code>$HOME/.tkg/config.yaml</code>. If the config file was not already created by hand or prior <code>tkg init</code> calls, it is created.  All other files are created in the default folder.<br />
  This option, for example, lets you deploy multiple management clusters that share a VNET.</td>
</tr>
<tr>
  <td><code>--kubeconfig</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-kubeconfig.yaml</code></td>
  <td>Kube configuration file or use, or create, other than the default <code>$HOME/.kube-tkg/config.yaml</code>.<br />
  This option lets you customize or share multiple <code>kubeconfig</code> files for multiple management clusters.</td>
</tr>
<tr>
  <th colspan=3>Nodes
  </th>
</tr>
<tr>
  <td><code>--size</code></td>
  <td rowspan=3>Machine size, designated as follows:
  <ul><li><code>small</code>: CPUs: 2, Memory: 2048&nbsp;MB, Disk: 20&nbsp;GB</li>
  <li><code>medium</code>: CPUs: 2, Memory: 4096&nbsp;MB, Disk: 40&nbsp;GB</li>
  <li><code>large</code>: CPUs: 2, Memory: 8192&nbsp;MB, Disk: 40&nbsp;GB</li>
  <li><code>extra-large</code>: CPUs: 4, Memory: 16384&nbsp;MB, Disk: 80&nbsp;GB</li></ul>
  </td>
  <td>Size for both control plane and worker node VMs.</td>
</tr>
<tr>
  <td><code>--controlplane-size</code></td>
  <td>Size for control plane node VMs. Overrides the <code>--size</code> option and <code>VSPHERE_CONTROL_PLANE_*</code> parameters.</td>
</tr>
<tr>
  <td><code>--worker-size</code></td>
  <td>Size for worker node VMs. Overrides the <code>--size</code> option <code>VSPHERE_WORKER_*</code> parameters.</td>
</tr>
<tr>
  <th colspan=3>Customer Experience Improvement Program
  </th>
</tr>
<tr>
  <td><code>--ceip-participation</code></td>
  <td><code>true</code> or <code>false</code></td>
  <td><code>false</code> opts out of the VMware Customer Experience Improvement Program. Default is <code>true</code>.<br />
  You can also opt in or out of the program after deploying  the management cluster. For information, see <a href="multiple-management-clusters.md#ceip">Opt in or Out of the VMware CEIP</a> and <a href="https://www.vmware.com/solutions/trustvmware/ceip.html">Customer Experience Improvement Program ("CEIP")</a>.</td>
</tr>
</table>


### <a id="vsphere-7"></a>Tanzu Kubernetes Grid Service on vSphere 7

On vSphere 7, the Supervisor Cluster built into the vSphere with Tanzu option provides a better experience than a management cluster deployed by Tanzu Kubernetes Grid, and you can use the TKG CLI to connect to the Supervisor Cluster. For information, see [Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster](../tanzu-k8s-clusters/connect-vsphere7.md).

To reflect the recommendation for Tanzu Kubernetes Grid Service, the Tanzu Kubernetes Grid CLI behaves as follows, controlled by the `--deploy-tkg-on-vSphere7` and `--enable-tkgs-on-vSphere7` flags to `tkg init`.

- vSphere with Tanzu enabled:
    - No `--enable-tkgs-on-vSphere7`: Informs you that deploying a management cluster is not possible, and exits.
    - With `--enable-tkgs-on-vSphere7`: Opens the vSphere Client at the address set by `VSPHERE_SERVER` in your `config.yml` or local environment, so you can configure your Supervisor Cluster as described in [Enable the Workload Management Platform with the vSphere Networking Stack](https://docs-staging.vmware.com/en/draft/VMware-vSphere/7.0/vmware-vsphere-with-tanzu/GUID-8D7D292B-43E9-4CB8-9E20-E4039B80BF9B.html) in the vSphere documentation.
- vSphere with Tanzu not enabled:
    - No `--deploy-tkg-on-vSphere7`: Informs you that deploying a Tanzu Kubernetes Grid management cluster is possible but not recommended, and prompts you to either quit the installation or continue to deploy the management cluster.
    - With `--deploy-tkg-on-vSphere7`: Deploys a TKG management cluster on vSphere7, against recommendation.

## <a id="what-next"></a> What to Do Next

- For information about what happened during the deployment of the management cluster, how to connect `kubectl` to the management cluster, and how to create namespaces see [Examine the Management Cluster Deployment](verify-deployment.md).
- For information about how to create namespaces in the management cluster, see [Create Namespaces in the Management Cluster](create-namespaces.md).
- If you need to deploy more than one management cluster, on any or all of vSphere, Azure, and Amazon EC2, see [Manage Your Management Clusters](multiple-management-clusters.md). This topic also provides information about how to add existing management clusters to your CLI instance, obtain credentials, scale and delete management clusters, and how to opt in or out of the CEIP.
