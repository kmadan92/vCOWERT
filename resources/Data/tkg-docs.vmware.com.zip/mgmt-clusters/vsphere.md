# Deploy Management Clusters to vSphere

Before you can use the Tanzu Kubernetes Grid CLI or installer interface to deploy a management cluster, you must prepare your vSphere environment. You must make sure that vSphere meets the general requirements, and import the base OS templates from which Tanzu Kubernetes Grid creates cluster node VMs. 

- [General Requirements ](#general-requirements)
- [Management Clusters Unnecessary on vSphere 7](#mc-vsphere7)
- [Load Balancers for vSphere](#load-balancer)
- [Required Permissions for the vSphere Account](#vsphere-permissions)
- [Create an SSH Key Pair](#ssh-key)
- [Import the Base OS Image Template into vSphere](#import-baseos)
- [What to Do Next](#what-next)

## <a id="general-requirements"></a> General Requirements 

- Perform the steps described in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md).
- You have a vSphere 6.7u3 instance with an Enterprise Plus license.
- If you have vSphere 7, see [Management Clusters Unnecessary on vSphere 7](#mc-vsphere7) below.
- Your vSphere instance has the following objects in place:
    - Either a standalone host or a vSphere cluster with at least two hosts
    - If you are deploying to a cluster, ideally vSphere DRS is enabled
    - Optionally, a resource pool in which to deploy the Tanzu Kubernetes Grid Instance
    - A VM folder in which to collect the Tanzu Kubernetes Grid VMs
    - A datastore with sufficient capacity for the control plane and worker node VM files
    - If you intend to deploy multiple Tanzu Kubernetes Grid instances to this vSphere instance, create a dedicated resource pool, VM folder, and network for each instance that you deploy.
- You have a network with a DHCP server to which to connect the cluster node VMs that Tanzu Kubernetes Grid deploys. The node VMs must be able to connect to vSphere.
- You have a set of available static IP addresses for the clusters that you create. Make sure that these IP addresses are not in the DHCP range, but are in the same subnet as the DHCP range. For more information, see [Load Balancers for vSphere](#load-balancer).
- Traffic to vCenter Server is allowed from the network on which clusters will run
- The Network Time Protocol (NTP) service is running on all hosts, and the hosts are running on UTC. To check the time settings on hosts, perform the following steps:
   - Use SSH to log in to the ESXi host.
   - Run the `date` command to see the timezone settings.
   - If the timezone is incorrect, run `esxcli system time set`.
- If your vSphere environment runs NSX-T Data Center, you can use the NSX-T Data Center interfaces when you deploy management clusters. Make sure that your NSX-T Data Center setup includes a segment on which DHCP is enabled. Make sure that NTP is configured on all ESXi hosts, on vCenter Server, and on the bootstrap machine.
- You have a vSphere account that has at least the permissions described in [Required Permissions for the vSphere Account](#vsphere-permissions).

## <a id="mc-vsphere7"></a> Management Clusters Unnecessary on vSphere 7

On vSphere 7, enabling the vSphere with Tanzu feature provides a built-in Tanzu Kubernetes Grid Service. The Tanzu Kubernetes Grid Service includes a Supervisor Cluster that performs the same role as a management cluster deployed by Tanzu Kubernetes Grid. This means that you do not need to deploy a management cluster on vSphere 7, and the Tanzu Kubernetes Grid installer discourages you from doing so.

The Tanzu Kubernetes Grid CLI can connect to the Supervisor Cluster on vSphere 7 and to Tanzu Kubernetes Grid management clusters deployed to Azure, Amazon EC2, and vSphere 6.7u3, letting you deploy and manage Tanzu Kubernetes clusters across multiple infrastructures using a single tool. For more information, see [Use the Tanzu Kubernetes Grid CLI with a vSphere with Tanzu Supervisor Cluster](../tanzu-k8s-clusters/connect-vsphere7.md).

If the vSphere with Tanzu feature is not enabled in vSphere 7, you can still deploy a Tanzu Kubernetes Grid management cluster, but it is not recommended. For information about the vSphere with Tanzu feature in vSphere 7, see [vSphere with Tanzu Configuration and Management](https://docs.vmware.com/en/VMware-vSphere/7.0/vmware-vsphere-with-kubernetes/GUID-152BE7D2-E227-4DAA-B527-557B564D9718.html) in the vSphere 7 documentation.

## <a id="load-balancer"></a> Load Balancers for vSphere

Each management cluster and Tanzu Kubernetes cluster that you deploy to vSphere requires one static virtual IP address for external requests to the cluster's API server.
You must be able to assign this IP address, so it cannot be within your DHCP range, but it must be in the same subnet as the DHCP range.

The cluster control plane's [Kube-vip](https://kube-vip.io/) pod uses this static virtual IP address to load-balance API requests across multiple nodes, and the API server certificate includes the address to enable secure TLS communication.

**NOTE**: `Kube-vip` is an in-cluster load balancer that is solely used by the API server. It is not a general purpose `Service type: load-balancer` for vSphere. Tanzu Kubernetes Grid does not currently provide a `Service type: load-balancer` for vSphere. If you require load balancing, you can use a solution such as [MetalLB](https://metallb.universe.tf/).
        
## <a id="vsphere-permissions"></a> Required Permissions for the vSphere Account

The vCenter Single Sign On account that you provide to Tanzu Kubernetes Grid when you deploy a management cluster must have at the correct permissions in order to perform the required operations in vSphere.  

It is not recommended to provide a vSphere administrator account to Tanzu Kubernetes Grid, because this provides Tanzu Kubernetes Grid with far greater permissions than it needs. The best way to assign permissions to Tanzu Kubernetes Grid is to create a role and a user account, and then to grant that user account that role on vSphere objects.

**NOTE**: If you are deploying Tanzu Kubernetes clusters to vSphere 7 and vSphere with Tanzu is enabled, you must set the **Global** > **Cloud Admin** permission in addition to the permissions listed below. If you intend to use Velero to back up and restore management clusters, you must also set the permissions listed in [Credentials and Privileges for VMDK Access](https://code.vmware.com/docs/11750/virtual-disk-development-kit-programming-guide/GUID-8301C6CF-37C2-42CC-B4C5-BB1DD28F79C9.html) in the *Virtual Disk Development Kit Programming Guide*.

1. In the vSphere Client, go to **Administration** > **Access Control** > **Roles**, and create a new role, for example `TKG`, with the following permissions.
   
   <table width="100%" border="0">
   <tr>
    <th scope="col">vSphere Object </th>
    <th scope="col">Required Permission </th>
   </tr>
   <tr>
    <td>Cns</td>
    <td>Searchable</td>
   </tr>
   <tr>
    <td>Datastore</td>
    <td>Allocate space<br />
    Browse datastore<br />
	Low level file operations</td>
   </tr>
   <tr>
    <td>Global (if using Velero for backup and restore)</td>
    <td>Disable methods<br />
    Enable methods<br />
	Licenses</td>
   </tr>
   <tr>
    <td>Network</td>
    <td>Assign network</td>
   </tr>
   <tr>
    <td>Profile-driven storage</td>
    <td>Profile-driven storage view</td>
   </tr>
   <tr>
    <td>Resource</td>
    <td>Assign virtual machine to resource pool</td>
   </tr>
   <tr>
     <td>Sessions</td>
     <td>Message<br />
     Validate session</td>
   </tr>  
   <tr>
    <td>Virtual machine</td>
    <td>
      Change Configuration &gt; Add existing disk<br />
      Change Configuration &gt; Add new disk<br />
      Change Configuration &gt; Add or remove device<br />
      Change Configuration &gt; Advanced configuration<br />
      Change Configuration &gt; Change CPU count<br />
      Change Configuration &gt; Change Memory<br />
      Change Configuration &gt; Change Settings<br />
      Change Configuration &gt; Configure Raw device<br />
      Change Configuration &gt; Extend virtual disk<br />
      Change Configuration &gt; Modify device settings<br />
      Change Configuration &gt; Remove disk<br />
      Edit Inventory &gt; Create from existing<br />
      Edit Inventory &gt; Remove<br />
      Interaction &gt; Power On<br />
      Interaction &gt; Power Off<br />
      Provisioning &gt; Deploy template</td>
   </tr>
   <tr>
    <td>vApp</td>
    <td>Import</td>
   </tr>
   </table>
1. In **Administration** > **Single Sign On** > **Users and Groups**, create a new user account in the appropriate domain, for example `tkg-user`.
1.  In the **Hosts and Clusters**, **VMs and Templates**, **Storage**, and **Networking** views, right-click the objects that your Tanzu Kubernetes Grid deployment will use, select **Add Permission**, and assign the `tkg-user`  with the `TKG` role to each object.

   - Hosts and Clusters
      - The vCenter Server instance
      - The Datacenter and all of the Host and Cluster folders, from the Datacenter object down to the cluster that manages the Tanzu Kubernetes Grid deployment
      - Target hosts and clusters
      - Target resource pools, with propagate to children enabled
   - VMs and Templates
      - The deployed Tanzu Kubernetes Grid base image templates
      -  Target VM and Template folders, with propagate to children enabled
   - Storage
      - Datastores and all storage folders, from the Datacenter object down to the datastores that will be used for Tanzu Kubernetes Grid deployments 
   - Networking
      - Networks or distributed port groups to which clusters will be assigned
      - Distributed switches
   
## <a id="ssh-key"></a> Create an SSH Key Pair

In order for the Tanzu Kubernetes Grid CLI to connect to vSphere from the machine on which you run it, you must provide the public key part of an SSH key pair to Tanzu Kubernetes Grid when you deploy the management cluster. If you do not already have one on the machine on which you run the CLI, you can use a tool such as `ssh-keygen` to generate a key pair.

1. On the machine on which you will run the Tanzu Kubernetes Grid CLI, run the following `ssh-keygen` command.

   <pre>ssh-keygen -t rsa -b 4096 -C "<em>email@example.com</em>"</pre>
1. At the prompt `Enter file in which to save the key (/root/.ssh/id_rsa):` press Enter to accept the default.
1. Enter and repeat a password for the key pair.
1. Add the private key to the SSH agent running on your machine, and enter the password you created in the previous step.

   ```
   ssh-add ~/.ssh/id_rsa
   ```
1. Open the file `.ssh/id_rsa.pub` in a text editor so that you can easily copy and paste it when you deploy a management cluster.
 
## <a id="import-baseos"></a> Import the Base OS Image Template into vSphere

Before you can deploy a management cluster or Tanzu Kubernetes clusters to vSphere, you must provide a base OS image template to vSphere. Tanzu Kubernetes Grid creates the management cluster and Tanzu Kubernetes cluster node VMs from this template. Tanzu Kubernetes Grid provides a base OS image template in OVA format for you to import into vSphere. After importing the OVA, you must convert the resulting VM into a VM template. The base OS image template includes the version of Kubernetes that Tanzu Kubernetes Grid uses to create clusters.

**NOTE**: Tanzu Kubernetes Grid 1.2.0 adds support for Kubernetes v1.19.1, v1.18.8, and v1.17.11. You can also use this version of Tanzu Kubernetes Grid to deploy clusters that run Kubernetes versions that were supported in previous releases of Tanzu Kubernetes Grid. If you want to deploy clusters with older versions of Kubernetes, either install or retain in your vSphere inventory the versions of the base OS image templates from the previous Tanzu Kubernetes Grid releases, alongside the new Kubernetes templates for this release. For information about the versions of Kubernetes that each Tanzu Kubernetes Grid release supports, see the release notes for that release.

1. Go to [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg) and log in with your My VMware credentials.
1. Download the Tanzu Kubernetes Grid OVAs for node VMs. 

   - Kubernetes v1.19.1: **Photon v3 Kubernetes v1.19.1 OVA**
   - Kubernetes v1.18.8: **Photon v3 Kubernetes v1.18.8 OVA**
   - Kubernetes v1.17.11: **Photon v3 Kubernetes v1.17.11 OVA**
   
   If you want to use Tanzu Kubernetes Grid 1.2 to deploy clusters with older versions of Kubernetes as well as those added in this release, after downloading the OVAs above, select an earlier Tanzu Kubernetes Grid version in the downloads page, and download the corresponding **Photon v3 Kubernetes *version* OVA** files.
1. In the vSphere Client, right-click an object in the vCenter Server inventory, select **Deploy OVF template**.
1. Select **Local file**, click the button to upload files, and navigate to the downloaded OVA file on your local machine.
1. Follow the installer prompts to deploy a VM from the OVA projects-stg.registry.vmware.com/tkg. 

    - Accept or modify the appliance name
    - Select the destination datacenter or folder
    - Select the destination host, cluster, or resource pool
    - Accept the end user license agreements (EULA)
    - Select the disk format and destination datastore
    - Select the network for the VM to connect to
    
    **NOTE**: If you select thick provisioning as the disk format, when Tanzu Kubernetes Grid creates cluster node VMs from the template, the full size of each node's disk will be reserved. This can rapidly consume storage if you deploy many clusters or clusters with many nodes. However, if you select thin provisioning, as you deploy clusters this can give a false impression of the amount of storage that is available. If you select thin provisioning, there might be enough storage available at the time that you deploy clusters, but storage might run out as the clusters run and accumulate data.
1. Click **Finish** to deploy the VM.
1. When the OVA deployment finishes, right-click the VM and select **Template** > **Convert to Template**.

   **NOTE**: Do not power on the VM before you convert it to a template.
1. In the **VMs and Templates** view, right-click the new template, select **Add Permission**, and assign the `tkg-user` to the template with the `TKG` role.

   For information about how to create the user and role for Tanzu Kubernetes Grid, see [Required Permissions for the vSphere Account](#vsphere-permissions) above.
   
Repeat the procedure for each of the Kubernetes versions for which you downloaded the OVA file.

## <a id="what-next"></a> What to Do Next

If you are using Tanzu Kubernetes Grid in an environment with an external internet connection, you are now ready to deploy management clusters to vSphere.

- [Deploy Management Clusters to vSphere with the Installer Interface](vsphere-ui.md). This is the preferred option for first deployments.
- [Deploy Management Clusters to vSphere with the CLI](vsphere-cli.md). This is the more complicated method,  that allows greater flexibility of configuration and automation.
- If you are using Tanzu Kubernetes Grid in an internet-restricted environment, see [Deploy Tanzu Kubernetes Grid to an Offline Environment](airgapped-environments.md) for the additional steps to perform.
- If you want to deploy clusters to Amazon EC2 and Azure as well as to vSphere, see [Deploy Management Clusters to Amazon EC2](aws.html) and [Deploy Management Clusters to Microsoft Azure](azure.md) for the required setup for those platforms.