# Deploy Management Clusters to Microsoft Azure with the Installer Interface

This topic describes how to use the Tanzu Kubernetes Grid installer interface to deploy a management cluster to Microsoft Azure. The Tanzu Kubernetes Grid installer interface guides you through the deployment of the management cluster, and provides different configurations for you to choose. If this is the first time that you are deploying a management cluster, it is recommended to use the installer interface.

- [Prerequisites](#prereqs)
- [Procedure](#procedure)
- [Installer Interface Options](#ui-options)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

Make sure that you have met the requirements and taken the steps described in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) and [Deploy Management Clusters to Microsoft Azure](azure.md).

## <a id="procedure"></a> Procedure

You deploy management clusters using the Tanzu Kubernetes Grid CLI, on a machine referred to as the _bootstrap machine_.

**IMPORTANT**: Do not run multiple management cluster deployments on the same bootstrap machine at the same time. Do not change context or edit the `$HOME/.kube-tkg/config` file while Tanzu Kubernetes Grid operations are running.

1. On the bootstrap machine, make sure that you have at least 6.00&nbsp;GB allocated to **Memory** in Docker or Docker Desktop.

1. Run the `tkg init` command with the `--ui` option.

   ```
   tkg init --ui
   ```  

   By default Tanzu Kubernetes Grid creates a folder called `$HOME/.tkg` and creates the cluster configuration file, `config.yaml` in that folder. To create `config.yaml` in a different location or with a different name, specify the `--config` option. It might be useful to do this if you want to use different management clusters to deploy Tanzu Kubernetes clusters with different configurations. If you specify the `--config` option, Tanzu Kubernetes Grid only creates the `config.yaml` file in the specified location. Other files are still created in the `$HOME/.tkg` folder.

   ```
   tkg init --ui --config /path/my-config.yaml
   ```  
   
   By default Tanzu Kubernetes Grid saves the `kubeconfig` for all management clusters in the `$HOME/.kube-tkg/config.yaml` file. If you want to keep the `kubeconfig` file for a management cluster separate from the `kubeconfig` file for other management clusters, for example so that you can share it, specify the `--kubeconfig` command.

   ```
   tkg init --ui --kubeconfig /path/my-kubeconfig.yaml
   ```  
   When you run the `tkg init --ui` command, it validates that your system meets the prerequisites:
   
   - NTP is running on the bootstrap machine on which you are running `tkg init` and on the hypervisor.
   - The CLI can connect to the location from which it pulls the required images.
   - Docker is running.
   
   By default, `tkg init --ui` opens the installer interface locally, at http://127.0.0.1:8080 in your default browser.
   The [Installer Interface Options](#ui-options) section below explains how you can change where the installer interface runs, including running it on a different machine from the `tkg` CLI.
   
   ![Tanzu Kubernetes Grid installer interface welcome page with Deploy to AWS button](../images/deploy-management-cluster.png)
1. Click the **Deploy** button for Microsoft Azure.
1. In the **IaaS Provider** section, enter the Tenant ID, Client ID, Client Secret, and Subscription ID for your Azure account and click **Connect**.  You recorded these values when you registered an Azure app and created a certificate and secret for it using the Azure Portal.

   ![Configure the connection to Azure](../images/connect-to-azure.png)
1. Select the Azure region in which to deploy the management cluster.
1. Paste the contents of your SSH public key, such as `.ssh/id_rsa.pub`, into the text box.

   ![Select region and provide SSH key](../images/select-azure-region.png)
1. Under **Resource Group**, select either the **Select an existing resource group** or the **Create a new resource group** radio button.

    - If you select **Select an existing resource group**, use the drop-down menu to select the group, then click **Next**.

       ![Select existing resource group](../images/select-azure-resource-group.png)
     
    - If you select **Create a new resource group**, enter a name for the new resource group, then click **Next**.

       ![Create new resource group](../images/create-azure-resource-group.png)

1. In the **VNET for Azure** section, select either the **Create a new VNET on Azure** or the **Select an existing VNET** radio button.

    - If you select **Create a new VNET on Azure**, use the drop-down menu to select the resource group in which to create the VNET, provide a name and a CIDR range for the VNET, then click **Next**.

       ![Create a new VNET on Azure](../images/create-vnet-azure.png)
     
    - If you select **Select an existing VNET**, use the drop-down menus to select the resource group in which the VNET is located, the VNET name, and the control plane and work node subnets, then click **Next**.

       ![Select an existing VNET](../images/select-vnet-azure.png)
     
1. In either of the **Development** or **Production** tiles, use the **Instance type** drop-down menu to select the configuration for the control plane node VM or VMs.

   Select the size of instance to use for the control plane node VMs, depending on the expected workloads that you will run in the cluster.
   
   ![Select the control plane node configuration](../images/configure-control-plane-azure.png)
   
1. Optionally enter a name for your management cluster.

   If you do not specify a name, Tanzu Kubernetes Grid generates one automatically. If you do specify a name, that name must be compliant with DNS hostname requirements as outlined in [RFC 952](https://tools.ietf.org/html/rfc952) and amended in [RFC 1123](https://tools.ietf.org/html/rfc1123).

1. Optionally, deselect the **Machine Health Checks** checkbox if you want to
disable [`MachineHealthCheck`](https://cluster-api.sigs.k8s.io/developer/architecture/controllers/machine-health-check.html#machinehealthcheck) and click **Next**.

   `MachineHealthCheck` provides node health monitoring and node auto-repair on the clusters that you deploy with this management cluster. You can enable or disable `MachineHealthCheck` on clusters after deployment by using the CLI.
   For instructions, see [Configure Machine Health Checks for Tanzu Kubernetes Clusters](../tanzu-k8s-clusters/configure-health-checks.md).
1. In the **Metadata** section, optionally provide descriptive information about this management cluster.

   Any metadata that you specify here applies to the management cluster and to the Tanzu Kubernetes clusters that it manages, and can be accessed by using the cluster management tool of your choice.

   - **Location**: The geographical location in which the clusters run.
   - **Description**: A description of this management cluster. The description has a maximum length of 63 characters and must start and end with a letter. It can contain only lower case letters, numbers, and hyphens, with no spaces. 
   - **Labels**: Key/value pairs to help users identify clusters, for example `release : beta`, `environment : staging`, or `environment : production`. For more information, see [Labels and Selectors](https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/) in the Kubernetes documentation.<br />
   You can click **Add** to apply multiple labels to the clusters.

   ![Add cluster metadata](../images/cluster-metadata-azure.png)
1. In the **Kubernetes Network** section, review the **Cluster Service CIDR** and **Cluster Pod CIDR** ranges. If the recommended CIDR ranges of `100.64.0.0/13` and `100.96.0.0/11` are unavailable, update the values under **Cluster Service CIDR** and **Cluster Pod CIDR**.
   
   ![Set the Kubernetes network](../images/azure-k8s-network.png)
1. In the **CEIP Participation** section, optionally deselect the check box to opt out of the VMware Customer Experience Improvement Program.

   You can also opt in or out of the program after the deployment of the management cluster. For information about the CEIP, see [Opt in or Out of the VMware CEIP](multiple-management-clusters.md#ceip) and [https://www.vmware.com/solutions/trustvmware/ceip.html](https://www.vmware.com/solutions/trustvmware/ceip.html).
1. Click **Review Configuration** to see the details of the management cluster that you have configured.

   When you click **Review Configuration**, Tanzu Kubernetes Grid populates the `.tkg/config.yaml` file with the settings that you specified in the interface. You can optionally copy the `.tkg/config.yaml` file without completing the deployment. You can copy `.tkg/config.yaml` to another bootstrap machine and deploy the management cluster from that machine. For example, you might do this so that you can deploy the management cluster from a bootstrap machine that does not have a Web browser. In earlier versions of Tanzu Kubernetes Grid, the `.tkg/config.yaml` file is populated when you deploy the management cluster.

   ![Review the management cluster configuration](../images/review-settings-azure.png)
1. (Optional) Under **CLI Command Equivalent**, click the **Copy** button to copy the CLI command for the configuration that you specified.

   ![Copy CLI command](../images/copy-cli-command-azure.png)
   
   Copying the CLI command allows you to reuse the command at the command line to deploy management clusters with the configuration that you specified in the interface. This can be useful if you want to automate management cluster deployment.
1. (Optional) Click **Edit Configuration** to return to the installer wizard to modify your configuration.
1. Click **Deploy Management Cluster** and follow the progress of the deployment of the management cluster in the installer interface.

   Deployment of the management cluster can take several minutes. The first run of `tkg init` takes longer than subsequent runs because it has to pull the required Docker images into the image store on your bootstrap machine. Subsequent runs do not require this step, so are faster. You can follow the progress of the deployment of the management cluster in the installer interface or in the terminal in which you ran `tkg init --ui`. If you inadvertently close the browser or browser tab in which the deployment is running before it finishes, the deployment continues in the terminal.
   
If `tkg init` fails before the management cluster deploys to Azure, you should clean up artifacts on your bootstrap machine before you re-run `tkg init`. See the [Troubleshooting Tips](../troubleshooting-tkg/tips.html) topic for details.

## <a id="ui-options"></a> Installer Interface Options

By default, `tkg init --ui` opens the installer interface locally, at http://127.0.0.1:8080 in your default browser.
You can use the `--browser` and `--bind` options to control where the installer interface runs:

- `--browser` specifies the local browser to open the interface in.
   - Supported values are `chrome`, `firefox`, `safari`, `ie`, `edge`, or `none`.
   - Use `none` with `--bind` to run the interface on a different machine, as described below.
- `--bind` specifies the IP address and port to serve the interface from.

<p class="note warning"><strong>Warning</strong>: Serving the installer interface from a non-default IP address and port could expose the <code>tkg</code> CLI to a potential security risk while the interface is running. VMware recommends passing in to the <code>--bind</code> option an IP and port on a secure network.</p>

Use cases for `--browser` and `--bind` include:

- If another process is already using http://127.0.0.1:8080, use `--bind` to serve the interface from a different local port.
- To run the `tkg` CLI and create management clusters on a remote machine, and run the installer interface locally or elsewhere:
  1. On the remote, bootstrap machine, run `tkg init --ui` with the following options and values:
      - `--bind`: an IP address and port for the remote machine
      - `--browser`: `none`
        ```
        tkg init --ui --bind 192.168.1.87:5555 --browser none
        ```  
  1. On the local UI machine, browse to the remote machine's IP address to access the installer interface.

## <a id="what-next"></a> What to Do Next

- For information about what happened during the deployment of the management cluster, how to connect `kubectl` to the management cluster, and how to create namespaces see [Examine the Management Cluster Deployment](verify-deployment.md).
- For information about how to create namespaces in the management cluster, see [Create Namespaces in the Management Cluster](create-namespaces.md).
- If you need to deploy more than one management cluster, on any or all of vSphere, Azure, and Amazon EC2, see [Manage Your Management Clusters](multiple-management-clusters.md). This topic also provides information about how to add existing management clusters to your CLI instance, obtain credentials, scale and delete management clusters, and how to opt in or out of the CEIP.
