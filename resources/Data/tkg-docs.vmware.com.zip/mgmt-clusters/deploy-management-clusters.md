# Deploying and Managing Management Clusters

This topic gives a high-level explanation of how to create a Tanzu Kubernetes Grid instance by deploying a management cluster.

- [Overview](#overview)
- [Installer UI vs. CLI](#ui-cli)
- [Platforms](#platforms)
- [Configuring the Management Cluster](#configuring)

## <a id="overview"></a> Overview

After you have performed the steps described in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md), you can deploy management clusters to the platform of your choice.

**NOTE**: On vSphere 7, it is recommended to use a built-in supervisor cluster from Tanzu Kubernetes Grid Service instead of deploying a management cluster with Tanzu Kubernetes Grid.
For details, see [Management Clusters Unnecessary on vSphere 7](vsphere.md#mc-vsphere7).

A management cluster is the first element that you deploy when you create a Tanzu Kubernetes Grid instance. The management cluster is a Kubernetes cluster that performs the role of the primary management and operational center for the Tanzu Kubernetes Grid instance. This is where Cluster API runs to create the Tanzu Kubernetes clusters in which your application workloads run, and where you configure the shared and in-cluster services that these clusters use.

## <a id="ui-cli"></a> Installer UI vs. CLI

You can deploy management clusters in two ways:

- By starting a local instance of the Tanzu Kubernetes Grid installer interface, which provides a graphical installer to guide you through the deployment process. This is the recommended method.
- By using CLI commands directly to deploy the management cluster from a configuration that you provide in a YAML template file. 

## <a id="platforms"></a> Platforms

Tanzu Kubernetes Grid allows you to provision and manage management clusters on the following platforms:

- vSphere 6.7u3
- vSphere 7, if vSphere with Tanzu is not enabled. For more information, see [Management Clusters Unnecessary on vSphere 7](vsphere.md#mc-vsphere7).
- Amazon Elastic Compute Cloud (Amazon EC2)
- Microsoft Azure

You can provision the management cluster in both a single node control plane  configuration for development, and in a highly available, multi-node control plane configuration for production environments.

- For information about the required setup and how to deploy management clusters to vSphere, see [Deploy Management Clusters to vSphere](vsphere.md) and its subtopics.
- For information about the required setup and how to deploy management clusters to Amazon EC2, see [Deploy Management Clusters to Amazon EC2](aws.md) and its subtopics.
- For information about the required setup and how to deploy management clusters to Azure, see [Deploy Management Clusters to Microsoft Azure](azure.md) and its subtopics.
- After you have deployed a management cluster to the platform of your choice, [Examine the Management Cluster Deployment](verify-deployment.md).
- If necessary, you can [Create Namespaces in the Management Cluster](create-namespaces.md).
- After you have deployed one or more management clusters to one or more platforms, use the Tanzu Kubernetes Grid CLI to [Manage Your Management Clusters](multiple-management-clusters.md).
- If necessary, you can [Backup and Restore Management Clusters](backup-restore-mgmt-cluster.md).

## <a id="configuring"></a> Configuring the Management Cluster

You deploy your management console by running the `tkg init` command on the bootstrap machine, and you can configure the deployment in multiple ways:

* Installer UI Input
* CLI Options, like `--worker-size`
* Configuration Parameters, like `AZURE_NODE_MACHINE_TYPE`
    - Defined as local environment variables
    - Set in `config.yaml` or another configuration

The `tkg init` command uses these sources and inputs in the following order of increasing precedence:

1. `~/.tkg/providers/config_defaults.yaml`: This file contains system defaults, and should not be changed.
1. `~/.tkg/config.yaml` or other file passed in with the `--config` option: This file configures specific invocations of `tkg init` and other `tkg` commands. Use different `--config` files to save multiple configurations, for example so that multiple management clusters can share a virtual network such as a VNET on Azure or a VPC on AWS.
1. Local environment variables: Parameter settings in your local environment override settings from config files. Use them to make quick config choices without having to search and edit a config file.
1. CLI options: Some options correspond to configuration parameters. For example `--worker-size` overrides `AZURE_NODE_MACHINE_TYPE`. But see `--ui` below.
1. Installer UI: When you run `tkg init` with the `--ui` option, the installer sets all management cluster configuration values from user input and ignores all other CLI options.
