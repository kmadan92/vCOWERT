# Back Up and Restore Management Clusters

To back up and restore Tanzu Kubernetes Grid management clusters, you can use [Velero](https://velero.io/docs), an open source community standard tool for backing up and restoring Kubernetes cluster resources and persistent volumes.
Velero supports a variety of [storage providers](https://velero.io/docs/main/supported-providers/) to store its backups.

If a Tanzu Kubernetes Grid management cluster crashes and fails to recover, the infrastructure administrator can use a Velero backup to restore its contents to a new management cluster, including management cluster extensions and internal API objects for the workload clusters.

The following sections explain how to back up and restore a Tanzu Kubernetes Grid management cluster using the Velero CLI.

To back up and restore Tanzu Kubernetes Grid **workload clusters**, you can use similar `velero backup` and `velero restore` commands to the ones described below.

- [Prerequisites](#prereqs)
    - [Install the Velero CLI](#cli)
    - [Storage Provider Setup](#storage)
- [vSphere Backup and Restore](#vsphere)
    - [Back Up a Management Cluster on vSphere](#vsphere-backup)
    - [Restore to a New Management Cluster on vSphere](#vsphere-restore)
- [AWS Backup and Restore](#aws)
    - [Back Up a Management Cluster on AWS](#aws-backup)
    - [Restore to a New Management Cluster on AWS](#aws-restore)
- [Azure Backup and Restore](#azure)
    - [Back Up a Management Cluster on Azure](#azure-backup)
    - [Restore to a New Management Cluster on Azure](#azure-restore)

## <a id="prereqs"></a> Prerequisites

These sections describe what you need to back up and restore Tanzu Kubernetes Grid management clusters.

### <a id="cli"></a> Install the Velero CLI

1. Go to [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg) and log in with your My VMware credentials.
1. Under **Product Downloads**, click **Go to Downloads**.
1. Scroll to the **Velero** entries and download the Velero CLI `.gz` file for your workstation OS. Its filename starts with `velero-linux-`, `velero-mac-`, or `velero-windows64-`.
1. Use either the `gunzip` command or the extraction tool of your choice to unpack the binary:
   ```sh  
   gzip -d <RELEASE-TARBALL-NAME>.gz
   ```
1. Rename the CLI binary for your platform to `velero`, make sure that it is executable, and add it to your `PATH`.
   
   - Mac OS and Linux platforms: 

       1. Move the binary into the `/usr/local/bin` folder and rename it to `velero`.
       1. Make the file executable:
       ```sh  
       chmod +x /usr/local/bin/velero
       ```
   
   - Windows platforms:
   
        1. Create a new `Program Files\velero` folder and copy the binary into it. 
        1. Rename the binary to `velero.exe`.
        1. Right-click the `velero` folder, select **Properties** > **Security**, and make sure that your user account has the **Full Control** permission.
        1. Use Windows Search to search for `env`.
        1. Select **Edit the system environment variables** and click the **Environment Variables** button.
        1. Select the `Path` row under **System variables**, and click **Edit**. 
        1. Click **New** to add a new row and enter the path to the `velero` binary.

### <a id="storage"></a> Storage Provider Setup

Velero supports a variety of [storage providers](https://velero.io/docs/main/supported-providers).
You need a storage provider to store cluster object backups and snapshots of any CSI persistent volumes that the cluster objects use.

VMware recommends dedicating a unique storage bucket to each cluster, so the instructions below include setting up storage for each management cluster backup or restore operation.

How you set up a storage provider depends on your infrastructure:

* **vSphere** (On Premises)
    - Requires external object storage, which can be:
        - An S3 bucket on Amazon Web Services (AWS), enabled by the [Velero Plugin for AWS](https://github.com/vmware-tanzu/velero-plugin-for-aws)
        - An S3 bucket on cloud storage such as [MinIO](https://min.io), also enabled by the AWS plugin. See the [example MinIO installation](https://velero.io/docs/main/contributions/minio) in the Velero documentation.
        - Other storage providers, as listed on the [Providers](https://velero.io/docs/main/supported-providers) page in the Velero documentation.
    - To store CSI volume snapshots, requires the [Velero Plugin for vSphere](https://github.com/vmware-tanzu/velero-plugin-for-vsphere).
    - Stores cluster objects and volume snapshots to the same S3 bucket.

* **AWS and Azure**
    - Requires plugins installed with the `velero install` command, with parameters including:
        - `--plugins`: the object store and volume snapshotter plugin versions
        - `--backup-location-config`: object backup location
        - `--snapshot-location-config`: volume snapshot location

**Example**: The following Velero CLI commands use a public Velero image repository.
Please replace the repository with the official Tanzu Kubernetes Grid image repository by following the [Customize Velero Install](https://velero.io/docs/main/on-premises) instructions in the Velero documentation.

   ```sh  
   velero install \
    --image=$TKG_REG/velero:$VELERO_VERSION \
    --plugin=$TKG_REG/velero-plugin-for-aws:$PLUGIN_VERSION \
   <....>
   ```

## <a id="vsphere"></a> vSphere Backup and Restore

These sections describe how to back up and restore Tanzu Kubernetes Grid management clusters on vSphere.

### <a id="vsphere-backup"></a> Back Up a Management Cluster on vSphere

1. Install Velero server on the management cluster.
   This example uses MinIO as the object storage:

   ```sh  
   velero install --provider aws --plugins "velero/velero-plugin-for-aws:v1.1.0" --bucket velero --secret-file ./credentials-velero --backup-location-config "region=minio,s3ForcePathStyle=true,s3Url=minio_server_url" --snapshot-location-config region="default"
   ```

   See the [MinIO server setup instructions](https://velero.io/docs/main/contributions/minio/#set-up-server) in the Velero documentation.

1. If there are CSI-based volumes to back up, follow the Velero Plugin for vSphere [setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-vsphere#installing-the-plugin) to install the Velero plugin for vSphere.

1. Set `Cluster.Spec.Paused` to `true` for all workload clusters:

  <pre>  
   kubectl patch cluster workload_cluster_name --type='merge' -p '{"spec":{"paused": true&rbrace;&rbrace;'
   </pre>

1. Back up the management cluster:

   ```sh  
   velero backup create your_backup_name --exclude-namespaces=tkg-system
   ```
   Excluding `tkg-system` objects avoids creating duplicate management cluster API objects when restoring to a new management cluster.

1. Set `Cluster.Spec.Paused` back to `false` for the workload clusters.

### <a id="vsphere-restore"></a> Restore to a New Management Cluster on vSphere

1. Install Velero server on the new management cluster.
   This example uses MinIO as the object storage:

   ```sh  
   velero install --provider aws --plugins "velero/velero-plugin-for-aws:v1.1.0" --bucket velero --secret-file ./credentials-velero --backup-location-config "region=minio,s3ForcePathStyle=true,s3Url=minio_server_url"
   ```

   See the [MinIO server setup instructions](https://velero.io/docs/main/contributions/minio/#set-up-server) in the Velero documentation.

1. If there are CSI-based volumes to restore, follow the Velero Plugin for vSphere [setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-vsphere#installing-the-plugin) to install the Velero plugin for vSphere.

1. Restore the management cluster:

   ```sh  
   velero restore create your_restore_name --from-backup your_backup_name
   ```

1. Set `Cluster.Spec.Paused` field to `false` for all workload clusters:

   <pre>  
   kubectl patch cluster cluster_name --type='merge' -p '{"spec":{"paused": false&rbrace;&rbrace;'
   </pre>

## <a id="aws"></a> AWS

These sections describe how to back up and restore Tanzu Kubernetes Grid management clusters on AWS.

### <a id="aws-backup"></a> Back Up a Management Cluster on AWS

1. Follow the [Velero Plugin for AWS setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-vsphere#installing-the-plugin) to install Velero server on the management cluster.

2. Set `Cluster.Spec.Paused` to `true` for all workload clusters:

   <pre>  
   kubectl patch cluster workload_cluster_name --type='merge' -p '{"spec":{"paused": true&rbrace;&rbrace;'
   </pre>

1. Back up the management cluster:

   ```sh  
   velero backup create your_backup_name --exclude-namespaces=tkg-system
   ```
   Excluding `tkg-system` objects avoids creating duplicate management cluster API objects when restoring to a new management cluster.

1. Set `Cluster.Spec.Paused` back to `false` for the workload clusters.

### <a id="aws-restore"></a> Restore to a New Management Cluster on AWS

1. Follow the [Velero Plugin for AWS setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-vsphere#installing-the-plugin) to install Velero server on the new management cluster.

1. Restore the management cluster:

   ```sh  
   velero backup get
   velero restore create your_restore_name --from-backup your_backup_name
   ```

1. Set `Cluster.Spec.Paused` to `false` for all workload clusters:

   <pre>  
   kubectl patch cluster cluster_name --type='merge' -p '{"spec":{"paused": false&rbrace;&rbrace;'
   </pre>

## <a id="azure"></a> Azure

These sections describe how to back up and restore Tanzu Kubernetes Grid management clusters on Azure.

### <a id="azure-backup"></a> Back Up a Management Cluster on Azure

1. Follow the [Velero Plugin for Azure setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-microsoft-azure#setup) to install Velero server on the management cluster.

1. Set `Cluster.Spec.Paused` to `true` for all workload clusters:

   <pre> 
   kubectl patch cluster workload_cluster_name --type='merge' -p '{"spec":{"paused": true&rbrace;&rbrace;'
   </pre>

1. Back up the management cluster:

   ```sh  
   velero backup create your_backup_name --exclude-namespaces=tkg-system
   ```
   Excluding `tkg-system` objects avoids creating duplicate management cluster API objects when restoring to a new management cluster.

1. If `velero backup` returns a `transport is closing` error, try again after increasing the memory limit, as described in [Update resource requests and limits after install](https://velero.io/docs/v1.4/customize-installation/#update-resource-requests-and-limits-after-install) in the Velero documentation.

1. Set `Cluster.Spec.Paused` back to `false` for the workload clusters.

### <a id="azure-restore"></a> Restore to a New Management Cluster on Azure

1. Follow the [Velero Plugin for Azure setup instructions](https://github.com/vmware-tanzu/velero-plugin-for-microsoft-azure#setup) to install Velero server on the new management cluster.

1. Restore the management cluster:

   ```sh  
   velero backup get
   velero restore create your_restore_name --from-backup your_backup_name
   ```

1. Set `Cluster.Spec.Paused` to `false` for all workload clusters:

   <pre> 
   kubectl patch cluster cluster_name --type='merge' -p '{"spec":{"paused": false&rbrace;&rbrace;'
   </pre>
