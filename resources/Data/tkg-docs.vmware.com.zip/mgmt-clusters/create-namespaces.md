# Create Namespaces in the Management Cluster

To help you to organize and manage your development projects, you can optionally divide the management cluster into Kubernetes namespaces. You can then use Tanzu Kubernetes Grid CLI to deploy Tanzu Kubernetes clusters to specific namespaces in your management cluster. For example, you might want to create different types of clusters in dedicated namespaces. If you do not create additional namespaces, Tanzu Kubernetes Grid creates all Tanzu Kubernetes clusters in the `default` namespace. For information about Kubernetes namespaces, see the [Kubernetes documentation](https://kubernetes.io/docs/tasks/administer-cluster/namespaces-walkthrough/).

1. Make sure that `kubectl` is connected to the correct management cluster context by displaying the current context.

   ```
   kubectl config current-context
   ```
1. List the namespaces that are currently present in the management cluster.

   ```
   kubectl get namespaces
   ```

   You will see that the management cluster already includes several namespaces for the different services that it provides:
   
    ```
    capi-kubeadm-bootstrap-system       Active   4m7s
    capi-kubeadm-control-plane-system   Active   4m5s
    capi-system                         Active   4m11s
    capi-webhook-system                 Active   4m13s
    capv-system                         Active   3m59s
    cert-manager                        Active   6m56s
    default                             Active   7m11s
    kube-node-lease                     Active   7m12s
    kube-public                         Active   7m12s
    kube-system                         Active   7m12s
    tkg-system                          Active   3m57s
    ```  
   
1. Use `kubectl create -f` to create new namespaces, for example for development and production.

   These examples use the `production` and `development` namespaces from the Kubernetes documentation. 
   
   <pre>kubectl create -f https://k8s.io/examples/admin/namespace-dev.json</pre>
   
   <pre>kubectl create -f https://k8s.io/examples/admin/namespace-prod.json</pre>
   
1. Run `kubectl get namespaces --show-labels` to see the new namespaces.

    ```
    development                         Active   22m   name=development
    production                          Active   22m   name=production
    ```