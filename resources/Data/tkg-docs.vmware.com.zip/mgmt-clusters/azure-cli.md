# Deploy Management Clusters to Microsoft Azure with the CLI

This topic describes how to use the Tanzu Kubernetes Grid CLI to deploy a management cluster to Microsoft Azure from a YAML configuration file.

- [Prerequisites](#prereqs)
- [Configure the `config.yaml` File](#config)
    - [Configuration Parameters Reference](#params-ref)
- [Run the `tkg init` Command](#tkg-init)
    - [CLI Options Reference](#cli-ref)
- [What to Do Next](#what-next)


## <a id="prereqs"></a> Prerequisites

- Ensure that you have met all of the requirements listed in
[Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) and [Deploy Management Clusters to Microsoft Azure](azure.md).
  - For information about the configurations of the different sizes of node instances, for example `Standard_D2s_v3`, or `Standard_DC4s_v2`, see [Sizes for Linux virtual machines in Azure](https://docs.microsoft.com/en-us/azure/virtual-machines/linux/sizes).
- It is **strongly recommended** to use the Tanzu Kubernetes Grid installer interface rather than the CLI to deploy your first management cluster to Azure. When you deploy a management cluster by using the installer interface, it populates the `config.yaml` file for the management cluster with the required parameters. You can use the created `config.yaml` as a model for future deployments from the CLI.
- On the bootstrap machine, make sure that you have at least 6.00&nbsp;GB allocated to **Memory** in Docker or Docker Desktop.
- (Optional) In the Azure Portal create a VNET, a subnet for the management cluster control plane node, and subnet for the management cluster worker nodes.


## <a id="config"></a> Configure the `config.yaml` File

The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. When you deploy a management cluster from the CLI, the `tkg init` command uses this configuration.

To configure the `config.yaml` file, follow the steps below:

1. If this is the first time that you are running Tanzu Kubernetes Grid commands on this machine, and you have not already deployed a management cluster to Azure by using the Tanzu Kubernetes Grid installer interface, open a terminal and run the `tkg get management-cluster` command:

   ```
   tkg get management-cluster
   ```  

   Running a `tkg` command for the first time creates the `$HOME/.tkg` folder, that contains the management cluster configuration file `config.yaml` and other configuration files.

1. Open the `.tkg/config.yaml` file in a text editor.

    - If you have already deployed a management cluster to Azure from the installer interface, you will see variables that describe your previous deployment. 

    - If you have not already deployed a management cluster to Azure from the installer interface, copy and paste the following rows at the end of the configuration file:

      ```
      AZURE_ENVIRONMENT: 
      AZURE_TENANT_ID: 
      AZURE_SUBSCRIPTION_ID: 
      AZURE_CLIENT_ID: 
      AZURE_CLIENT_SECRET: 
      AZURE_LOCATION: 
      AZURE_SSH_PUBLIC_KEY_B64:
      AZURE_CONTROL_PLANE_MACHINE_TYPE: 
      AZURE_NODE_MACHINE_TYPE: 
      AZURE_VNET_NAME: 
      AZURE_VNET_CIDR: 
      AZURE_CONTROL_PLANE_SUBNET_NAME: 
      AZURE_CONTROL_PLANE_SUBNET_CIDR: 
      AZURE_NODE_SUBNET_NAME: 
      AZURE_NODE_SUBNET_CIDR: 
      ```

1. Edit the configuration file to update the information about the target Azure environment and the configuration of the management cluster to deploy.
   
    The table in [Configuration Parameters Reference](#params-ref) describes configuration options for deploying a management cluster to Azure. Line order in the configuration file does not matter.

### <a id="params-ref"></a> Configuration Parameters Reference

The table below describes all of the variables that you must set for deployment to Azure, along with some Azure-specific optional variables. To set them in a configuration file, leave a space between the colon (`:`) and the variable value. For example:
    
```
AZURE_LOCATION: southcentralus
```

**IMPORTANT**:

- As described in [Configuring the Management Cluster](deploy-management-clusters.md#configuring), environment variables override values from a configuration file. To use all settings from a `config.yaml`, unset any conflicting environment variables before you deploy the management cluster from the CLI.
- Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this topic.

<table width="100%" border="0">
  <tr>
    <th width="25%" scope="col">Option</th>
    <th width="25%" scope="col">Value</th>
    <th width="50%" scope="col">Description</th>
  </tr>
  <tr>
    <td><code>AZURE_ENVIRONMENT</code></td>
    <td><code>AzurePublicCloud</code>, <code>AzureChinaCloud</code>, etc.</td>
    <td>For possible values, see <a href="https://docs.microsoft.com/en-us/cli/azure/manage-clouds-azure-cli?view=azure-cli-latest#list-available-clouds">List available clouds</a> in the Azure docs.</td>
  </tr>
  <tr>
    <td><code>AZURE_TENANT_ID</code>&#42;</td>
    <td>GUID</td>
    <td>The tenant ID of your Azure account.</td>
  </tr>
  <tr>
    <td><code>AZURE_SUBSCRIPTION_ID</code>&#42;</td>
    <td>GUID</td>
    <td>The subscription ID of your Azure subscription. </td>
  </tr>
  <tr>
    <td><code>AZURE_CLIENT_ID</code>&#42;</td>
    <td>GUID</td>
    <td>The client ID of the app for Tanzu Kubernetes Grid that you registered with Azure.</td>
  </tr>
  <tr>
    <td><code>AZURE_CLIENT_SECRET</code>&#42;</td>
    <td>e.g. <code>uHY49cq [...] Og.SG-4</code></td>
    <td>Client secret from <a href="azure.md#register-app">Register a Tanzu Kubernetes Grid App on Azure</a>.</td>
  </tr>
  <tr>
    <td><code>AZURE_LOCATION</code>&#42;</td>
    <td><code>us-west</code>, <code>ap-northeast</code>, etc.</td>
    <td>The name of the Azure region in which to deploy the management cluster. </td>
  </tr>
  <tr>
    <td><code>AZURE_SSH_PUBLIC_KEY_B64</code>&#42;</td>
    <td>e.g. <code>c3NoLXJzYSBB [...] vdGFsLmlvCg==</code></td>
      <td>Your SSH public key, created in <a href="azure.html">Deploy a Management Cluster to Microsoft Azure</a>, converted into base64 with newlines removed.
      For example, with a public key file `id_rsa.pub`, set `AZURE_SSH_PUBLIC_KEY_B64` to the output of `cat id_rsa.pub | base64 | tr -d ‘\r\n’`</td>
  </tr>
  <tr>
    <td><code>AZURE_RESOURCE_GROUP</code>&#42;</td>
    <td rowspan=2><code>resource-group-name</code> that already exists in your Azure account.<br />
    <code>AZURE_RESOURCE_GROUP</code> and <code>AZURE_VNET_RESOURCE_GROUP</code> are the same by default.</td>
    <td>Must be unique to each management cluster.</td>
  </tr>
  <tr>
    <td><code>AZURE_VNET_RESOURCE_GROUP</code></td>
    <td>Can be shared across multiple management clusters.</td>
  </tr>
  <tr>
    <td><code>AZURE_CONTROL_PLANE_MACHINE_TYPE</code>&#42;</td>
    <td rowspan=2><a href="https://docs.microsoft.com/en-us/azure/virtual-machines/dv3-dsv3-series#dsv3-series">Dsv3-series</a> or <a href="https://docs.microsoft.com/en-us/azure/virtual-machines/fsv2-series">Fsv2-series</a> machine type, chosen to fit expected workloads.
    <td>For control plane node VMs. You can also specify or override this value with the <code>tkg init --size</code> or <code>--controlplane-size</code> options.</td>
  </tr>
  <tr>
    <td><code>AZURE_NODE_MACHINE_TYPE</code>&#42;</td>
    <td>For worker node VMs. You can also specify or override this value with the <code>tkg init --size</code> or <code>--worker-size</code> options.</td>
  </tr>
  <tr>
    <td><code>AZURE_VNET_NAME</code></td>
    <td>VNET in the management cluster resource group.</td>
    <td rowspan=6><strong>Existing VNET and Subnets (IP ranges)</strong>: If a dedicated VNET and two subnets for your management cluster have already been defined in Azure, set <code>_NAME</code> variables to their names, and do not set <code>_CIDR</code> variables.<br />
    <strong>New VNET and Subnets</strong>: If you have not defined a VNET and subnets in Azure, the installer creates them with <code>_NAME</code> or <code>_CIDR</code> values specified and generated default values when not specified.<br />
    Specified <code>_NAME</code> and <code>_CIDR</code> values must be unique and nonconflicting.</td>
  </tr>
    <td><code>AZURE_VNET_CIDR</code></td>
    <td>CIDR for the VNET in management cluster resource group.</td>
  </tr>
    <td><code>AZURE_CONTROL_PLANE_SUBNET_NAME</code></td>
    <td>Name of control plane node subnet.</td>
  </tr>
    <td><code>AZURE_CONTROL_PLANE_SUBNET_CIDR</code></td>
    <td>CIDR for control plane node subnet.</td>
  </tr>
    <td><code>AZURE_NODE_SUBNET_NAME</code></td>
    <td>Name of worker node subnet.</td>
  </tr>
    <td><code>AZURE_NODE_SUBNET_CIDR</code></td>
    <td>CIDR for worker node subnet.</td>
  </tr>
  <tr>
    <td><code>SERVICE_CIDR</code></td>
    <td><code>100.64.0.0/13</code></td>
    <td>The CIDR range to use for the Kubernetes services. The recommended range is 100.64.0.0/13. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>CLUSTER_CIDR</code></td>
    <td><code>100.96.0.0/11</code></td>
    <td>The CIDR range to use for pods. The recommended range is 100.96.0.0/11. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>ENABLE_MHC</code></td>
    <td><code>"true"</code> or <code>"false"</code></td>
    <td>Enables or disables the <a href="https://cluster-api.sigs.k8s.io/developer/architecture/controllers/machine-health-check.html#machinehealthcheck"><code>MachineHealthCheck</code></a> controller, which provides node health monitoring and node auto-repair for Tanzu Kubernetes clusters. This option is enabled in the global Tanzu Kubernetes Grid configuration by default, for all Tanzu Kubernetes clusters. To disable <code>MachineHealthCheck</code> on the clusters that you deploy with this management cluster, set <code>ENABLE_MHC</code> to <code>false</code>. Set this variable only if you want to override your global configuration. You can enable or disable <code>MachineHealthCheck</code> on individual clusters after deployment by using the CLI. For instructions, see <a href="../tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a>.</td>
  </tr>
  <tr>
    <td><code>MHC_UNKNOWN_STATUS_TIMEOUT</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>Unknown</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
  <tr>
    <td><code>MHC_FALSE_STATUS_TIMEOUT</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>False</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
</table> 

*Required

## <a id="tkg-init"></a> Run the `tkg init` Command

After you have updated `.tkg/config.yaml` you deploy a management cluster by running the `tkg init` command. The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. You provide more precise configuration information for individual clusters by running the `tkg init` command with different options.

**IMPORTANT**: Do not run multiple management cluster deployments on the same bootstrap machine at the same time. Do not change context or edit the `.kube-tkg/config` file while Tanzu Kubernetes Grid operations are running.

To deploy a management cluster to Azure, you must at least specify the `--infrastructure azure` option to `tkgi init`:

   ```
   tkg init --infrastructure azure
   ```
   
The table in [CLI Options Reference](#cli-ref) describes additional command-line options for deploying a management cluster to Azure.

**Monitoring Progress**

When you run `tkg init`, you can follow the progress of the deployment of the management cluster in the terminal.  For more detail, open the log file listed in the terminal output **Logs of the command execution can also be found at...**.

Deployment of the management cluster can take several minutes. The first run of `tkg init` takes longer than subsequent runs because it has to pull the required Docker images into the image store on your bootstrap machine. Subsequent runs do not require this step, so are faster.

The first run of `tkg init` also adds settings to your configuration file.

If `tkg init` fails before the management cluster deploys to Azure, you should clean up artifacts on your bootstrap machine before you re-run `tkg init`. See the [Troubleshooting Tips](../troubleshooting-tkg/tips.html) topic for details.

### <a id="cli-ref"></a> CLI Options Reference

The table below describes command-line options that you can set for deployment to Azure.

For example, to create a highly available Azure management cluster `azure-management-cluster` in which all of the control plane and worker node VMs are `Standard_D2s_v3` size:

   ```
   tkg init --infrastructure azure --name azure-management-cluster --plan prod --size Standard_DC4s_v2
   ```

<table width="100%" border="0">
<tr>
  <th width="25%" scope="col">Option</th>
  <th width="25%" scope="col">Value</th>
  <th width="50%" scope="col">Description</th>
</tr>
<tr>
  <td><code>--infrastructure</code></td>
  <td><code>azure</code></td>
  <td>Required</td>
</tr>
<tr>
  <td><code>--name</code></td>
  <td>Name for the management cluster</td>
  <td>Name must comply with DNS hostname requirements as outlined in <a href="https://tools.ietf.org/html/rfc952">RFC 952</a> and amended in <a href="https://tools.ietf.org/html/rfc1123">RFC 1123</a><br />
  If you do not specify a name, a unique name is generated.</td>
</tr>
<tr>
  <th colspan=3>Scaling and Availability
  </th>
</tr>
<tr>
  <td><code>--plan</code></td>
  <td><code>dev</code> or <code>prod</code></td>
  <td><code>dev</code> ("development"), the default, deploys a management cluster with a single control plane node.<br />
  <code>prod</code> ("production") deploys a highly available management cluster with three control plane nodes.</td>
</tr>
<tr>
  <th colspan=3>Configuration Files
  </th>
</tr>
<tr>
  <td><code>--config</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-config.yaml</code></td>
  <td>Configuration file to use or create, other than the default <code>$HOME/.tkg/config.yaml</code>. If the config file was not already created by hand or prior <code>tkg init</code> calls, it is created.  All other files are created in the default folder.<br />
  This option, for example, lets you deploy multiple management clusters that share a VNET.</td>
</tr>
<tr>
  <td><code>--kubeconfig</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-kubeconfig.yaml</code></td>
  <td>Kube configuration file or use, or create, other than the default <code>$HOME/.kube-tkg/config.yaml</code>.<br />
  This option lets you customize or share multiple <code>kubeconfig</code> files for multiple management clusters.</td>
</tr>
<tr>
  <th colspan=3>Nodes
  </th>
</tr>
<tr>
  <td><code>--size</code></td>
  <td rowspan=3><a href="https://docs.microsoft.com/en-us/azure/virtual-machines/dv3-dsv3-series#dsv3-series">Dsv3-series</a> or <a href="https://docs.microsoft.com/en-us/azure/virtual-machines/fsv2-series">Fsv2-series</a> machine type, e.g. <code>Standard_D2s_v3</code></td>
  <td>Size for both control plane and worker node VMs.</td>
</tr>
<tr>
  <td><code>--controlplane-size</code></td>
  <td>Size for control plane node VMs. Overrides the <code>--size</code> option and <code>AZURE_CONTROL_PLANE_MACHINE_TYPE</code> parameter.</td>
</tr>
<tr>
  <td><code>--worker-size</code></td>
  <td>Size for worker node VMs. Overrides the <code>--size</code> option and <code>AZURE_NODE_MACHINE_TYPE</code> parameter.</td>
</tr>
<tr>
  <th colspan=3>Customer Experience Improvement Program
  </th>
</tr>
<tr>
  <td><code>--ceip-participation</code></td>
  <td><code>true</code> or <code>false</code></td>
  <td><code>false</code> opts out of the VMware Customer Experience Improvement Program. Default is <code>true</code>.<br />
  You can also opt in or out of the program after deploying  the management cluster. For information, see <a href="multiple-management-clusters.md#ceip">Opt in or Out of the VMware CEIP</a> and <a href="https://www.vmware.com/solutions/trustvmware/ceip.html">Customer Experience Improvement Program ("CEIP")</a>.</td>
</tr>
</table>

## <a id="what-next"></a> What to Do Next

- For information about what happened during the deployment of the management cluster, how to connect `kubectl` to the management cluster, and how to create namespaces see [Examine the Management Cluster Deployment](verify-deployment.md).
- For information about how to create namespaces in the management cluster, see [Create Namespaces in the Management Cluster](create-namespaces.md).
- If you need to deploy more than one management cluster, on any or all of vSphere, Azure, and Amazon EC2, see [Manage Your Management Clusters](multiple-management-clusters.md). This topic also provides information about how to add existing management clusters to your CLI instance, obtain credentials, scale and delete management clusters, and how to opt in or out of the CEIP.
