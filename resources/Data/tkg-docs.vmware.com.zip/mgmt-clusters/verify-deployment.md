# Examine the Management Cluster Deployment 

During the deployment of the management cluster, either from the installer interface or the CLI, Tanzu Kubernetes Grid creates a temporary management cluster using a [Kubernetes in Docker](https://kind.sigs.k8s.io/) (`kind`) cluster on the bootstrap machine. After creating the temporary management cluster locally, Tanzu Kubernetes Grid uses it to provision the final management cluster in the platform of your choice, depending on whether you are deploying to vSphere, Amazon EC2, or Microsoft Azure. After the deployment of the management cluster finishes successfully, Tanzu Kubernetes Grid deletes the temporary `kind` cluster.

Tanzu Kubernetes Grid saves the configuration of your management cluster in the `~/.tkg/config.yaml` file. Tanzu Kubernetes Grid also creates a folder named `~/.tkg/providers`, that contains all of the files required by Cluster API to create the management cluster.

**IMPORTANT**: By default, unless you specify the `--kubeconfig` option to save the `kubeconfig` for a cluster to a specific file, all clusters that you deploy from the Tanzu Kubernetes Grid CLI are added to a shared `.kube-tkg/config` file. If you delete the shared `.kube-tkg/config` file, all management clusters become orphaned and thus unusable.

- [Management Cluster Networking](#networking)
- [Verify the Deployment of the Management Cluster](#verify-deployment)
- [Connect `kubectl` to Management Clusters](#connect-tkg-kubectl)
- [What to Do Next](#what-next)

## <a id="networking"></a> Management Cluster Networking

When you deploy a management cluster, pod-to-pod networking with [Antrea](https://antrea.io/) is automatically enabled in the management cluster.

## <a id="verify-deployment"></a>Verify the Deployment of the Management Cluster

After the deployment of the management cluster completes successfully, control plane VM and one or more worker node VMs are present in your vSphere inventory, Amazon EC2 instances, or Azure resource group. You can obtain information about your management cluster by running the `tkg get management-cluster` command, and by locating the created artifacts in vSphere, your Amazon EC2 dashboard, or the Azure Portal.  

Unless you manually change the context of the Tanzu Kubernetes Grid CLI to another cluster by using the `tkg set management-cluster` command, by default the CLI uses the context of the most recently deployed management cluster.
     
1. To facilitate the deployment of similar management clusters in the future, make a copy of the `~/.tkg/config.yaml` file.
1. View the management cluster objects in vSphere, Amazon EC2, or Azure.

   - If you deployed the management cluster to vSphere, go to the resource pool that you designated when you deployed the management cluster.
   - If you deployed the management cluster to Amazon EC2, go to the **Instances** view of your EC2 dashboard.
   
   You should see the following VMs or instances. If you did not specify a name for the management cluster, <code><em>cluster_name</em></code> is something similar to `tkg-mgmt-vsphere-20200323121503` or `tkg-mgmt-aws-20200323140554`.
   
   - **vSphere**:
       - One or three control plane VMs, for development or production control plane, respectively, with names similar to <code><em>cluster_name</em>-control-plane-sx5rp</code>
       - A worker node VM with a name similar to <code><em>cluster_name</em>-md-0-6b8db6b59d-kbnk4</code>
   - **Amazon EC2**:
       - One or three control plane VM instances, for development or production control plane, respectively, with names similar to <code><em>cluster_name</em>-control-plane-bcpfp</code>
       - A worker node instance with a name similar to <code><em>cluster_name</em>-md-0-dwfnm</code>
       - An EC2 bastion host instance with the name  <code><em>cluster_name</em>-bastion</code>
   - **Azure**:
       - One or three control plane VMs, for development or production control plane, respectively, with names similar to <code><em>cluster_name</em>-<em>timestamp</em>-control-plane-rh7xv</code>
       - A worker node VMs with a name similar to <code><em>cluster_name</em>-<em>timestamp</em>-md-0-rh7xv</code>
       - Disk and Network Interface resources for the control plane and worker node VMs, with names based on the same name patterns.

## <a id="connect-tkg-kubectl"></a> Connect `kubectl` to List Management Clusters   

Tanzu Kubernetes Grid CLI provides commands that facilitate many of the operations that you can perform with your management cluster. However, for certain operations, you still need to use `kubectl`. By default, Tanzu Kubernetes Grid sets the `kubectl` context to a new management cluster when you deploy it.

1. On the bootstrap machine on which you ran `tkg init`, run the `tkg get management-cluster` command to see the context of the management cluster that you have deployed.

   ```
   tkg get management-cluster
   ```   
   
   If you deployed a management cluster named `my-management-cluster-admin@my-management-cluster`, you will see the following output:
   
   ```
   MANAGEMENT-CLUSTER-NAME    CONTEXT-NAME                                            STATUS
   my-management-cluster *    my-management-cluster-admin@my-management-cluster       Success
   other-mgmnt-cluster        other-mgmnt-cluster-admin@other-mgmnt-cluster           Success   
   ```

   The asterisk (`*`) identifies `my-management-cluster` as being the current context of the Tanzu Kubernetes Grid CLI.

1. To instruct `kubectl` to use the context of the other management cluster, so that you can examine its resources, run `kubectl config use-context`.

   ```
   kubectl config use-context other-mgmnt-cluster-admin@other-mgmnt-cluster
   ```   
1. Use `kubectl` commands to examine the resources of the management cluster.

   For example, run `kubectl get nodes`, `kubectl get pods`, or `kubectl get namespaces` to see the nodes, pods, and namespaces running in the management cluster.


## <a id="what-next"></a> What to Do Next

You can now use Tanzu Kubernetes Grid to start deploying Tanzu Kubernetes clusters. For information, see [Deploying Tanzu Kubernetes Clusters and Managing their Lifecycle](../tanzu-k8s-clusters/index.md).

- For information about how to create namespaces in the management cluster, see [Create Namespaces in the Management Cluster](create-namespaces.md).
- If you need to deploy more than one management cluster, on any or all of vSphere, Azure, and Amazon EC2, see [Manage Your Management Clusters](multiple-management-clusters.md). This topic also provides information about how to add existing management clusters to your CLI instance, obtain credentials, scale and delete management clusters, and how to opt in or out of the CEIP.
