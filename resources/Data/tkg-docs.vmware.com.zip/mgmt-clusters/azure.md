# Deploy Management Clusters to Microsoft Azure

This topic explains how to prepare Microsoft Azure for running Tanzu Kubernetes Grid.

- [General Requirements ](#general-requirements)
- [Register a Tanzu Kubernetes Grid App on Azure](#register-app)
- [Accept the Base OS Image License](#license)
- [Create an SSH Key Pair (Optional)](#ssh-key)
- [What to Do Next](#what-next)

## <a id="general-requirements"></a> General Requirements 

- The Tanzu Kubernetes Grid CLI installed locally. See [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md).
- OpenSSL installed locally.  See [OpenSSL](https://www.openssl.org).
- A Microsoft Azure account with:
   - Permissions required to register an app. See [Permissions required for registering an app](https://docs.microsoft.com/en-us/azure/active-directory/develop/howto-create-service-principal-portal#permissions-required-for-registering-an-app) in the Azure documentation.
   - Sufficient VM core (vCPU) quotas for your clusters. A standard Azure account has a quota of 10 vCPU per region. Tanzu Kubernetes Grid clusters require 2 vCPU per node, which translates to:
      - Management cluster: 8 vCPU for `prod` plan (3 main nodes, 1 worker) 4 for `dev` (1 main, one worker)
      - Workoad clusters: 12 vCPU for `prod` plan (3 main nodes, 3 worker); 4 for `dev` (1 main, 1 worker)
* The Azure CLI installed and configured. See [Install the Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) in the Microsoft Azure documentation.

## <a id="tkg-app"></a> Register a Tanzu Kubernetes Grid App on Azure

Tanzu Kubernetes Grid manages Azure resources as a registered application that accesses Azure via a service principal account.
The following steps register your Tanzu Kubernetes Grid application with Azure Active Directory, create its service account, create a client secret for authenticating communications, and record information needed later to deploy a management cluster.

1. Log into the [Azure Portal](https://portal.azure.com).

1. Record your **Tenant ID** by hovering over your account name at upper-right, or else browse to **Azure Active Directory** > \<Your Azure Org\> > **Properties** > **Tenant ID**.  The value is a GUID, for example `b39138ca-3cee-4b4a-a4d6-cd83d9dd62f0`.

1. Browse to **Active Directory** > **App registrations** and click **+ New registration**.

1. Enter a display name for the app, such as `tkg`, and select who else can use it.  You can leave the **Redirect URI (optional)** field blank.

1. Click **Register**.  This registers the app with Azure and also creates a service principal as described in [How to: Use the portal to create an Azure AD application and service principal that can access resources](https://docs.microsoft.com/en-us/azure/active-directory/develop/howto-create-service-principal-portal) in the Azure documentation.

1. An overview pane for the app appears.  Record its **Application (client) ID** value, which is a GUID. 

1. From the Azure Portal top level, browse to **Subscriptions**.  At the bottom of the pane, select one of the subscriptions you have access to, and record its **Subscription ID**.  Click the subscription listing to open its overview pane.

1. Select to **Access control (IAM)** and click **Add a role assignment**.

1. In the **Add role assignment** pane
    - Select the **Owner** role
    - Leave **Assign access to** selection as "Azure AD user, group, or service principal"
    - Under **Select** enter the name of your app, `tkg`.  It appears underneath under **Selected Members**

1. Click **Save**. A popup appears confirming that your app was added as an owner for your subscription.

1. From the Azure Portal > **Azure Active Directory** > **App Registrations**, select your `tkg` app under **Owned applications**. The app overview pane opens.

1. From **Certificates & secrets** > **Client secrets** click **+ New client secret**.

1. In the **Add a client secret** popup, enter a **Description**, choose an expiration period, and click **Add**.

1. Azure lists the new secret with its generated value under **Client Secrets**.  Record the value.

## <a id="license"></a> Accept the Base OS Image License

To run management cluster VMs on Azure, accept the license for their base Kubernetes version and machine OS.

On Azure, Tanzu Kubernetes Grid v1.2 management cluster VMs run Kubernetes v1.19.1 on Ubuntu v18.04,
designated as `k8s-1dot19dot1-ubuntu-1804`.

1. From the command line, run:

   ```
   az vm image terms accept --publisher vmware-inc --offer tkg-capi --plan k8s-1dot19dot1-ubuntu-1804
   ```

Once you have accepted this license, you can skip this step in the future.

## <a id="ssh-key"></a> Create an SSH Key Pair (Optional)

You deploy management clusters from a machine referred to as the _bootstrap machine_, using the Tanzu Kubernetes Grid CLI.
To connect to Azure, the bootstrap machine must provide the public key part of an SSH key pair. If your bootstrap machine does not already have an SSH key pair, you can use a tool such as `ssh-keygen` to generate one.

1. On your bootstrap machine, run the following `ssh-keygen` command.

   <pre>ssh-keygen -t rsa -b 4096 -C "<em>email@example.com</em>"</pre>
1. At the prompt `Enter file in which to save the key (/root/.ssh/id_rsa):` press Enter to accept the default.
1. Enter and repeat a password for the key pair.
1. Add the private key to the SSH agent running on your machine, and enter the password you created in the previous step.

   ```
   ssh-add ~/.ssh/id_rsa
   ```
1. Open the file `.ssh/id_rsa.pub` in a text editor so that you can easily copy and paste it when you deploy a management cluster.

## <a id="what-next"></a> What to Do Next

Your environment is now ready for you to deploy the management cluster to Azure.

- [Deploy Management Clusters to Microsoft Azure with the Installer Interface](azure-ui.md). This is the preferred option for first deployments.
- [Deploy Management Clusters to Microsoft Azure with the CLI](azure-cli.md). This is the more complicated method, that allows greater flexibility of configuration.
- If you want to deploy clusters to vSphere and Amazon EC2 as well as to Azure, see [Deploy Management Clusters to vSphere](vsphere.html) and [Deploy Management Clusters to Amazon EC2](aws.md) for the required setup for those platforms.
