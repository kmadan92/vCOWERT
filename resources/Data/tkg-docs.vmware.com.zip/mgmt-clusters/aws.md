# Deploy Management Clusters to Amazon EC2

Before you can use the Tanzu Kubernetes Grid CLI or installer interface to deploy a management cluster, you must prepare the machine on which you run the Tanzu Kubernetes Grid CLI and set up your Amazon Web Services Account account. 

- [General Requirements ](#general-requirements)
- [Resource Usage in Your Amazon Web Services Account](#aws-resources)
   - [Virtual Private Clouds and NAT Gateway Limits](#aws-vpc)
- [Register an SSH Public Key with Your AWS Account](#register-ssh)
- [What to Do Next](#what-next)

## <a id="general-requirements"></a> General Requirements 

- Perform the steps described in [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md).
- You have the access key and access key secret for an active Amazon Web Services (AWS) account.
- Your AWS account must have Administrator privileges.
- Your AWS account has sufficient resource quotas for the following.
For more information, see [Amazon VPC Quotas](https://docs.aws.amazon.com/vpc/latest/userguide/amazon-vpc-limits.html) in the AWS documentation and [Resource Usage in Your Amazon Web Services Account](#aws-resources) below:
   - Virtual Private Cloud (VPC) instances. By default, each management cluster that you deploy creates one VPC and one or three NAT gateways. The default NAT gateway quota is 5 instances per availability zone, per account.
   - Elastic IP (EIP) addresses. The default EIP quota is 5 EIP addresses per region, per account.
- Install the [AWS CLI]( https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html).
- Install [`jq`]( https://stedolan.github.io/jq/download/).

   The AWS CLI uses `jq` to process JSON when creating SSH key pairs. It is also used to prepare the environment or configuration variables when you deploy Tanzu Kubernetes Grid by using the CLI.
   
## <a id="aws-resources"></a> Resource Usage in Your Amazon Web Services Account

For each cluster that you create, Tanzu Kubernetes Grid provisions a set of resources in your AWS account.

For development management clusters that are not configured for high availability, Tanzu Kubernetes Grid provisions the following resources:

- 3 VMs, including a control plane node, a worker node (to run the cluster agent extensions) and, by default, a bastion host. If you specify additional VMs in your node pool, those are provisioned as well.
- 4 security groups, one for the load balancer and one for each of the initial VMs.
- 1 private subnet and 1 public subnet in the specified availability zone.
- 1 public and 1 private route table in the specified availability zone.
- 1 classic load balancer.
- 1 internet gateway.
- 1 NAT gateway in the specified availability zone.
- By default, 1 EIP, for the NAT gateway, when clusters are deployed in their own VPC. You can optionally share VPCs rather than creating new ones, such as a workload cluster sharing a VPC with its management cluster.

For production management clusters, which are configured for high availability, Tanzu Kubernetes Grid provisions the following resources to support distribution across three availability zones:

- 3  control plane VMs
- 3  private and public subnets
- 3  private and public route tables
- 3  NAT gateways
- By default, 3 EIPs, one for each NAT gateway, for clusters deployed in their own VPC. You can optionally share VPCs rather than creating new ones, such as a workload cluster sharing a VPC with its management cluster.

AWS implements a set of default limits or quotas on these types of resources and allows you to modify the limits. Typically, the default limits are sufficient to get started creating clusters from Tanzu Kubernetes Grid. However, as you increase the number of clusters you are running or the workloads on your clusters, you will encroach on these limits. When you reach the limits imposed by AWS, any attempts to provision that type of resource fail. As a result, Tanzu Kubernetes Grid will be unable to create a new cluster, or you might be unable to create additional deployments on your existing clusters. Therefore, regularly assess the limits you have specified in AWS account and adjust them as necessary to fit your business needs.

For information about the sizes of cluster node instances, see
[Amazon EC2 Instance Types](https://aws.amazon.com/ec2/instance-types/) in the AWS documentation.

### <a id="aws-vpc"></a> Virtual Private Clouds and NAT Gateway Limits

If you create a new Virtual Private Cloud (VPC) when you deploy a management cluster, Tanzu Kubernetes Grid also creates a dedicated NAT gateway for the management cluster or if you deploy a production management cluster, three NAT gateways, one in each of the availability zones. In this case, by default, Tanzu Kubernetes Grid creates a new VPC and one or three NAT gateways for each Tanzu Kubernetes cluster that you deploy from that management cluster. By default, AWS allows 5 NAT gateways per availability zone per account. Consequently, if you always create a new VPC for each cluster, you can create only 5 development clusters in a single availability zone. If you already have five NAT gateways in use, Tanzu Kubernetes Grid is unable to provision the necessary resources when you attempt to create a new cluster. If you do not want to change the default quotas, to create more than 5 development clusters in a given availability zone, you must share existing VPCs, and therefore their NAT gateways, between multiple clusters.

There are 3 possible scenarios regarding VPCs and NAT gateway usage when you deploy management clusters and Tanzu Kubernetes clusters.

- **Create a new VPC and NAT gateway(s) for every management cluster and Tanzu Kubernetes cluster**

   If you deploy a management cluster and use the option to create a new VPC and if you make no modifications to the configuration when you deploy Tanzu Kubernetes clusters from that management cluster, the deployment of each of the Tanzu Kubernetes clusters also creates a VPC and one or three NAT gateways. In this scenario, you can deploy one development management cluster and up to 4 development Tanzu Kubernetes clusters, due to the default limit of 5 NAT gateways per availability zone.

- **Reuse a VPC and NAT gateway(s) that already exist in your availability zone(s)**

   If a VPC already exists in the availability zone(s) in which you are deploying a management cluster, for example a VPC that you created manually or by using tools such as CloudFormation or Terraform, you can specify that the management cluster should use this VPC. In this case, all of the Tanzu Kubernetes clusters that you deploy from that management cluster also use the specified VPC and its NAT gateway(s).

   An existing VPC must be configured with the following networking: 

   - Two subnets for development clusters or six subnets for production clusters
   - One NAT gateway for development clusters or three NAT gateways for production clusters
   - One internet gateway and corresponding routing tables

- **Create a new VPC and NAT gateway(s) for the management cluster and deploy Tanzu Kubernetes clusters that share that VPC and NAT gateway(s)**

   If you are starting with an empty availability zone(s), you can deploy a management cluster and use the option to create a new VPC. If you want the Tanzu Kubernetes clusters to share a VPC that Tanzu Kubernetes Grid created, you must modify the cluster configuration when you deploy Tanzu Kubernetes clusters from this management cluster. 

For information about how to deploy management clusters that either create or reuse a VPC, see [Deploy Management Clusters to Amazon EC2 with the Installer Interface](aws-ui.md) and [Deploy Management Clusters to Amazon EC2 with the CLI](aws-cli.md).

For information about how to deploy Tanzu Kubernetes clusters that share a VPC that Tanzu Kubernetes Grid created when you deployed the management cluster, see [Deploy a Cluster that Shares a VPC with the Management Cluster](../tanzu-k8s-clusters/create.md#aws-vpc).

## <a id="register-ssh"></a> Register an SSH Public Key with Your AWS Account

To enable Tanzu Kubernetes Grid VMs to launch on Amazon EC2, you must provide the public key part of an SSH key pair to Amazon EC2 for every region in which you plan to deploy management clusters. 

**NOTE**: AWS supports only RSA keys. The keys required by AWS are of a different format to those required by vSphere. You cannot use the same key pair for both vSphere and AWS deployments.

If you do not already have an SSH key pair, you can create one by performing the steps below:

1. Set the following environment variables for your AWS account:

    - <code>export AWS_ACCESS_KEY_ID=<em>aws_access_key</em></code>, where
    <code><em>aws_access_key</em></code> is your AWS access key.

    - <code>export AWS_SECRET_ACCESS_KEY=<em>aws_access_key_secret</em></code>, where <code><em>aws_access_key_secret</em></code> is your AWS access key secret.

    - (Multi-factor authentication only)
    <code>export AWS_SESSION_TOKEN=<em>aws_session_token</em></code>, where
    <code><em>aws_session_token</em></code> is your AWS session token. Set this variable if you use multi-factor authentication.

    - <code>export AWS_REGION=<em>aws_region</em></code>, where
    <code><em>aws_region</em></code> is the AWS region in which you intend to deploy the cluster. For example, `us-west-2`.
    
      For the full list of AWS regions, see [AWS Service Endpoints](https://docs.aws.amazon.com/general/latest/gr/rande.html). In addition to the regular AWS regions, you can also specify the `us-gov-east` and
      `us-gov-west` regions in AWS GovCloud.

1. For each region that you plan to use with Tanzu Kubernetes Grid, create a key pair named `default` and save it as `default.pem`.

   ```
   aws ec2 create-key-pair --key-name default --output json | jq .KeyMaterial -r > default.pem
   ```
1. Log in to your Amazon EC2 dashboard and go to **Network & Security** > **Key Pairs** to verify that the created key pair is registered with your account.

## <a id="what-next"></a> What to Do Next

Your environment is now ready for you to deploy the management cluster to Amazon EC2.

- [Deploy Management Clusters to Amazon EC2 with the Installer Interface](aws-ui.md). This is the preferred option for first deployments.
- [Deploy Management Clusters to Amazon EC2 with the CLI](aws-cli.md). This is the more complicated method that allows greater flexibility of configuration.

    **NOTE:** If in Tanzu Kubernetes Grid v1.1 you set `AWS_B64ENCODED_CREDENTIALS` as an environment variable, unset the variable before deploying management clusters with the CLI v1.2. In v1.2 and later, Tanzu Kubernetes Grid calculates the value of `AWS_B64ENCODED_CREDENTIALS` automatically. To enable Tanzu Kubernetes Grid to calculate this value, you must set the `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and `AWS_REGION` variables in `.tkg/config.yaml` or as environment variables. See [Configure the `config.yaml` File](aws-cli.md#configure) in _Deploy Management Clusters to Amazon EC2 with the CLI_.

- If you want to deploy clusters to vSphere and Azure as well as to Amazon EC2, see [Deploy Management Clusters to vSphere](vsphere.html) and [Deploy Management Clusters to Microsoft Azure](azure.md) for the required setup for those platforms.