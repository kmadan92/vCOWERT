# Deploy Management Clusters to Amazon EC2 with the CLI

This topic describes how to use the Tanzu Kubernetes Grid CLI to deploy a management cluster to Amazon Elastic Compute Cloud (Amazon EC2) from a YAML configuration file.

- [Prerequisites](#prereqs)
- [Configure the `config.yaml` File](#configure)
  - [Configuration Parameter Reference](#parameters)
- [Create an AWS CloudFormation Stack](#create)
- [Run the tkg init Command](#run)
    - [CLI Options Reference](#cli-ref)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

- Ensure that you have met all of the requirements listed in
[Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) and [Deploy Management Clusters to Amazon EC2](aws.md).
  - For information about the configurations of the different sizes of node instances, for example, `t3.large` or `t3.xlarge`, see
  [Amazon EC2 Instance Types](https://aws.amazon.com/ec2/instance-types/).
  - For information about when to create a Virtual Private Cloud (VPC) and when to reuse an existing VPC, see
  [Resource Usage in Your Amazon Web Services Account](aws.md#aws-resources).
- It is **strongly recommended** to use the Tanzu Kubernetes Grid installer interface rather than the CLI to deploy your first management cluster to Amazon EC2. When you deploy a management cluster by using the installer interface, it populates the `config.yaml` file for the management cluster with the required parameters. You can use the created `config.yaml` as a model for future deployments from the CLI.

## <a id="configure"></a> Configure the `config.yaml` File

The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. When you deploy a management cluster from the CLI, the `tkg init` command uses this configuration.

Also, the `tkg config permissions aws` command that you run to create a CloudFormation stack in your Amazon EC2 account retrieves the values of the
`AWS_ACCESS_KEY_ID`,
`AWS_SECRET_ACCESS_KEY`, `AWS_REGION` variables from
the `config.yaml` file. Alternatively, it can read these variables from the AWS default credential provider chain. For more information, see [Create an AWS CloudFormation Stack](#create) below.

To configure the `config.yaml` file, follow the steps below:

1. If this is the first time that you are running Tanzu Kubernetes Grid commands on your machine and you have not already deployed a management cluster to Amazon EC2 by using the Tanzu Kubernetes Grid installer interface, open a terminal and run the `tkg get management-cluster` command:

    ```
    tkg get management-cluster
    ```  

    Running a `tkg` command for the first time creates the `$HOME/.tkg` folder that contains the management cluster configuration file `config.yaml` and other configuration files.

1. Open the `.tkg/config.yaml` file in a text editor:

    - If you have already deployed a management cluster to Amazon EC2 from the installer interface, review the variables that describe your previous deployment and update your configuration file if needed.

    - If you have not already deployed a management cluster to Amazon EC2 from the installer interface, copy and paste the following rows at the end of your configuration file: 

        - **New VPC:** If you want to deploy a development management cluster with a
        single control plane node to a new VPC, add the variables listed below to the configuration file:

          ```
          AWS_ACCESS_KEY_ID:
          AWS_SECRET_ACCESS_KEY:
          AWS_REGION:
          AWS_NODE_AZ:
          AWS_PRIVATE_NODE_CIDR:
          AWS_PUBLIC_NODE_CIDR:
          AWS_SSH_KEY_NAME:
          AWS_VPC_CIDR:
          BASTION_HOST_ENABLED:
          SERVICE_CIDR:
          CLUSTER_CIDR:
          CONTROL_PLANE_MACHINE_TYPE:
          NODE_MACHINE_TYPE:
          ```

          If you want to deploy a production management cluster with three control plane nodes to a new VPC, add the following variables to the list of variables above:

          ```
          AWS_NODE_AZ_1:
          AWS_NODE_AZ_2:
          AWS_PRIVATE_NODE_CIDR_1:
          AWS_PRIVATE_NODE_CIDR_2:
          AWS_PUBLIC_NODE_CIDR_1:
          AWS_PUBLIC_NODE_CIDR_2:
          ```

          See the example configuration below for a production management cluster with three control plane nodes:

          ```
          AWS_ACCESS_KEY_ID: EXAMPLEWDRMY2A7QLK6UM
          AWS_SECRET_ACCESS_KEY: EXAMPLEghtYU/H6WUILO/dSqutLrIfxaz94mP6G
          AWS_REGION: us-west-2
          AWS_NODE_AZ: us-west-2a
          AWS_NODE_AZ_1: us-west-2b
          AWS_NODE_AZ_2: us-west-2c
          AWS_PRIVATE_NODE_CIDR: 10.0.0.0/24
          AWS_PRIVATE_NODE_CIDR_1: 10.0.2.0/24
          AWS_PRIVATE_NODE_CIDR_2: 10.0.4.0/24
          AWS_PUBLIC_NODE_CIDR: 10.0.1.0/24
          AWS_PUBLIC_NODE_CIDR_1: 10.0.3.0/24
          AWS_PUBLIC_NODE_CIDR_2: 10.0.5.0/24
          AWS_SSH_KEY_NAME: tkg
          AWS_VPC_CIDR: 10.0.0.0/16
          BASTION_HOST_ENABLED: "true"
          SERVICE_CIDR: 100.64.0.0/13
          CLUSTER_CIDR: 100.96.0.0/11
          CONTROL_PLANE_MACHINE_TYPE: m5.large
          NODE_MACHINE_TYPE: m5.large
          ```

        * **Existing VPC:** If you want to deploy a development management cluster with a single control plane node to an existing VPC, add the variables listed below to the configuration file:

          ```
          AWS_ACCESS_KEY_ID:
          AWS_SECRET_ACCESS_KEY:
          AWS_REGION:
          AWS_NODE_AZ:
          AWS_PRIVATE_SUBNET_ID:
          AWS_PUBLIC_SUBNET_ID:
          AWS_SSH_KEY_NAME:
          AWS_VPC_ID:
          BASTION_HOST_ENABLED:
          SERVICE_CIDR:
          CLUSTER_CIDR:
          CONTROL_PLANE_MACHINE_TYPE:
          NODE_MACHINE_TYPE:
          ```

          If you want to deploy a production management cluster with three control plane nodes to an existing VPC, add the following variables to the list of variables above:

          ```
          AWS_NODE_AZ_1:
          AWS_NODE_AZ_2:
          AWS_PRIVATE_SUBNET_ID_1:
          AWS_PRIVATE_SUBNET_ID_2:
          AWS_PUBLIC_SUBNET_ID_1:
          AWS_PUBLIC_SUBNET_ID_2:
          ```

          See the example configuration below for a production management cluster with three control plane nodes:

          ```
          AWS_ACCESS_KEY_ID: EXAMPLEWDRMY2A7QLK6UM
          AWS_SECRET_ACCESS_KEY: EXAMPLEghtYU/H6WUILO/dSqutLrIfxaz94mP6G
          AWS_REGION: us-west-2
          AWS_NODE_AZ: us-west-2a
          AWS_NODE_AZ_1: us-west-2b
          AWS_NODE_AZ_2: us-west-2c
          AWS_PRIVATE_SUBNET_ID: subnet-ID
          AWS_PRIVATE_SUBNET_ID_1: subnet-ID
          AWS_PRIVATE_SUBNET_ID_2: subnet-ID
          AWS_PUBLIC_SUBNET_ID: subnet-ID
          AWS_PUBLIC_SUBNET_ID_1: subnet-ID
          AWS_PUBLIC_SUBNET_ID_2: subnet-ID
          AWS_SSH_KEY_NAME: tkg
          AWS_VPC_ID: vpc-ID
          BASTION_HOST_ENABLED: "true"
          SERVICE_CIDR: 100.64.0.0/13
          CLUSTER_CIDR: 100.96.0.0/11
          CONTROL_PLANE_MACHINE_TYPE: m5.large
          NODE_MACHINE_TYPE: m5.large
          ```

    The table in [Configuration Parameter Reference](#params-ref) describes all of the configuration options that you can provide for deployment of a management cluster to Amazon EC2. Line order in the configuration file does not matter.


### <a id="parameters"></a> Configuration Parameter Reference

The table below describes all of the variables that you must set for deployment to Amazon EC2, along with some AWS-specific optional variables. To set them in a configuration file, leave a space between the colon (`:`) and the variable value. For example:

```
AWS_REGION: us-west-2
```

**IMPORTANT**:

- As described in [Configuring the Management Cluster](deploy-management-clusters.md#configuring), environment variables override values from a configuration file. To use all settings from a `config.yaml`, unset any conflicting environment variables before you deploy the management cluster from the CLI.
- Tanzu Kubernetes Grid does not support IPv6 addresses. This is because upstream Kubernetes only provides alpha support for IPv6. Always provide IPv4 addresses in the procedures in this topic.

<table width="100%" border="0">
  <tr>
    <th width="25%" scope="col">Parameter</th>
    <th width="25%" scope="col">Value</th>
    <th width="50%" scope="col">Description</th>
  </tr>
  <tr>
    <td><code>AWS_ACCESS_KEY_ID</code></td>
    <td>Your AWS access key ID</td>
    <td>Enter the access key ID for your AWS account.</td>
  </tr>
  <tr>
    <td><code>AWS_SECRET_ACCESS_KEY</code></td>
    <td>Your AWS secret access key</td>
    <td>Enter the secret access key for your AWS account.</td>
  </tr>
  <tr>
    <td><code>AWS_REGION</code></td>
    <td><code>us-west-2</code>, <code>ap-northeast-2</code>, etc.</td>
    <td>The name of the AWS region in which to deploy the management cluster. For example, <code>us-west-2</code>. You can also specify the
      <code>us-gov-east</code> and <code>us-gov-west</code> regions in AWS GovCloud. If you have already set a different region as an environment variable, for example, in <a href="aws.md">Deploy Management Clusters to Amazon EC2</a>, you must unset that environment variable.</td>
  </tr>
  <tr>
    <td><code>AWS_NODE_AZ</code></td>
    <td><code>us-west-2a</code>, <code>ap-northeast-2b</code>, etc.</td>
    <td>The name of the AWS availability zone in your chosen region that you want use as the availability zone for this management cluster. Availability zone names are the same as the AWS region name, with a single lower-case letter suffix, such as <code>a</code>, <code>b</code>, <code>c</code>. For example,
      <code>us-west-2a</code>. To deploy a <code>prod</code> management cluster with three control plane nodes, you must also set
      <code>AWS_NODE_AZ_1</code> and <code>AWS_NODE_AZ_2</code>. The letter suffix in each of these availability zones must be unique. For example, <code>us-west-2a</code>,
      <code>us-west-2b</code>, and <code>us-west-2c</code>.</td>
  </tr>
  <tr>
    <td><code>AWS_NODE_AZ_1</code> and <code>AWS_NODE_AZ_2</code></td>
    <td><code>us-west-2a</code>, <code>ap-northeast-2b</code>, etc.</td>
    <td>Set these variables if you want to deploy a <code>prod</code> management cluster with three control plane nodes. Both availability zones must be in the same region as <code>AWS_NODE_AZ</code>. See <code>AWS_NODE_AZ</code> above for more information.</td>
  <tr>
    <td><code>AWS_PRIVATE_NODE_CIDR</code></td>
    <td><code>10.0.0.0/24</code></td>
    <td>Set this variable if you set <code>AWS_VPC_CIDR</code>. If the recommended range of 10.0.0.0/24 is not available, enter a different IP range in CIDR format for private nodes to use. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in
      <code>AWS_NODE_AZ</code>. To deploy a <code>prod</code> management cluster with three control plane nodes, you must also set
      <code>AWS_PRIVATE_NODE_CIDR_1</code> and
      <code>AWS_PRIVATE_NODE_CIDR_2</code>.</td>
  </tr>
  <tr>
    <td><code>AWS_PRIVATE_NODE_CIDR_1</code></td>
    <td><code>10.0.2.0/24</code></td>
    <td>If the recommended range of 10.0.2.0/24 is not available, enter a different IP range in CIDR format. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in <code>AWS_NODE_AZ_1</code>. See
    <code>AWS_PRIVATE_NODE_CIDR</code> above for more information.</td>
  <tr>
    <td><code>AWS_PRIVATE_NODE_CIDR_2</code></td>
    <td><code>10.0.4.0/24</code></td>
    <td>If the recommended range of 10.0.4.0/24 is not available, enter a different IP range in CIDR format. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in <code>AWS_NODE_AZ_2</code>. See
      <code>AWS_PRIVATE_NODE_CIDR</code> above for more information.</td>
  <tr>
  <tr>
    <td><code>AWS_PUBLIC_NODE_CIDR</code></td>
    <td><code>10.0.1.0/24</code></td>
    <td>Set this variable if you set <code>AWS_VPC_CIDR</code>. If the recommended range of 10.0.1.0/24 is not available, enter a different IP range in CIDR format for public nodes to use. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in
      <code>AWS_NODE_AZ</code>. To deploy a <code>prod</code> management cluster with three control plane nodes, you must also set
      <code>AWS_PUBLIC_NODE_CIDR_1</code> and
      <code>AWS_PUBLIC_NODE_CIDR_2</code>.</td>
  </tr>
  <tr>
    <td><code>AWS_PUBLIC_NODE_CIDR_1</code></td>
    <td><code>10.0.3.0/24</code></td>
    <td>If the recommended range of 10.0.3.0/24 is not available, enter a different IP range in CIDR format. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in <code>AWS_NODE_AZ_1</code>.
    See <code>AWS_PUBLIC_NODE_CIDR</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_PUBLIC_NODE_CIDR_2</code></td>
    <td><code>10.0.5.0/24</code></td>
    <td>If the recommended range of 10.0.5.0/24 is not available, enter a different IP range in CIDR format. When Tanzu Kubernetes Grid deploys your management cluster, it creates this subnetwork in <code>AWS_NODE_AZ_2</code>. See <code>AWS_PUBLIC_NODE_CIDR</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_PRIVATE_SUBNET_ID</code></td>
    <td>Private subnet for the VPC </td>
    <td>If you set <code>AWS_VPC_ID</code> to use an existing VPC, enter the ID of a private subnet that already exists in <code>AWS_NODE_AZ</code>. This setting is optional. If you do not set it, <code>tkg init</code> identifies the private subnet automatically. To deploy a <code>prod</code> management cluster with three control plane nodes, you must also set
      <code>AWS_PRIVATE_SUBNET_ID_1</code> and
      <code>AWS_PRIVATE_SUBNET_ID_2</code>.</td>
  </tr>
  <tr>
    <td><code>AWS_PRIVATE_SUBNET_ID_1</code></td>
    <td>Private subnet for the VPC </td>
    <td>Enter the ID of a private subnet that exists in <code>AWS_NODE_AZ_1</code>. If you do not set this variable, <code>tkg init</code> identifies the private subnet automatically. See
      <code>AWS_PRIVATE_SUBNET_ID</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_PRIVATE_SUBNET_ID_2</code></td>
    <td>Private subnet for the VPC </td>
    <td>Enter the ID of a private subnet that exists in <code>AWS_NODE_AZ_2</code>. If you do not set this variable, <code>tkg init</code> identifies the private subnet automatically. See
      <code>AWS_PRIVATE_SUBNET_ID</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_PUBLIC_SUBNET_ID</code></td>
    <td>Public subnet for the VPC</td>
    <td>If you set <code>AWS_VPC_ID</code> to use an existing VPC, enter the ID of a public subnet that already exists in <code>AWS_NODE_AZ</code>. This setting is optional. If you do not set it, <code>tkg init</code> identifies the public subnet automatically. To deploy a <code>prod</code> management cluster with three control plane nodes, you must also set
      <code>AWS_PUBLIC_SUBNET_ID_1</code> and
      <code>AWS_PUBLIC_SUBNET_ID_2</code>.</td>
  </tr>
  <tr>
    <td><code>AWS_PUBLIC_SUBNET_ID_1</code></td>
    <td>Public subnet for the VPC</td>
    <td>Enter the ID of a public subnet that exists in <code>AWS_NODE_AZ_1</code>. If you do not set this variable, <code>tkg init</code> identifies the public subnet automatically. See
      <code>AWS_PUBLIC_SUBNET_ID</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_PUBLIC_SUBNET_ID_2</code></td>
    <td>Public subnet for the VPC</td>
    <td>Enter the ID of a public subnet that exists in <code>AWS_NODE_AZ_2</code>. If you do not set this variable, <code>tkg init</code> identifies the public subnet automatically. See
      <code>AWS_PUBLIC_SUBNET_ID</code> above for more information.</td>
  </tr>
  <tr>
    <td><code>AWS_SSH_KEY_NAME</code></td>
    <td>Your SSH key name</td>
    <td>Enter the name of the SSH private key that you registered with your AWS account.</td>
  </tr>
  <tr>
    <td><code>AWS_VPC_ID</code></td>
    <td>VPC ID name</td>
    <td>To use a VPC that already exists in your selected AWS region, enter the ID of the VPC and then set <code>AWS_PUBLIC_SUBNET_ID</code> and
      <code>AWS_PRIVATE_SUBNET_ID</code>. Set either <code>AWS_VPC_ID</code> or <code>AWS_VPC_CIDR</code>, but not both.</td>
  </tr>
  <tr>
    <td><code>AWS_VPC_CIDR</code></td>
    <td><code>10.0.0.0/16</code></td>
    <td>If you want Tanzu Kubernetes Grid to create a new VPC in the selected region, set the <code>AWS_VPC_CIDR</code>,
      <code>AWS_PUBLIC_NODE_CIDR</code>, and
      <code>AWS_PRIVATE_NODE_CIDR</code> variables. If the recommended range of 10.0.0.0/16 is not available, enter a different IP range in CIDR format in <code>AWS_VPC_CIDR</code> for the management cluster to use. Set either <code>AWS_VPC_CIDR</code> or <code>AWS_VPC_ID</code>, but not both.</td>
  </tr>
  <tr>
    <td><code>BASTION_HOST_ENABLED</code></td>
    <td><code>&quot;true&quot;</code> or <code>&quot;false&quot;</code> </td>
    <td>This option is set to <code>&quot;true&quot;</code> in the global Tanzu Kubernetes Grid configuration. Specify <code>&quot;true&quot;</code> to deploy an AWS basion host or <code>&quot;false&quot;</code> to reuse an existing bastion host. If no bastion host exists in your availability zone(s) and you set <code>AWS_VPC_ID</code> to use an existing VPC, set <code>BASTION_HOST_ENABLED</code> to <code>&quot;true&quot;</code>.</td>
  </tr>
  <tr>
    <td><code>SERVICE_CIDR</code></td>
    <td><code>100.64.0.0/13</code></td>
    <td>The CIDR range to use for the Kubernetes services. The recommended range is 100.64.0.0/13. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>CLUSTER_CIDR</code></td>
    <td><code>100.96.0.0/11</code></td>
    <td>The CIDR range to use for pods. The recommended range is 100.96.0.0/11. Change this value only if the recommended range is unavailable.</td>
  </tr>
  <tr>
    <td><code>CONTROL_PLANE_MACHINE_TYPE</code></td>
    <td>For example, <code>t3.small</code></td>
    <td>An AWS <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html">instance type</a> available in your specified region and availability zone(s) for the control plane node VMs, depending on the expected workloads that you will run in the cluster. Possible values may include <code>i3.xlarge</code>, <code>r4.8xlarge</code>, <code>m5a.4xlarge</code>, <code>m5.large</code>, and <code>t3.small</code>, but see <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-discovery.html">Finding an Amazon EC2 instance type</a> in the AWS documentation for actual choices. You can also specify or override this value by using the <code>tkg init --size</code> or <code>--controlplane-size</code> options.</td>
  </tr>
  <tr>
    <td><code>NODE_MACHINE_TYPE</code></td>
    <td>For example, <code>m5.large</code></td>
    <td>An AWS <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html">instance type</a> available in your specified region and availability zone(s) for the worker node VMs, depending on the expected workloads that you will run in the cluster. Possible values may include <code>i3.xlarge</code>, <code>r4.8xlarge</code>, <code>m5a.4xlarge</code>, <code>m5.large</code>, and <code>t3.small</code>, but see <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-discovery.html">Finding an Amazon EC2 instance type</a> in the AWS documentation for actual choices. You can also specify or override this value by using the <code>tkg init --size</code> or <code>--worker-size</code> options.</td>
  </tr>
  <tr>
    <td><code>ENABLE_MHC</code></td>
    <td><code>"true"</code> or <code>"false"</code></td>
    <td>Enables or disables the <a href="https://cluster-api.sigs.k8s.io/developer/architecture/controllers/machine-health-check.html#machinehealthcheck"><code>MachineHealthCheck</code></a> controller, which provides node health monitoring and node auto-repair for Tanzu Kubernetes clusters. This option is enabled in the global Tanzu Kubernetes Grid configuration by default, for all Tanzu Kubernetes clusters. To disable <code>MachineHealthCheck</code> on the clusters that you deploy with this management cluster, set <code>ENABLE_MHC</code> to <code>false</code>. Set this variable only if you want to override your global configuration. You can enable or disable <code>MachineHealthCheck</code> on individual clusters after deployment by using the CLI. For instructions, see <a href="../tanzu-k8s-clusters/configure-health-checks.md">Configure Machine Health Checks for Tanzu Kubernetes Clusters</a>.</td>
  </tr>
  <tr>
    <td><code>MHC_UNKNOWN_STATUS_TIMEOUT</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>Unknown</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
  <tr>
    <td><code>MHC_FALSE_STATUS_TIMEOUT</code></td>
    <td>For example, <code>10m</code></td>
    <td>Property of <code>MachineHealthCheck</code>. By default, if the <code>Ready</code> condition of a node remains <code>False</code> for longer than <code>5m</code>, <code>MachineHealthCheck</code> considers the machine unhealthy and recreates it. Set this variable if you want to change the default timeout.</td>
  </tr>
</table>   

## <a id="create"></a> Create an AWS CloudFormation Stack

Before deploying a management cluster to Amazon EC2 for the first time,
you must create an AWS CloudFormation stack for Tanzu Kubernetes Grid in your AWS account. To create the CloudFormation stack, you run the
`tkg config permissions aws` command from the CLI or enable the **Automate creation of AWS CloudFormation Stack** in the installer interface.

This CloudFormation stack provides the identity and access management (IAM) resources that Tanzu Kubernetes Grid needs to create management clusters and Tanzu Kubernetes clusters on Amazon EC2. The IAM resources are added to the control plane and node roles when they are created during cluster deployment.

You need to create only one CloudFormation stack per AWS account. The IAM resources that the CloudFormation stack provides are global, meaning they are not specific to any region. For more information about CloudFormation stacks, see [Working with Stacks](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/stacks.html) in the AWS documentation.

**IMPORTANT:** In Tanzu Kubernetes Grid v1.2 and later, the **Automate creation of AWS CloudFormation Stack** checkbox and the
`tkg config permissions aws` command replace the `clusterawsadm` command line utility. For existing management and Tanzu Kubernetes clusters, initially deployed with v1.1.x or earlier, continue to use the CloudFormation stack that you created by running the
`clusterawsadm alpha bootstrap create-stack` command. If you want to use the same AWS account for your existing clusters and Tanzu Kubernetes Grid v1.2 and later, both stacks must be present in the account. For more information, see [Prepare to Upgrade Clusters on Amazon EC2](../upgrade-tkg/index.md#aws).

Do one of the following:

* If you have already created the CloudFormation stack for Tanzu Kubernetes Grid in your AWS account, proceed to [Run the `tkg init` Command](#run) below.
* If you have not already created the CloudFormation stack for Tanzu Kubernetes Grid in your AWS account:

    1. Ensure that the `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and
    `AWS_REGION` are set in your configuration file or set them in the AWS default credential provider chain. For more information, see
    [Working with AWS Credentials](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html) in the AWS documentation.

    1. Run the following command:

       ```
       tkg config permissions aws
       ```
       To specify the path to your configuration file, use the `--config` flag.
       The default path is `$HOME/.tkg/config.yaml`. For more information about this command, run `tkg config permissions aws --help`.

## <a id="run"></a> Run the tkg init Command

After you have updated `.tkg/config.yaml` you deploy a management cluster by running the `tkg init` command. The `config.yaml` file provides the base configuration for management clusters and Tanzu Kubernetes clusters. You provide more precise configuration information for individual clusters by running the `tkg init` command with different options.

**IMPORTANT**: Do not run multiple management cluster deployments on the same bootstrap machine at the same time. Do not change context or edit the `.kube-tkg/config` file while Tanzu Kubernetes Grid operations are running.

To deploy a management cluster to Amazon EC2, you must at least specify the `--infrastructure aws` option to `tkgi init`:

   ```
   tkg init --infrastructure aws
   ```
   
The table in [CLI Options Reference](#cli-ref) describes additional command-line options for deploying a management cluster to Amazon EC2.

**Monitoring Progress**

When you run `tkg init`, you can follow the progress of the deployment of the management cluster in the terminal.  For more detail, open the log file listed in the terminal output **Logs of the command execution can also be found at...**.

Deployment of the management cluster can take several minutes. The first run of `tkg init` takes longer than subsequent runs because it has to pull the required Docker images into the image store on your bootstrap machine. Subsequent runs do not require this step, so are faster.

The first run of `tkg init` also adds settings to your configuration file.

If `tkg init` fails before the management cluster deploys to AWS, you should clean up artifacts on your bootstrap machine before you re-run `tkg init`. See the [Troubleshooting Tips](../troubleshooting-tkg/tips.html) topic for details.

### <a id="cli-ref"></a> CLI Options Reference

The table below describes command-line options that you can set for deployment to AWS.

For example, to create a highly available Amazon EC2 management cluster `aws-mgmt-cluster` in which all of the control plane and worker node VMs are `t3.xlarge` size:

   ```
   tkg init --infrastructure aws --name aws-mgmt-cluster --plan prod --size t3.xlarge
   ```

<table width="100%" border="0">
<tr>
  <th width="25%" scope="col">Option</th>
  <th width="25%" scope="col">Value</th>
  <th width="50%" scope="col">Description</th>
</tr>
<tr>
  <td><code>--infrastructure</code></td>
  <td><code>aws</code></td>
  <td>Required</td>
</tr>
<tr>
  <td><code>--name</code></td>
  <td>Name for the management cluster</td>
  <td>Name must comply with DNS hostname requirements as outlined in <a href="https://tools.ietf.org/html/rfc952">RFC 952</a> and amended in <a href="https://tools.ietf.org/html/rfc1123">RFC 1123</a><br />
  If you do not specify a name, a unique name is generated.</td>
</tr>
<tr>
  <th colspan=3>Scaling and Availability
  </th>
</tr>
<tr>
  <td><code>--plan</code></td>
  <td><code>dev</code> or <code>prod</code></td>
  <td><code>dev</code> ("development"), the default, deploys a management cluster with a single control plane node.<br />
  <code>prod</code> ("production") deploys a highly available management cluster with three control plane nodes.</td>
</tr>
<tr>
  <th colspan=3>Configuration Files
  </th>
</tr>
<tr>
  <td><code>--config</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-config.yaml</code></td>
  <td>Configuration file to use or create, other than the default <code>$HOME/.tkg/config.yaml</code>. If the config file was not already created by hand or prior <code>tkg init</code> calls, it is created.  All other files are created in the default folder.<br />
  This option, for example, lets you deploy multiple management clusters that share a VNET.</td>
</tr>
<tr>
  <td><code>--kubeconfig</code></td>
  <td>Local file system path to <code>.yaml</code> file, e.g. <code>/path/to/file/my-kubeconfig.yaml</code></td>
  <td>Kube configuration file or use, or create, other than the default <code>$HOME/.kube-tkg/config.yaml</code>.<br />
  This option lets you customize or share multiple <code>kubeconfig</code> files for multiple management clusters.</td>
</tr>
<tr>
  <th colspan=3>Nodes
  </th>
</tr>
<tr>
  <td><code>--size</code></td>
  <td rowspan=3>An AWS <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html">instance type</a> available in your specified region and availability zone(s). Possible values may include <code>i3.xlarge</code>, <code>r4.8xlarge</code>, <code>m5a.4xlarge</code>, <code>m5.large</code>, and <code>t3.small</code>, but see <a href="https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-discovery.html">Finding an Amazon EC2 instance type</a> in the AWS documentation for actual choices.</td>
  <td>Size for both control plane and worker node VMs.</td>
</tr>
<tr>
  <td><code>--controlplane-size</code></td>
  <td>Size for control plane node VMs. Overrides the <code>--size</code> option and <code>CONTROL_PLANE_MACHINE_TYPE</code> parameter.</td>
</tr>
<tr>
  <td><code>--worker-size</code></td>
  <td>Size for worker node VMs. Overrides the <code>--size</code> option and <code>NODE_MACHINE_TYPE</code> parameter.</td>
</tr>
<tr>
  <th colspan=3>Customer Experience Improvement Program
  </th>
</tr>
<tr>
  <td><code>--ceip-participation</code></td>
  <td><code>true</code> or <code>false</code></td>
  <td><code>false</code> opts out of the VMware Customer Experience Improvement Program. Default is <code>true</code>.<br />
  You can also opt in or out of the program after deploying  the management cluster. For information, see <a href="multiple-management-clusters.md#ceip">Opt in or Out of the VMware CEIP</a> and <a href="https://www.vmware.com/solutions/trustvmware/ceip.html">Customer Experience Improvement Program ("CEIP")</a>.</td>
</tr>
</table>


## <a id="what-next"></a> What to Do Next

- For information about what happened during the deployment of the management cluster, how to connect `kubectl` to the management cluster, and how to create namespaces see [Examine the Management Cluster Deployment](verify-deployment.md).
- For information about how to create namespaces in the management cluster, see [Create Namespaces in the Management Cluster](create-namespaces.md).
- If you need to deploy more than one management cluster, on any or all of vSphere, Azure, and Amazon EC2, see [Manage Your Management Clusters](multiple-management-clusters.md). This topic also provides information about how to add existing management clusters to your CLI instance, obtain credentials, scale and delete management clusters, and how to opt in or out of the CEIP.
