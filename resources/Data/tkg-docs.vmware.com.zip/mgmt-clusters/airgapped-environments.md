# Deploy Tanzu Kubernetes Grid to an Offline Environment

This topic describes how to set up an offline environment, not connected to the Internet, where you can deploy Tanzu Kubernetes Grid management clusters and Kubernetes clusters. These procedures apply to vSphere or AWS environments.

You do not need to perform this procedure if you are using Tanzu Kubernetes Grid in a connected environment that can pull images over an external Internet connection.

- [Prerequisites](#prereqs)
    - [vSphere Prerequisites](#prereqs-vsphere)
    - [Amazon EC2 Prerequisites](#prereqs-aws)
- [Procedure](#procedure)
    - [Step 1: Prepare Environment](#prepare)
    - [Step 2: Generate the `publish-images` Script](#generate)
    - [Step 3: Run the `publish-images` Script](#run)
- [What to Do Next](#what-next)

## <a id="prereqs"></a> Prerequisites

Before you can deploy management clusters and Tanzu Kubernetes clusters in an offline environment, you must have:

- A private Docker registry such as [Harbor](https://goharbor.io/), against which this procedure has been tested.
   - Install the Docker registry within your firewall (for vSphere).
   For information about how to install Harbor, see [Harbor Installation and Configuration](https://goharbor.io/docs/latest/install-config/).
   - Ideally, configure the Docker registry with public SSL certificates signed by a trusted CA, not self-signed certificates. Using self-signed certificates is possible, but requires you to either disable TLS verification, manually inject the certificates into every cluster node that you deploy, or to deploy Harbor as a shared service after you complete the steps in this procedure. For information about how to obtain the Harbor registry certificate, see [the Harbor documentation](https://goharbor.io/docs/latest/working-with-projects/working-with-images/pulling-pushing-images/). For more information about Harbor and self-signed certificates in an Internet-restricted environment, see [Deploy Harbor Registry as a Shared Service](../extensions/harbor-registry.md).
- An Internet-connected Linux bootstrap machine that:
   - Can connect to your private Docker registry; for example, is inside your VPC.
   - Has the Docker client app installed.
   - Has the Tanzu Kuberneted Grid CLI installed. See [Install the Tanzu Kubernetes Grid CLI](../install-tkg.md) to download, unpack, and install the Tanzu Kubernetes Grid CLI binary on your Internet-connected system.
   - Has [`yq`](https://github.com/mikefarah/yq) and [`jq`](https://stedolan.github.io/jq/) installed.

### <a id="prereqs-vsphere"></a> vSphere Prerequisites

On vSphere, in addition to the prerequisites above, you must:

- Create an SSH key pair. See [Create an SSH Key Pair](vsphere.md#ssh-key) in _Deploy Management Clusters to vSphere_.
- Upload to vSphere the OVAs from which node VMs are created.  See [Import the Base OS Image Template into vSphere](vsphere.md#import-baseos) in _Deploy Management Clusters to vSphere_.

### <a id="prereqs-aws"></a> Amazon EC2 Prerequisites

For an offline installation on Amazon EC2, you also need:

- An Amazon EC2 VPC with no internet gateway ("offline VPC") configured as described below.
- An Amazon S3 bucket.
- A Docker registry installed within your offline VPC, configured equivalently to the internet-connected registry above.
- A Linux bootstrap VM within your offline VPC, provisioned similarly to the internet-connected machine above.

**Offline VPC Configuration**

By default, deploying Tanzu Kubernetes Grid to Amazon EC2 creates a new, internet-connected VPC.
To deploy to an offline environment, you must first create an offline VPC. For details, see the [Reuse a VPC and NAT gateway(s) that already exist in your availability zone(s)](aws.html#aws-vpc) instructions in the _Deploy Management Clusters to Amazon EC2_ topic.

After you create the offline VPC, you must add following endpoints to it:

   - Service endpoints:
     - `sts`
     - `ssm`
     - `ec2`
     - `ec2messages`
     - `elasticloadbalancing`
     - `secretsmanager`
     - `ssmmessages`
   - Gateway endpoint to your Amazon S3 storage bucket

To add the service endpoints to your VPC:

1. In the AWS console, browse to **VPC Dashboard** > **Endpoints**
1. For each of the above services
   1. Click **Create Endpoint**
   1. Search for the service and select it under **Service Name**
   1. Select your **VPC** and its **Subnets**
   1. **Enable DNS Name** for the endpoint
   1. Select a **Security group** that allows VMs in the VPC to access the endpoint
   1. Select **Policy** > **Full Access**
   1. Click **Create endpoint**

To add the Amazon S3 gateway endpoint to your VPC, follow the instructions in
[Endpoints for Amazon S3](https://docs.aws.amazon.com/vpc/latest/userguide/vpce-gateway.html) in the AWS documentation.

  - When an offline VPC has an S3 endpoint to dedicated S3 storage, all traffic between the VPC and S3 travels via internal AWS cloud infrastructure, and never over the open Internet.

## <a id="procedure"></a> Procedure

This procedure also applies if you are upgrading an existing offline Tanzu Kubernetes Grid deployment. 

### <a id="prepare"></a> Step 1: Prepare Environment

1. On the machine with an Internet connection on which you installed the Tanzu Kubernetes Grid CLI, run the `tkg get management-cluster` command.

   Running a `tkg` command for the first time installs the necessary Tanzu Kubernetes Grid configuration files in the `~/.tkg` folder on your system. The script that you create and run in subsequent steps requires the Bill of Materials (BoM) YAML files in the `~/.tkg/bom` folder to be present on your machine. The scripts in this procedure use the BoM files to identify the correct versions of the different Tanzu Kubernetes Grid component images to pull.

1. In the `~/.tkg/bom` folder, temporarily remove any BoM files that either:
   - Do not correspond to your current and previously-installed versions of Tanzu Kubernetes Grid, or
   - Do not correspond to patch versions of Kubernetes that you plan to run workloads on.
   
   For example, if you upgraded to v1.2 from v1.1.3, and you want to run workloads on Kubernetes v1.19.1 (the default for Tanzu Kubernetes Grid v1.2), v1.18.6 (the default Kubernetes for v1.1.3), and Kubernetes v1.18.8, then you should keep the following BoM files in `~/.tkg/bom` and move the rest elsewhere:

   - `bom-1.2.0+vmware.1.yaml`
   - `bom-1.1.3+vmware.1.yaml`
   - `bom-1.18.8+vmware.1.yaml`
   
   Note: BoM files named for Tanzu Kubernetes Grid versions, like `bom-1.2.0+vmware.1.yaml`, specify the default Kubernetes version for those Tanzu Kubernetes Grid versions and their management clusters. BoM files named for Kubernetes versions, like `bom-1.18.8+vmware.1.yaml` enable workload clusters to run non-default versions of Kubernetes. In all cases, the file's `components.kubernetes.version` field specifies the Kubernetes version that it includes.

1. Set the IP address or FQDN of your local registry as an environment variable.

   In the following command example, replace `custom-image-repository.io` with the address of your private Docker registry.

   On Windows platforms, use the `SET` command instead of `export`. Include the name of the project in the value: 
   
   ```
   export TKG_CUSTOM_IMAGE_REPOSITORY="custom-image-repository.io/yourproject"
   ```   
1. If your private Docker registry uses a self-signed certificate, set the following environment variable to disable TLS verification.

   On Windows platforms, use the `SET` command instead of `export`.
   
   ```
   export TKG_CUSTOM_IMAGE_REPOSITORY_SKIP_TLS_VERIFY=true
   ```

### <a id="generate"></a> Step 2: Generate the `publish-images` Script

1. Copy and paste the following shell script in a text editor, and save it as `gen-publish-images.sh`.

    ```
    #!/usr/bin/env bash
    # Copyright 2020 The TKG Contributors.
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #     http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    BOM_DIR=${HOME}/.tkg/bom
    
    if [ -z "$TKG_CUSTOM_IMAGE_REPOSITORY" ]; then
        echo "TKG_CUSTOM_IMAGE_REPOSITORY variable is not defined"
        exit 1
    fi
    
    for TKG_BOM_FILE in "$BOM_DIR"/*.yaml; do
        # Get actual image repository from BoM file
        actualImageRepository=$(yq r "$TKG_BOM_FILE" imageConfig.imageRepository | tr -d '"')
    
        # Iterate through BoM file to create the complete Image name
        # and then pull, retag and push image to custom registry
        yq r --tojson "$TKG_BOM_FILE" images | jq -c '.[]' | while read -r i; do
            # Get imagePath and imageTag
            imagePath=$(jq .imagePath <<<"$i" | tr -d '"')
            imageTag=$(jq .tag <<<"$i" | tr -d '"')
    
            # create complete image names
            actualImage=$actualImageRepository/$imagePath:$imageTag
            customImage=$TKG_CUSTOM_IMAGE_REPOSITORY/$imagePath:$imageTag
    
            echo "docker pull $actualImage"
            echo "docker tag  $actualImage $customImage"
            echo "docker push $customImage"
            echo ""
        done
    done
    ```
1. Make the `gen-publish-images` script executable.

   ```
   chmod +x gen-publish-images.sh
   ```
1. Generate a `publish-images` shell script that is populated with the address of your private Docker registry.

   ```
   ./gen-publish-images.sh > publish-images.sh
   ```
1. Verify that the generated script contains the correct registry address.

   ```
   cat publish-images.sh
   ```

### <a id="run"></a> Step 3: Run the `publish-images` Script

1. Make the `publish-images` script executable.

   ```
   chmod +x publish-images.sh
   ```
1. Log in to your local private registry.
   ```
   docker login ${TKG_CUSTOM_IMAGE_REPOSITORY}
   ``` 
1. Run the `publish-images` script to pull the required images from the public Tanzu Kubernetes Grid registry, retag them, and push them to your private registry.

   ```
   ./publish-images.sh
   ```
   
   If your registry lacks sufficient storage for all images in the `publish-images` script, re-generate and re-run the script after either:
   
   - Increasing the `persistentVolumeClaim.registry.size` value in your Harbor extension configuration. See [Deploy Harbor Registry as a Shared Service](../extensions/harbor-registry.md) and the `extensions/registry/harbor/harbor-data-values.yaml.example` file in the **VMware Tanzu Kubernetes Grid Extensions Manifest 1.2.0** download on [https://www.vmware.com/go/get-tkg](https://www.vmware.com/go/get-tkg).
   - Removing additional BoM files from the `~/.tkg/bom` directory, as described in [Step 1: Prepare Environment](#prepare).
   
1. When the script finishes, do the following, depending on your infrastructure:
  - **vSphere**: Turn off your Internet connection.
  - **Amazon EC2**: Use the offline VPC's S3 gateway to transfer the Docker containers from the online registry to the offline registry, and the `tkg` CLI and dependencies from the online bootstrap machine to the offline bootstrap machine.
     - You can do this from the AWS console by uploading and downloading `tar` archives from the online registry and machine, and to the offline registry and machine.

1. Run any Tanzu Kubernetes Grid CLI command, for example `tkg init --ui`.

   The Tanzu Kubernetes Grid installer interface should open.
   
## <a id="what-next"></a> What to Do Next

As long as the `TKG_CUSTOM_IMAGE_REPOSITORY` variable remains set, when you deploy clusters, Tanzu Kubernetes Grid will pull images from your local private registry rather than from the external public registry. To make sure that Tanzu Kubernetes Grid always pulls images from the local private registry, add `TKG_CUSTOM_IMAGE_REPOSITORY` to the `~/.tkg/config.yaml` file. If your Docker registry uses self-signed certificates, also add `TKG_CUSTOM_IMAGE_REPOSITORY_SKIP_TLS_VERIFY` to `~/.tkg/config.yaml`. 

```
TKG_CUSTOM_IMAGE_REPOSITORY: custom-image-repository.io/yourproject
TKG_CUSTOM_IMAGE_REPOSITORY_SKIP_TLS_VERIFY: true
```

Your offline environment is now ready for you to deploy or upgrade Tanzu Kubernetes Grid management clusters and Tanzu Kubernetes clusters to vSphere or Amazon EC2. 

- [Deploy Management Clusters to vSphere](vsphere.md)
- [Deploy Management Clusters to Amazon EC2](aws.md)
- If you performed this procedure as a part of an upgrade, see [Upgrading Tanzu Kubernetes Grid](../upgrade-tkg/index.md).
- If you used self-signed certificates with your private registry and have disabled TLS verification, see [Deploy Harbor Registry as a Shared Service](../extensions/harbor-registry.md) for more information about how to secure your deployment.