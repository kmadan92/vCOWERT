# Install the Tanzu Kubernetes Grid CLI

<!-- A README is required in each folder by Gitbook. This file is only for PDF generation and does not appear in the output -->

*Install the Tanzu Kubernetes Grid CLI* describes the prerequisites for installing Tanzu Kubernetes Grid on vSphere and on Amazon EC2, and how to deploy the management cluster to vSphere, Azure, and Amazon EC2.
